/**
 * TOP O'ZBEK — Real API Client
 * Connects frontend to backend server + Supabase
 */

const API_BASE = import.meta.env.VITE_API_URL || '/api';

function getHeaders(): Record<string, string> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  const tg = window.Telegram?.WebApp;
  if (tg?.initData) {
    headers['X-Telegram-Init-Data'] = tg.initData;
  }
  return headers;
}

async function apiFetch<T = any>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: { ...getHeaders(), ...(options.headers as Record<string, string> || {}) }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Network error' }));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

// ── Auth ─────────────────────────────────────────────────────
export async function verifyTelegramUser() {
  const tg = window.Telegram?.WebApp;
  if (!tg?.initData) throw new Error('Not in Telegram Mini App');
  return apiFetch<any>('/auth/telegram-verify', {
    method: 'POST',
    body: JSON.stringify({ initData: tg.initData })
  });
}

// ── Leaderboard ───────────────────────────────────────────────
export async function fetchLeaderboard() {
  return apiFetch<{ users: any[] }>('/leaderboard');
}

// ── Gifts & Boosts ────────────────────────────────────────────
export async function fetchGifts() {
  return apiFetch<{ gifts: any[] }>('/gifts');
}

export async function fetchBoosts() {
  return apiFetch<{ packages: any[] }>('/boosts');
}

// ── User ──────────────────────────────────────────────────────
export async function fetchUser(telegramId: number) {
  return apiFetch<{ user: any }>(`/user/${telegramId}`);
}

// ── Transactions ──────────────────────────────────────────────
export async function fetchTransactions(telegramId: number) {
  return apiFetch<{ transactions: any[] }>(`/transactions/${telegramId}`);
}

// ── Competition ───────────────────────────────────────────────
export async function fetchCompetition() {
  return apiFetch<{ competition: any }>('/competition/current');
}

// ── Payments ──────────────────────────────────────────────────
export async function createStarsInvoice(params: {
  type: 'boost' | 'gift_sent' | 'entry_fee';
  amount: number;
  points: number;
  recipientId?: string;
  message?: string;
  userTelegramId: number;
}) {
  return apiFetch<{ invoiceLink: string }>('/payments/create-invoice', {
    method: 'POST',
    body: JSON.stringify(params)
  });
}

// Open Telegram Stars invoice
export function openStarsInvoice(invoiceLink: string): Promise<'paid' | 'cancelled' | 'failed' | 'pending'> {
  return new Promise((resolve) => {
    const tg = window.Telegram?.WebApp;
    if (!tg) { resolve('cancelled'); return; }
    tg.openInvoice(invoiceLink, (status) => resolve(status));
  });
}

// ── Admin ─────────────────────────────────────────────────────
export async function closeCompetition(adminKey: string) {
  return apiFetch<any>('/competition/close', {
    method: 'POST',
    headers: { 'X-Admin-Key': adminKey }
  });
}

// ── Health ────────────────────────────────────────────────────
export async function checkHealth() {
  return apiFetch<any>('/health');
}
