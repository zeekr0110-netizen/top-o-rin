import React, { useState } from 'react';
import { ScreenType, UserProfile } from '../types';
import { triggerHaptic } from '../services/telegram';

interface ProfileScreenProps {
  user: UserProfile;
  currentUser: UserProfile;
  onNavigate: (screen: ScreenType) => void;
  onSendGiftToThisUser: (user: UserProfile) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  currentUser,
  onNavigate,
  onSendGiftToThisUser,
}) => {
  const [showShareToast, setShowShareToast] = useState(false);

  const isSelf = user.id === currentUser.id;

  const handleShare = () => {
    triggerHaptic('light');
    if (navigator.clipboard) {
      navigator.clipboard.writeText(
        `https://t.me/TopOrinBot/app?startapp=profile_${user.username}`
      ).catch(() => {});
    }
    setShowShareToast(true);
    setTimeout(() => setShowShareToast(false), 2200);
  };

  return (
    <div className="flex flex-col w-full space-y-space-lg max-w-lg mx-auto pb-12 relative">
      {/* Profile Identity Card */}
      <div className="relative overflow-hidden rounded-lg bg-surface-container-high/70 backdrop-blur-xl p-space-lg shadow-[0_12px_40px_rgba(0,0,0,0.55)] border border-white/5">
        {/* Ambient backlight blooms inside card */}
        <div className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-primary-container/25 blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-16 -left-16 w-40 h-40 rounded-full bg-secondary-container/20 blur-3xl pointer-events-none"></div>

        <div className="relative flex flex-col items-center text-center">
          {/* High-res Avatar Card with Violet Halo & Online Badge */}
          <div className="relative mb-space-md">
            <div className="relative w-28 h-28 rounded-full p-[3px] bg-gradient-to-tr from-primary via-secondary to-primary-container shadow-[0_0_28px_rgba(160,120,255,0.45)]">
              <img
                alt={user.fullName}
                className="w-full h-full rounded-full object-cover"
                src={user.avatar}
              />
            </div>
            {/* Status Indicator Pill */}
            {user.isOnline && (
              <div className="absolute bottom-1 right-2 flex items-center gap-1 bg-surface-container-lowest/90 backdrop-blur-md px-2 py-0.5 rounded-full shadow-[0_2px_8px_rgba(0,0,0,0.6)]">
                <span className="w-2 h-2 rounded-full bg-secondary shadow-[0_0_6px_#4cd7f6] animate-pulse"></span>
                <span className="font-label-sm text-label-sm text-secondary font-bold">ONLINE</span>
              </div>
            )}
          </div>

          {/* Identity Meta */}
          <div className="flex items-center gap-1.5 justify-center">
            <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-on-surface font-extrabold">
              {user.fullName}
            </h1>
            {user.isVerified18 && (
              <span
                className="material-symbols-outlined text-secondary text-[20px]"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                verified
              </span>
            )}
          </div>
          <div className="flex items-center gap-1 text-on-surface-variant font-body-sm text-body-sm mt-0.5">
            <span className="material-symbols-outlined text-[16px] text-primary">location_on</span>
            <span>{user.city}</span>
          </div>

          <p className="font-body-md text-body-md text-on-surface-variant mt-space-sm max-w-xs leading-relaxed">
            “{user.bio || 'Cho‘qqilar zabt etish uchun!'}”
          </p>

          {/* Current Rank & Score Showcase Banner */}
          <div className="w-full mt-space-lg grid grid-cols-2 gap-space-sm">
            <div className="flex flex-col items-center justify-center p-space-md rounded-DEFAULT bg-surface-container/80 shadow-md">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold">
                Hozirgi O‘rin
              </span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="font-metric-rank text-metric-rank text-primary font-bold">
                  #{user.rank}
                </span>
                <span className="font-headline-sm text-headline-sm text-on-surface">o‘rinda</span>
              </div>
              <div className="flex items-center gap-0.5 text-secondary font-label-md text-label-md mt-1 font-bold">
                <span className="material-symbols-outlined text-[14px]">trending_up</span>
                <span>+2 pog‘ona bugun</span>
              </div>
            </div>

            <div className="flex flex-col items-center justify-center p-space-md rounded-DEFAULT bg-surface-container/80 shadow-md">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold">
                Umumiy Ball
              </span>
              <div className="flex items-center gap-1 mt-0.5">
                <span className="font-metric-rank text-metric-rank text-tertiary font-bold">
                  {user.points.toLocaleString()}
                </span>
              </div>
              <div className="flex items-center gap-1 text-on-surface-variant font-label-md text-label-md mt-1 font-bold">
                <span
                  className="material-symbols-outlined text-tertiary text-[14px]"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  local_fire_department
                </span>
                <span>Oltin Liga</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Rank Progress Bar to Bronze #3 */}
      <div className="rounded-lg bg-surface-container-high/60 backdrop-blur-lg p-space-md shadow-md flex flex-col gap-space-xs border border-white/5">
        <div className="flex items-center justify-between text-on-surface">
          <div className="flex items-center gap-1.5">
            <span
              className="material-symbols-outlined text-tertiary text-[18px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              military_tech
            </span>
            <span className="font-headline-sm text-headline-sm font-bold">
              3-o‘ringa o‘tish (Bronza)
            </span>
          </div>
          <span className="font-label-md text-label-md text-secondary font-bold">82%</span>
        </div>

        {/* Glowing Progress Track */}
        <div className="w-full h-3 rounded-full bg-surface-container-lowest overflow-hidden p-0.5">
          <div
            className="h-full rounded-full bg-gradient-to-r from-primary via-secondary to-tertiary shadow-[0_0_12px_rgba(76,215,246,0.6)] transition-all duration-700 ease-out"
            style={{ width: '82%' }}
          ></div>
        </div>

        <div className="flex items-center justify-between text-on-surface-variant font-body-sm text-body-sm pt-0.5">
          <span>
            3-o‘ringacha qoldi: <strong className="text-on-surface font-semibold">11,600 ball</strong>
          </span>
          <span className="text-tertiary font-label-md text-label-md font-bold">
            Raqib: Azamat_K (76.4k)
          </span>
        </div>
      </div>

      {/* Stats Grid & Weekly Evolution */}
      <div className="flex flex-col gap-space-sm">
        <div className="flex items-center justify-between px-1">
          <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
            Reyting Tarixi va Statistikasi
          </span>
          <span className="font-label-md text-label-md text-primary font-bold">Oxirgi 7 kun</span>
        </div>

        {/* 4 Key Metrics Bento Grid */}
        <div className="grid grid-cols-2 gap-space-sm">
          <div className="p-space-md rounded-DEFAULT bg-surface-container/70 flex flex-col justify-between shadow-sm border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-label-sm text-label-sm text-on-surface-variant font-medium">
                Haftalik Eng Yuqori
              </span>
              <span className="material-symbols-outlined text-tertiary text-[18px]">
                workspace_premium
              </span>
            </div>
            <div className="mt-space-sm">
              <span className="font-metric-rank text-metric-rank text-tertiary font-bold">
                #{Math.min(user.rank, 2)}
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant ml-1">o‘rin</span>
            </div>
          </div>

          <div className="p-space-md rounded-DEFAULT bg-surface-container/70 flex flex-col justify-between shadow-sm border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-label-sm text-label-sm text-on-surface-variant font-medium">
                Qabul Sovg‘alar
              </span>
              <span className="material-symbols-outlined text-primary text-[18px]">card_giftcard</span>
            </div>
            <div className="mt-space-sm">
              <span className="font-metric-rank text-metric-rank text-on-surface font-bold">
                {user.giftsReceivedCount}
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant ml-1">dona</span>
            </div>
          </div>

          <div className="p-space-md rounded-DEFAULT bg-surface-container/70 flex flex-col justify-between shadow-sm border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-label-sm text-label-sm text-on-surface-variant font-medium">
                Berilgan Ovozlar
              </span>
              <span className="material-symbols-outlined text-secondary text-[18px]">how_to_vote</span>
            </div>
            <div className="mt-space-sm">
              <span className="font-metric-rank text-metric-rank text-secondary font-bold">
                {user.votesCount || 114}
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant ml-1">ovoz</span>
            </div>
          </div>

          <div className="p-space-md rounded-DEFAULT bg-surface-container/70 flex flex-col justify-between shadow-sm border border-white/5">
            <div className="flex items-center justify-between">
              <span className="font-label-sm text-label-sm text-on-surface-variant font-medium">
                Haftalik G‘alaba
              </span>
              <span className="material-symbols-outlined text-tertiary text-[18px]">emoji_events</span>
            </div>
            <div className="mt-space-sm">
              <span className="font-metric-rank text-metric-rank text-tertiary font-bold">
                {user.weeklyWins || 1}
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant ml-1">marta</span>
            </div>
          </div>
        </div>

        {/* Mini Weekly Chart: Mon to Sun */}
        <div className="p-space-md rounded-DEFAULT bg-surface-container/80 flex flex-col gap-space-sm shadow-sm border border-white/5">
          <div className="flex items-center justify-between">
            <span className="font-body-sm text-body-sm text-on-surface font-semibold">
              Pog‘ona o‘zgarishi (Hafta)
            </span>
            <div className="flex items-center gap-1 font-label-sm text-label-sm text-secondary font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
              <span>Yuqori o‘rin = baland ustun</span>
            </div>
          </div>

          {/* Compact CSS Bar Graphic */}
          <div className="flex items-end justify-between h-20 pt-2 px-1">
            <div className="flex flex-col items-center gap-1 flex-1">
              <span className="font-label-sm text-label-sm text-on-surface-variant">#8</span>
              <div className="w-4 rounded-t-full bg-surface-container-highest h-8"></div>
              <span className="font-label-sm text-label-sm text-on-surface-variant">Dsh</span>
            </div>
            <div className="flex flex-col items-center gap-1 flex-1">
              <span className="font-label-sm text-label-sm text-on-surface-variant">#6</span>
              <div className="w-4 rounded-t-full bg-primary-container/60 h-10"></div>
              <span className="font-label-sm text-label-sm text-on-surface-variant">Ssh</span>
            </div>
            <div className="flex flex-col items-center gap-1 flex-1">
              <span className="font-label-sm text-label-sm text-on-surface-variant">#5</span>
              <div className="w-4 rounded-t-full bg-primary-container/80 h-12"></div>
              <span className="font-label-sm text-label-sm text-on-surface-variant">Chr</span>
            </div>
            <div className="flex flex-col items-center gap-1 flex-1">
              <span className="font-label-sm text-label-sm text-tertiary font-bold">#2</span>
              <div className="w-4 rounded-t-full bg-gradient-to-t from-tertiary-container to-tertiary h-16 shadow-[0_0_10px_rgba(255,185,95,0.4)]"></div>
              <span className="font-label-sm text-label-sm text-tertiary font-bold">Pay</span>
            </div>
            <div className="flex flex-col items-center gap-1 flex-1">
              <span className="font-label-sm text-label-sm text-primary font-bold">#3</span>
              <div className="w-4 rounded-t-full bg-primary h-14"></div>
              <span className="font-label-sm text-label-sm text-on-surface-variant">Jum</span>
            </div>
            <div className="flex flex-col items-center gap-1 flex-1">
              <span className="font-label-sm text-label-sm text-on-surface-variant">#5</span>
              <div className="w-4 rounded-t-full bg-primary-container/70 h-12"></div>
              <span className="font-label-sm text-label-sm text-on-surface-variant">Shn</span>
            </div>
            <div className="flex flex-col items-center gap-1 flex-1">
              <span className="font-label-sm text-label-sm text-secondary font-bold">#{user.rank}</span>
              <div className="w-4 rounded-t-full bg-gradient-to-t from-secondary-container to-secondary h-13 shadow-[0_0_10px_rgba(76,215,246,0.35)]"></div>
              <span className="font-label-sm text-label-sm text-secondary font-bold">Yak</span>
            </div>
          </div>
        </div>
      </div>

      {/* Received Virtual Gifts Showcase */}
      <div className="flex flex-col gap-space-sm">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-primary text-[20px]">
              featured_seasonal_and_gifts
            </span>
            <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
              Qabul Qilingan Sovg‘alar
            </span>
          </div>
          <span className="font-label-md text-label-md text-on-surface-variant font-bold">
            Jami {user.giftsReceivedCount} ta
          </span>
        </div>

        {/* Gifts Grid */}
        <div className="grid grid-cols-2 gap-space-sm sm:grid-cols-3">
          <div className="flex flex-col p-space-sm rounded-DEFAULT bg-surface-container-high/60 backdrop-blur-md relative overflow-hidden group border border-white/5">
            <div className="flex items-center justify-between">
              <span aria-label="Oltin Toj" className="text-2xl" role="img">
                👑
              </span>
              <span className="px-2 py-0.5 rounded-full bg-tertiary-container/40 text-tertiary font-label-sm text-label-sm font-bold">
                x3
              </span>
            </div>
            <span className="font-headline-sm text-headline-sm text-on-surface mt-space-xs truncate font-bold">
              Oltin Toj
            </span>
            <span className="font-label-sm text-label-sm text-tertiary mt-0.5 font-bold">+15,000 ball</span>
          </div>

          <div className="flex flex-col p-space-sm rounded-DEFAULT bg-surface-container-high/60 backdrop-blur-md relative overflow-hidden group border border-white/5">
            <div className="flex items-center justify-between">
              <span aria-label="Olmos Yurak" className="text-2xl" role="img">
                💎
              </span>
              <span className="px-2 py-0.5 rounded-full bg-secondary-container/40 text-secondary font-label-sm text-label-sm font-bold">
                x5
              </span>
            </div>
            <span className="font-headline-sm text-headline-sm text-on-surface mt-space-xs truncate font-bold">
              Olmos Yurak
            </span>
            <span className="font-label-sm text-label-sm text-secondary mt-0.5 font-bold">+12,500 ball</span>
          </div>

          <div className="flex flex-col p-space-sm rounded-DEFAULT bg-surface-container-high/60 backdrop-blur-md relative overflow-hidden group border border-white/5">
            <div className="flex items-center justify-between">
              <span aria-label="Afsona Kubogi" className="text-2xl" role="img">
                🏆
              </span>
              <span className="px-2 py-0.5 rounded-full bg-tertiary-container/40 text-tertiary font-label-sm text-label-sm font-bold">
                x1
              </span>
            </div>
            <span className="font-headline-sm text-headline-sm text-on-surface mt-space-xs truncate font-bold">
              Afsona Kubogi
            </span>
            <span className="font-label-sm text-label-sm text-tertiary mt-0.5 font-bold">+10,000 ball</span>
          </div>

          <div className="flex flex-col p-space-sm rounded-DEFAULT bg-surface-container-high/60 backdrop-blur-md relative overflow-hidden group border border-white/5">
            <div className="flex items-center justify-between">
              <span aria-label="Oltin Atirgul" className="text-2xl" role="img">
                🌹
              </span>
              <span className="px-2 py-0.5 rounded-full bg-primary-container/40 text-primary font-label-sm text-label-sm font-bold">
                x8
              </span>
            </div>
            <span className="font-headline-sm text-headline-sm text-on-surface mt-space-xs truncate font-bold">
              Oltin Atirgul
            </span>
            <span className="font-label-sm text-label-sm text-primary mt-0.5 font-bold">+8,000 ball</span>
          </div>

          <div className="col-span-2 sm:col-span-1 flex flex-col p-space-sm rounded-DEFAULT bg-surface-container-high/60 backdrop-blur-md relative overflow-hidden group border border-white/5">
            <div className="flex items-center justify-between">
              <span aria-label="Kosmik Ajdar" className="text-2xl" role="img">
                🐉
              </span>
              <span className="px-2 py-0.5 rounded-full bg-secondary-container/40 text-secondary font-label-sm text-label-sm font-bold">
                x1
              </span>
            </div>
            <span className="font-headline-sm text-headline-sm text-on-surface mt-space-xs truncate font-bold">
              Kosmik Ajdar
            </span>
            <span className="font-label-sm text-label-sm text-secondary mt-0.5 font-bold">+18,000 ball</span>
          </div>
        </div>
      </div>

      {/* Weekly Achievements & Badges */}
      <div className="flex flex-col gap-space-sm">
        <div className="flex items-center justify-between px-1">
          <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
            Yutuqlar va Nishonlar
          </span>
          <span className="font-label-md text-label-md text-primary font-bold">3 ta faol</span>
        </div>
        <div className="grid grid-cols-3 gap-space-xs">
          <div className="flex flex-col items-center text-center p-space-sm rounded-DEFAULT bg-surface-container/70 shadow-sm border border-white/5">
            <div className="w-10 h-10 rounded-full bg-primary-container/30 flex items-center justify-center text-primary mb-1 shadow-[0_0_12px_rgba(160,120,255,0.3)]">
              <span className="material-symbols-outlined text-[22px]">military_tech</span>
            </div>
            <span className="font-label-md text-label-md text-on-surface font-semibold line-clamp-1">
              TOP 10 Fathi
            </span>
            <span className="font-label-sm text-label-sm text-primary font-bold">Elita</span>
          </div>

          <div className="flex flex-col items-center text-center p-space-sm rounded-DEFAULT bg-surface-container/70 shadow-sm border border-white/5">
            <div className="w-10 h-10 rounded-full bg-tertiary-container/30 flex items-center justify-center text-tertiary mb-1 shadow-[0_0_12px_rgba(202,129,0,0.3)]">
              <span
                className="material-symbols-outlined text-[22px]"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                hotel_class
              </span>
            </div>
            <span className="font-label-md text-label-md text-on-surface font-semibold line-clamp-1">
              Hafta Yulduzi
            </span>
            <span className="font-label-sm text-label-sm text-tertiary font-bold">Chempion</span>
          </div>

          <div className="flex flex-col items-center text-center p-space-sm rounded-DEFAULT bg-surface-container/70 shadow-sm border border-white/5">
            <div className="w-10 h-10 rounded-full bg-secondary-container/30 flex items-center justify-center text-secondary mb-1 shadow-[0_0_12px_rgba(3,181,211,0.3)]">
              <span className="material-symbols-outlined text-[22px]">verified</span>
            </div>
            <span className="font-label-md text-label-md text-on-surface font-semibold line-clamp-1">
              Faol 2025
            </span>
            <span className="font-label-sm text-label-sm text-secondary font-bold">Tasdiqlangan</span>
          </div>
        </div>
      </div>

      {/* Action Buttons Bar */}
      <div className="flex items-center gap-space-sm pt-space-xs">
        {isSelf ? (
          <button
            type="button"
            onClick={() => onNavigate('boost')}
            className="flex-1 h-12 rounded-full bg-gradient-to-r from-primary-container via-primary to-secondary text-on-primary font-headline-sm text-headline-sm flex items-center justify-center gap-1.5 shadow-[0_8px_24px_rgba(160,120,255,0.4)] active:scale-[0.98] transition-transform cursor-pointer font-bold"
          >
            <span className="material-symbols-outlined text-[20px]">rocket_launch</span>
            <span>Reytingni ko‘tarish</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => onSendGiftToThisUser(user)}
            className="flex-1 h-12 rounded-full bg-gradient-to-r from-tertiary-container via-tertiary to-primary-container text-on-tertiary-fixed font-headline-sm text-headline-sm flex items-center justify-center gap-1.5 shadow-[0_8px_24px_rgba(202,129,0,0.4)] active:scale-[0.98] transition-transform cursor-pointer font-bold"
          >
            <span className="material-symbols-outlined text-[20px]">featured_seasonal_and_gifts</span>
            <span>Ushbu ishtirokchiga Sovg‘a</span>
          </button>
        )}

        <button
          type="button"
          aria-label="Profilga sovg‘a yuborish"
          onClick={() => {
            onSendGiftToThisUser(user);
            onNavigate('gifts');
          }}
          className="h-12 px-space-md rounded-full bg-surface-container-high/90 hover:bg-surface-container-highest text-primary font-headline-sm text-headline-sm flex items-center justify-center gap-1 shadow-md active:scale-[0.98] transition-transform cursor-pointer font-bold"
        >
          <span className="material-symbols-outlined text-[20px] text-tertiary">card_giftcard</span>
          <span className="hidden xs:inline">Sovg‘a</span>
        </button>

        <button
          type="button"
          id="share-profile-btn"
          aria-label="Ulashish / Share profile"
          onClick={handleShare}
          className="w-12 h-12 rounded-full bg-surface-container-high/90 hover:bg-surface-container-highest text-on-surface flex items-center justify-center shrink-0 shadow-md active:scale-[0.98] transition-transform cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">share</span>
        </button>
      </div>

      {/* Share Toast Feedback */}
      {showShareToast && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 px-space-md py-space-xs bg-surface-container-highest/95 backdrop-blur-md rounded-full shadow-2xl flex items-center gap-2 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200 border border-white/10">
          <span className="material-symbols-outlined text-secondary text-[18px]">check_circle</span>
          <span className="font-body-sm text-body-sm text-on-surface font-semibold">Havola nusxalandi!</span>
        </div>
      )}
    </div>
  );
};
