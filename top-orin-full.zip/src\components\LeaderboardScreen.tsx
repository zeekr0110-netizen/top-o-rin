import React, { useState, useEffect } from 'react';
import { UserProfile, ScreenType, CompetitionConfig } from '../types';

interface LeaderboardScreenProps {
  users: UserProfile[];
  currentUser: UserProfile;
  config: CompetitionConfig;
  onNavigate: (screen: ScreenType) => void;
  onSelectUserForGift: (user: UserProfile) => void;
  onSelectUserForProfile: (user: UserProfile) => void;
  onOpenWeeklyChampion: () => void;
}

export const LeaderboardScreen: React.FC<LeaderboardScreenProps> = ({
  users,
  currentUser,
  config,
  onNavigate,
  onSelectUserForGift,
  onSelectUserForProfile,
  onOpenWeeklyChampion,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'toshkent' | 'viloyatlar' | 'haftalik' | 'oylik'>('all');

  // Live Countdown timer
  const [timeLeft, setTimeLeft] = useState({
    days: 2,
    hours: 14,
    minutes: 14,
    seconds: 28,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Filter users
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.city.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (activeFilter === 'toshkent') {
      return user.city.toLowerCase().includes('toshkent');
    }
    if (activeFilter === 'viloyatlar') {
      return !user.city.toLowerCase().includes('toshkent');
    }
    return true;
  });

  // Podium top 3
  const rank1 = users[0];
  const rank2 = users[1];
  const rank3 = users[2];

  // The rest (ranks 4+)
  const feedUsers = filteredUsers.filter((u) => u.rank > 3);

  // Compute points needed for next position for current user
  const higherUser = users.find((u) => u.rank === currentUser.rank - 1);
  const pointsToNext = higherUser ? Math.max(50, higherUser.points - currentUser.points + 100) : 150;

  return (
    <div className="flex flex-col w-full gap-space-lg relative max-w-lg mx-auto">
      {/* Ambient Light Accents (Cyber-Luxe glow effect) */}
      <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-72 h-36 bg-primary-container/20 blur-[80px] pointer-events-none rounded-full"></div>
      <div className="absolute top-64 right-[-10%] w-48 h-48 bg-secondary-container/15 blur-[70px] pointer-events-none rounded-full"></div>

      {/* Header Banner: Prestige & Slogan */}
      <section className="relative overflow-hidden rounded-lg bg-surface-container-high p-space-lg shadow-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-container/15 via-transparent to-tertiary-container/10 pointer-events-none"></div>
        <div className="relative z-10 flex flex-col items-center text-center gap-space-xs">
          <div className="inline-flex items-center gap-space-xs px-space-md py-space-2xs rounded-full bg-surface-container-highest shadow-sm">
            <span
              className="material-symbols-outlined text-tertiary text-[16px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              workspace_premium
            </span>
            <span className="font-label-sm text-label-sm uppercase tracking-widest text-tertiary">
              Rasmiy VIP Reyting Platformasi
            </span>
          </div>
          <h1 className="font-display-hero-mobile text-display-hero-mobile tracking-tight text-on-surface mt-space-2xs">
            TOP <span className="text-tertiary">O‘RIN</span>
          </h1>
          <p className="font-headline-sm text-headline-sm text-primary-fixed font-semibold tracking-wide">
            “O‘z o‘rningni egalla.”
          </p>
          <p className="font-label-md text-label-md text-on-surface-variant uppercase tracking-widest">
            Reyting • Raqobat • G‘alaba
          </p>
        </div>
      </section>

      {/* Weekly Competition Countdown & Prize Teaser */}
      <section className="relative overflow-hidden rounded-lg bg-surface-container p-space-md shadow-lg flex flex-col gap-space-sm">
        <div className="flex items-center justify-between gap-space-xs">
          <div className="flex items-center gap-space-xs min-w-0">
            <span className="material-symbols-outlined text-secondary animate-pulse text-[20px]">timer</span>
            <span className="font-label-md text-label-md text-on-surface-variant uppercase truncate">
              Haftalik chempionat tugashiga:
            </span>
          </div>
          <div className="font-label-md text-label-md font-bold text-secondary bg-surface-container-highest px-space-sm py-space-2xs rounded-full shadow-inner shrink-0">
            {timeLeft.days}k : {timeLeft.hours}s : {timeLeft.minutes}d
          </div>
        </div>

        <div
          onClick={onOpenWeeklyChampion}
          className="flex items-center justify-between p-space-sm rounded bg-surface-container-highest gap-space-sm cursor-pointer hover:bg-surface-bright transition-colors"
        >
          <div className="flex items-center gap-space-sm min-w-0">
            <div className="w-10 h-10 rounded-full bg-tertiary-container flex items-center justify-center shrink-0 shadow-md">
              <span
                className="material-symbols-outlined text-on-tertiary-container text-[22px]"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                military_tech
              </span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-label-sm text-label-sm uppercase text-tertiary tracking-wider font-bold">
                Hafta g‘olibi yutuqlari
              </span>
              <span className="font-body-md text-body-md text-on-surface font-semibold truncate">
                {config.championshipTrophy} + {config.championshipPrizeStars.toLocaleString()} Telegram Stars
              </span>
            </div>
          </div>
          <button
            aria-label="Sovrin tafsilotlari"
            className="shrink-0 p-space-xs rounded-full bg-surface-container-high text-tertiary hover:bg-tertiary hover:text-on-tertiary transition-colors"
          >
            <span className="material-symbols-outlined text-[20px]">chevron_right</span>
          </button>
        </div>
      </section>

      {/* Top 3 Podium (Cyber-Luxe Spotlight Arena) */}
      <section className="flex flex-col gap-space-md pt-space-xs">
        <div className="flex items-center justify-between px-space-xs">
          <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
            Oltin Uchlik (Top 3)
          </span>
          <span className="font-label-sm text-label-sm uppercase tracking-widest text-primary flex items-center gap-space-2xs">
            <span className="w-2 h-2 rounded-full bg-secondary animate-ping"></span>
            Jonli efir
          </span>
        </div>

        {/* 3-Column Podium Arena */}
        <div className="grid grid-cols-3 gap-space-xs items-end pt-space-xl">
          {/* Rank 2: Silver */}
          {rank2 && (
            <div
              onClick={() => onSelectUserForProfile(rank2)}
              className="flex flex-col items-center bg-surface-container-high rounded-t-lg rounded-b p-space-sm shadow-md relative pt-space-lg cursor-pointer hover:bg-surface-container-highest transition-colors"
            >
              <div className="absolute -top-6 flex flex-col items-center">
                <div className="relative">
                  <img
                    className="w-14 h-14 rounded-full object-cover shadow-lg ring-2 ring-surface-bright"
                    src={rank2.avatar}
                    alt={rank2.fullName}
                  />
                  <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-surface-bright text-on-surface flex items-center justify-center font-metric-rank-sm text-metric-rank-sm font-bold shadow-md">
                    2
                  </span>
                </div>
              </div>
              <div className="text-center mt-space-sm w-full">
                <p className="font-body-sm text-body-sm font-bold text-on-surface truncate">
                  {rank2.fullName}
                </p>
                <span className="font-label-sm text-label-sm text-on-surface-variant flex items-center justify-center gap-space-2xs truncate">
                  <span className="material-symbols-outlined text-[12px]">location_on</span> {rank2.city}
                </span>
                <div className="mt-space-xs py-space-2xs px-space-xs bg-surface-container-highest rounded-full text-center">
                  <p className="font-label-md text-label-md font-bold text-secondary">
                    {rank2.points.toLocaleString()}
                  </p>
                </div>
                <p className="font-label-sm text-label-sm text-on-surface-variant mt-space-2xs">
                  {rank2.giftsReceivedCount} ta sovg‘a
                </p>
              </div>
            </div>
          )}

          {/* Rank 1: Gold Champion - Elevated & Highlighted */}
          {rank1 && (
            <div
              onClick={() => onSelectUserForProfile(rank1)}
              className="flex flex-col items-center bg-surface-container-highest rounded-t-lg rounded-b p-space-sm shadow-2xl relative pt-space-2xl -translate-y-3 shadow-tertiary/20 cursor-pointer border border-tertiary/20 hover:border-tertiary/40 transition-colors"
            >
              <div className="absolute -top-10 flex flex-col items-center">
                <span
                  className="material-symbols-outlined text-tertiary text-[26px] animate-bounce"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  crown
                </span>
                <div className="relative">
                  <img
                    className="w-18 h-18 rounded-full object-cover shadow-xl ring-2 ring-tertiary"
                    src={rank1.avatar}
                    alt={rank1.fullName}
                  />
                  <span className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-tertiary text-on-tertiary flex items-center justify-center font-metric-rank-sm text-metric-rank-sm font-extrabold shadow-md">
                    1
                  </span>
                </div>
              </div>
              <div className="text-center mt-space-md w-full">
                <span className="font-label-sm text-label-sm text-tertiary uppercase font-bold tracking-wider px-space-xs py-space-2xs rounded bg-surface-container-lowest block truncate mb-space-2xs">
                  Hafta yetakchisi 👑
                </span>
                <p className="font-body-md text-body-md font-bold text-on-surface truncate">
                  {rank1.fullName}
                </p>
                <span className="font-label-sm text-label-sm text-on-surface-variant flex items-center justify-center gap-space-2xs truncate">
                  <span className="material-symbols-outlined text-[12px]">location_on</span> {rank1.city}
                </span>
                <div className="mt-space-xs py-space-2xs px-space-xs bg-tertiary-container rounded-full text-center shadow-md">
                  <p className="font-label-md text-label-md font-extrabold text-on-tertiary-container">
                    {rank1.points.toLocaleString()}
                  </p>
                </div>
                <p className="font-label-sm text-label-sm text-tertiary font-bold mt-space-2xs">
                  {rank1.giftsReceivedCount} ta sovg‘a
                </p>
              </div>
            </div>
          )}

          {/* Rank 3: Bronze */}
          {rank3 && (
            <div
              onClick={() => onSelectUserForProfile(rank3)}
              className="flex flex-col items-center bg-surface-container-high rounded-t-lg rounded-b p-space-sm shadow-md relative pt-space-lg cursor-pointer hover:bg-surface-container-highest transition-colors"
            >
              <div className="absolute -top-6 flex flex-col items-center">
                <div className="relative">
                  <img
                    className="w-14 h-14 rounded-full object-cover shadow-lg ring-2 ring-tertiary/40"
                    src={rank3.avatar}
                    alt={rank3.fullName}
                  />
                  <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-surface-bright text-tertiary flex items-center justify-center font-metric-rank-sm text-metric-rank-sm font-bold shadow-md">
                    3
                  </span>
                </div>
              </div>
              <div className="text-center mt-space-sm w-full">
                <p className="font-body-sm text-body-sm font-bold text-on-surface truncate">
                  {rank3.fullName}
                </p>
                <span className="font-label-sm text-label-sm text-on-surface-variant flex items-center justify-center gap-space-2xs truncate">
                  <span className="material-symbols-outlined text-[12px]">location_on</span> {rank3.city}
                </span>
                <div className="mt-space-xs py-space-2xs px-space-xs bg-surface-container-highest rounded-full text-center">
                  <p className="font-label-md text-label-md font-bold text-tertiary">
                    {rank3.points.toLocaleString()}
                  </p>
                </div>
                <p className="font-label-sm text-label-sm text-on-surface-variant mt-space-2xs">
                  {rank3.giftsReceivedCount} ta sovg‘a
                </p>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Filter & Search Controls */}
      <section className="flex flex-col gap-space-sm">
        {/* Search Bar */}
        <div className="relative flex items-center w-full">
          <span className="material-symbols-outlined absolute left-space-md text-outline text-[20px]">
            search
          </span>
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-surface-container-high text-on-surface pl-10 pr-space-md py-space-sm rounded-lg font-body-md text-body-md placeholder:text-outline focus:outline-none focus:bg-surface-container-highest shadow-inner"
            placeholder="Foydalanuvchini qidirish..."
            type="text"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-10 p-1 text-outline hover:text-on-surface"
            >
              <span className="material-symbols-outlined text-[16px]">close</span>
            </button>
          )}
          <button className="absolute right-space-sm p-space-2xs text-outline hover:text-on-surface">
            <span className="material-symbols-outlined text-[18px]">tune</span>
          </button>
        </div>

        {/* Filter Chips Scrollable Row */}
        <div className="flex items-center gap-space-xs overflow-x-auto pb-space-2xs no-scrollbar">
          {(
            [
              { key: 'all', label: 'Barchasi' },
              { key: 'toshkent', label: 'Toshkent' },
              { key: 'viloyatlar', label: 'Viloyatlar' },
              { key: 'haftalik', label: 'Haftalik' },
              { key: 'oylik', label: 'Oylik' },
            ] as const
          ).map((filter) => {
            const isChipActive = activeFilter === filter.key;
            return (
              <button
                key={filter.key}
                onClick={() => setActiveFilter(filter.key)}
                className={`px-space-md py-space-xs rounded-full font-label-md text-label-md shrink-0 transition-all cursor-pointer ${
                  isChipActive
                    ? 'bg-primary-container text-on-primary-container font-bold shadow-md'
                    : 'bg-surface-container-high text-on-surface-variant hover:bg-surface-container-highest'
                }`}
              >
                {filter.label}
              </button>
            );
          })}
        </div>
      </section>

      {/* Leaderboard Feed (Ranks 4+) */}
      <section className="flex flex-col gap-space-sm">
        <div className="flex items-center justify-between px-space-xs">
          <span className="font-headline-sm text-headline-sm text-on-surface">Umumiy Reyting</span>
          <span className="font-label-sm text-label-sm text-outline uppercase font-semibold">
            {users.length.toLocaleString()} Ishtirokchi
          </span>
        </div>

        {feedUsers.length === 0 ? (
          <div className="p-space-lg rounded-lg bg-surface-container text-center text-on-surface-variant">
            Hech qanday ishtirokchi topilmadi.
          </div>
        ) : (
          feedUsers.map((user) => {
            const isSelf = user.id === currentUser.id;
            return (
              <div
                key={user.id}
                className={`flex items-center justify-between p-space-sm rounded-lg bg-surface-container-high shadow-md hover:bg-surface-container-highest transition-colors ${
                  isSelf ? 'border border-primary/40 ring-1 ring-primary/20' : ''
                }`}
              >
                <div
                  onClick={() => onSelectUserForProfile(user)}
                  className="flex items-center gap-space-sm min-w-0 flex-1 cursor-pointer"
                >
                  <span className="font-metric-rank-sm text-metric-rank-sm text-secondary w-6 text-center font-bold">
                    {user.rank}
                  </span>
                  <div className="relative shrink-0">
                    <img
                      className="w-11 h-11 rounded-full object-cover shadow-sm ring-1 ring-surface-bright"
                      src={user.avatar}
                      alt={user.fullName}
                    />
                    {user.isOnline && (
                      <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-secondary ring-1 ring-surface"></span>
                    )}
                  </div>
                  <div className="flex flex-col min-w-0 pr-2">
                    <div className="flex items-center gap-space-2xs">
                      <span className="font-body-md text-body-md font-bold text-on-surface truncate">
                        {user.fullName} {isSelf && '(Siz)'}
                      </span>
                      {user.isVerified18 && (
                        <span
                          className="material-symbols-outlined text-secondary text-[16px]"
                          style={{ fontVariationSettings: "'FILL' 1" }}
                          title="18+ Tasdiqlangan"
                        >
                          verified
                        </span>
                      )}
                    </div>
                    <span className="font-label-sm text-label-sm text-on-surface-variant flex items-center gap-space-2xs truncate">
                      <span className="material-symbols-outlined text-[12px]">location_on</span>
                      {user.city} • {user.giftsReceivedCount} sovg‘a
                    </span>
                  </div>
                </div>

                <div className="flex flex-col items-end shrink-0 gap-space-2xs">
                  <span className="font-label-lg text-label-lg font-bold text-on-surface">
                    {user.points.toLocaleString()}{' '}
                    <span className="font-label-sm text-label-sm text-primary">ball</span>
                  </span>
                  <button
                    onClick={() => onSelectUserForGift(user)}
                    className="flex items-center gap-space-2xs px-space-sm py-space-2xs rounded-full bg-surface-container text-tertiary hover:bg-tertiary-container hover:text-on-tertiary-container text-label-sm font-label-sm transition-all shadow-sm active:scale-95 cursor-pointer"
                  >
                    <span>🎁 Sovg‘a</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </section>

      {/* Sticky Prominent Quick Action Floating Deck */}
      <section className="sticky bottom-2 z-40 flex flex-col gap-space-xs p-space-sm rounded-lg bg-surface-container-lowest/95 backdrop-blur-xl shadow-2xl border border-white/5">
        <div className="flex items-center gap-space-sm w-full">
          {/* Primary Boost Action Button */}
          <button
            onClick={() => onNavigate('boost')}
            className="flex-1 flex items-center justify-center gap-space-xs py-space-sm px-space-md rounded-lg bg-primary-container text-on-primary font-headline-sm text-headline-sm font-bold shadow-lg shadow-primary-container/30 active:scale-98 transition-transform cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px] animate-pulse">rocket_launch</span>
            <span>Reytingni ko‘tarish</span>
          </button>

          {/* Anketa Quick Registration Link */}
          <button
            onClick={() => onNavigate('anketa')}
            className="flex items-center justify-center gap-space-2xs py-space-sm px-space-md rounded-lg bg-surface-container-highest text-primary font-label-lg text-label-lg font-semibold hover:bg-surface-bright active:scale-98 transition-all shrink-0 cursor-pointer"
          >
            <span
              className="material-symbols-outlined text-[18px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              assignment_ind
            </span>
            <span>Anketa (18+)</span>
          </button>
        </div>

        <div className="flex items-center justify-between px-space-xs text-on-surface-variant">
          <span className="font-label-sm text-label-sm">
            Sizning hozirgi o‘rningiz:{' '}
            <strong className="text-secondary font-bold">#{currentUser.rank}</strong>
          </span>
          <span className="font-label-sm text-label-sm">
            Keyingi pog‘onaga:{' '}
            <strong className="text-tertiary font-bold">+{pointsToNext.toLocaleString()} ball</strong>
          </span>
        </div>
      </section>
    </div>
  );
};
