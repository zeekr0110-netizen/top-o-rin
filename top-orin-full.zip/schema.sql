-- ============================================================
-- TOP O'ZBEK - Database Schema
-- Run this in: Supabase Dashboard → SQL Editor
-- ============================================================

-- 1. Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Users Table
CREATE TABLE IF NOT EXISTS public.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    telegram_id BIGINT UNIQUE NOT NULL,
    username TEXT,
    full_name TEXT NOT NULL DEFAULT 'Foydalanuvchi',
    avatar_url TEXT,
    city TEXT DEFAULT 'Toshkent',
    bio TEXT DEFAULT '',
    birth_date DATE,
    is_verified_18 BOOLEAN DEFAULT FALSE,
    points BIGINT DEFAULT 0 CHECK (points >= 0),
    rank INT DEFAULT 999999,
    gifts_received_count INT DEFAULT 0,
    gifts_sent_count INT DEFAULT 0,
    votes_count INT DEFAULT 0,
    weekly_wins INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    is_demo BOOLEAN DEFAULT FALSE,
    interests TEXT[] DEFAULT ARRAY[]::TEXT[],
    badges JSONB DEFAULT '[]'::JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_points ON public.users(points DESC) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON public.users(telegram_id);
CREATE INDEX IF NOT EXISTS idx_users_rank ON public.users(rank) WHERE is_active = TRUE;

-- 3. Gifts Catalog
CREATE TABLE IF NOT EXISTS public.gifts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    uz_name TEXT NOT NULL,
    stars_price INT NOT NULL CHECK (stars_price > 0),
    points_reward BIGINT NOT NULL CHECK (points_reward > 0),
    tier TEXT NOT NULL CHECK (tier IN ('standard', 'rare', 'epic', 'mythic', 'exalted')),
    tier_label TEXT NOT NULL,
    description TEXT DEFAULT '',
    image_url TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Boost Packages
CREATE TABLE IF NOT EXISTS public.boost_packages (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    name_uz TEXT NOT NULL,
    stars_price INT NOT NULL CHECK (stars_price > 0),
    points_reward BIGINT NOT NULL CHECK (points_reward > 0),
    bonus_label TEXT,
    is_popular BOOLEAN DEFAULT FALSE,
    is_mega BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE
);

-- 5. Transactions
CREATE TABLE IF NOT EXISTS public.transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    type TEXT NOT NULL CHECK (type IN ('entry_fee', 'boost', 'gift_sent', 'gift_received')),
    amount_stars BIGINT NOT NULL CHECK (amount_stars >= 0),
    points_awarded BIGINT DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'verified', 'failed', 'refunded')),
    telegram_charge_id TEXT,
    provider_charge_id TEXT,
    recipient_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    message TEXT,
    is_anonymous BOOLEAN DEFAULT FALSE,
    is_demo BOOLEAN DEFAULT FALSE,
    metadata JSONB DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    verified_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_tx_user ON public.transactions(user_id, status);
CREATE INDEX IF NOT EXISTS idx_tx_created ON public.transactions(created_at DESC);

-- 6. Weekly Competitions
CREATE TABLE IF NOT EXISTS public.weekly_competitions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    week_number INT NOT NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    prize_stars BIGINT DEFAULT 50000,
    prize_trophy TEXT DEFAULT '🏆 Oltin Kubok',
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled')),
    winner_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    winner_name TEXT,
    winner_prize_sent BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. App Config
CREATE TABLE IF NOT EXISTS public.app_config (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    description TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- FUNCTIONS
-- ============================================================

-- Recalculate leaderboard ranks
CREATE OR REPLACE FUNCTION public.recalculate_ranks()
RETURNS VOID AS $$
BEGIN
    UPDATE public.users u
    SET rank = r.new_rank, updated_at = NOW()
    FROM (
        SELECT id, ROW_NUMBER() OVER (ORDER BY points DESC, created_at ASC) as new_rank
        FROM public.users WHERE is_active = TRUE
    ) r WHERE u.id = r.id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Verify Telegram Stars transaction
CREATE OR REPLACE FUNCTION public.verify_transaction(
    p_tx_id UUID,
    p_telegram_charge_id TEXT,
    p_is_demo BOOLEAN DEFAULT FALSE
)
RETURNS BOOLEAN AS $$
DECLARE v_tx RECORD;
BEGIN
    SELECT * INTO v_tx FROM public.transactions WHERE id = p_tx_id FOR UPDATE;
    IF NOT FOUND THEN RETURN FALSE; END IF;
    IF v_tx.status = 'verified' THEN RETURN TRUE; END IF;

    UPDATE public.transactions
    SET status = 'verified', telegram_charge_id = p_telegram_charge_id,
        verified_at = NOW(), is_demo = p_is_demo
    WHERE id = p_tx_id;

    IF v_tx.type IN ('entry_fee', 'boost') THEN
        UPDATE public.users SET points = points + v_tx.points_awarded, updated_at = NOW()
        WHERE id = v_tx.user_id;
    ELSIF v_tx.type = 'gift_sent' AND v_tx.recipient_id IS NOT NULL THEN
        UPDATE public.users SET points = points + v_tx.points_awarded,
            gifts_received_count = gifts_received_count + 1, updated_at = NOW()
        WHERE id = v_tx.recipient_id;
        UPDATE public.users SET gifts_sent_count = gifts_sent_count + 1, updated_at = NOW()
        WHERE id = v_tx.user_id;
    END IF;

    PERFORM public.recalculate_ranks();
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Get or create user by telegram_id
CREATE OR REPLACE FUNCTION public.get_or_create_user(
    p_telegram_id BIGINT,
    p_username TEXT,
    p_full_name TEXT,
    p_avatar_url TEXT DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE v_user_id UUID;
BEGIN
    SELECT id INTO v_user_id FROM public.users WHERE telegram_id = p_telegram_id;
    IF FOUND THEN
        UPDATE public.users SET username = COALESCE(p_username, username),
            full_name = COALESCE(p_full_name, full_name),
            avatar_url = COALESCE(p_avatar_url, avatar_url),
            updated_at = NOW()
        WHERE telegram_id = p_telegram_id RETURNING id INTO v_user_id;
        RETURN v_user_id;
    END IF;
    INSERT INTO public.users (telegram_id, username, full_name, avatar_url)
    VALUES (p_telegram_id, COALESCE(p_username, 'user_' || p_telegram_id),
            COALESCE(p_full_name, 'Foydalanuvchi'), p_avatar_url)
    RETURNING id INTO v_user_id;
    RETURN v_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.boost_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.weekly_competitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_config ENABLE ROW LEVEL SECURITY;

-- Users: public read (leaderboard), self update
CREATE POLICY "anyone_read_active_users" ON public.users FOR SELECT USING (is_active = TRUE);
CREATE POLICY "users_update_own" ON public.users FOR UPDATE USING (auth.uid() = id);

-- Catalog: public read
CREATE POLICY "anyone_read_gifts" ON public.gifts FOR SELECT USING (is_active = TRUE);
CREATE POLICY "anyone_read_boosts" ON public.boost_packages FOR SELECT USING (is_active = TRUE);

-- Competitions: public read
CREATE POLICY "anyone_read_competitions" ON public.weekly_competitions FOR SELECT USING (TRUE);

-- Transactions: users read own
CREATE POLICY "users_read_own_tx" ON public.transactions
    FOR SELECT USING (auth.uid() = user_id OR auth.uid() = recipient_id);

-- Transactions: insert pending only (verified only via server)
CREATE POLICY "insert_pending_tx" ON public.transactions
    FOR INSERT WITH CHECK (status = 'pending');

-- ============================================================
-- SEED DATA: Gifts Catalog
-- ============================================================
INSERT INTO public.gifts (id, name, uz_name, stars_price, points_reward, tier, tier_label, description, image_url) VALUES
('gift-golden-rose', 'Golden Rose', 'Oltin Atirgul', 100, 1200, 'standard', 'Standart', 'Nozik oltin gul. Gozallik va hurmat.', NULL),
('gift-phoenix-wings', 'Phoenix Wings', 'Feniks Qanotlari', 300, 4000, 'rare', 'Noyob', 'Qayta tiklanish va galaha ramzi.', NULL),
('gift-diamond-heart', 'Diamond Heart', 'Olmos Yurak', 500, 7000, 'epic', 'Epik', 'Moviy kristal yurak. Qatiyat ramzi.', NULL),
('gift-crown', 'Golden Crown', 'Oltin Toj', 1000, 15000, 'mythic', 'Mifik', 'Zarhal toj. Chempionlar safiga kotaradi.', NULL),
('gift-legend-cup', 'Legend Cup', 'Afsona Kubogi', 2500, 40000, 'mythic', 'Mifik', 'Neon kubok. Galaha yetakchilar uchun.', NULL),
('gift-cosmic-dragon', 'Cosmic Dragon', 'Kosmik Ajdar', 5000, 90000, 'exalted', 'Eksklyuziv', 'Yulduzlar chandan yasalgan afsonaviy ajdarho.', NULL)
ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- SEED DATA: Boost Packages
-- ============================================================
INSERT INTO public.boost_packages (name, name_uz, stars_price, points_reward, bonus_label, is_popular, is_mega) VALUES
('Start Boost', 'Start Boost', 50, 500, NULL, FALSE, FALSE),
('Standard Jump', 'Standart Sakrash', 150, 1800, '+20% Bonus', FALSE, FALSE),
('Super Nitro', 'Super Nitro', 500, 7000, '+40% Bonus', TRUE, FALSE),
('Champion Step', 'Chempionlik Qadami', 1500, 25000, '+65% Mega Bonus', FALSE, TRUE)
ON CONFLICT DO NOTHING;

-- ============================================================
-- SEED DATA: App Config
-- ============================================================
INSERT INTO public.app_config (key, value, description) VALUES
('entry_fee', '{"stars": 250, "points": 1000}', 'Kirish tolovining yulduzcha va ball miqdori'),
('competition', '{"prize_stars": 50000, "trophy": "Oltin Kubok", "reset_on_win": true}', 'Haftalik musobaqa sozlamalari'),
('points_per_star', '{"base": 14}', '1 yulduzcha uchun asosiy ball kursi')
ON CONFLICT (key) DO NOTHING;
