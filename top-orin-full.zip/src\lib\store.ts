/**
 * TOP O'ZBEK — Production Store
 * Uses real API + Supabase instead of localStorage
 */
import { create } from 'zustand';
import {
  verifyTelegramUser,
  fetchLeaderboard,
  fetchGifts,
  fetchBoosts,
  fetchUser,
  fetchTransactions,
  fetchCompetition,
  createStarsInvoice,
  openStarsInvoice,
} from './api';
import { triggerHaptic } from '../services/telegram';

export interface UserProfile {
  id: string;
  telegramId?: number;
  username: string;
  fullName: string;
  avatar: string;
  city: string;
  bio: string;
  points: number;
  rank: number;
  previousRank: number;
  giftsReceivedCount: number;
  giftsSentCount: number;
  weeklyWins: number;
  isOnline: boolean;
  isCurrentUser?: boolean;
  interests: string[];
  badges: any[];
}

export interface GiftItem {
  id: string;
  name: string;
  uzName: string;
  starsPrice: number;
  pointsReward: number;
  tier: string;
  tierLabel: string;
  description: string;
  imageUrl?: string;
  projectedRank: string;
}

export interface BoostPackage {
  id: number;
  name: string;
  name_uz: string;
  stars: number;
  points: number;
  bonusLabel?: string;
  isPopular?: boolean;
  isMega?: boolean;
}

export interface TransactionRecord {
  id: string;
  type: string;
  title: string;
  stars: number;
  points: number;
  timestamp: string;
  status: 'pending' | 'verified' | 'failed';
  senderId?: string;
  recipientId?: string;
  recipientName?: string;
  telegramChargeId?: string;
  isDemo: boolean;
}

interface AppState {
  // App state
  initialized: boolean;
  loading: boolean;
  error: string | null;

  // User
  currentUser: UserProfile | null;
  dbUserId: string | null;

  // Data
  users: UserProfile[];
  gifts: GiftItem[];
  boosts: BoostPackage[];
  transactions: TransactionRecord[];
  competition: any;

  // UI state
  currentScreen: string;
  isDemoMode: boolean;

  // Actions
  init: () => Promise<void>;
  loadLeaderboard: () => Promise<void>;
  loadGifts: () => Promise<void>;
  loadBoosts: () => Promise<void>;
  loadTransactions: () => Promise<void>;
  loadCompetition: () => Promise<void>;

  navigateTo: (screen: string) => void;
  navigateBack: () => void;

  // Payment
  buyBoost: (pkg: BoostPackage) => Promise<void>;
  sendGift: (gift: GiftItem, recipient: UserProfile, message?: string, anonymous?: boolean) => Promise<void>;
  payEntryFee: () => Promise<void>;
}

const screenHistory: string[] = ['leaderboard'];

export const useStore = create<AppState>((set, get) => ({
  initialized: false,
  loading: false,
  error: null,
  currentUser: null,
  dbUserId: null,
  users: [],
  gifts: [],
  boosts: [],
  transactions: [],
  competition: null,
  currentScreen: 'leaderboard',
  isDemoMode: false,

  // ── INIT ────────────────────────────────────────────────────
  init: async () => {
    set({ loading: true, error: null });
    try {
      // Verify Telegram user
      const auth = await verifyTelegramUser();

      const user: UserProfile = {
        id: auth.dbUserId,
        telegramId: auth.user.id,
        username: auth.user.username || `user_${auth.user.id}`,
        fullName: auth.user.firstName || 'Foydalanuvchi',
        avatar: auth.user.photoUrl || '',
        city: 'Toshkent',
        bio: '',
        points: 0,
        rank: 999,
        previousRank: 999,
        giftsReceivedCount: 0,
        giftsSentCount: 0,
        weeklyWins: 0,
        isOnline: true,
        isCurrentUser: true,
        interests: [],
        badges: [],
      };

      set({
        currentUser: user,
        dbUserId: auth.dbUserId,
        initialized: true,
      });

      // Load all data in parallel
      await Promise.all([
        get().loadLeaderboard(),
        get().loadGifts(),
        get().loadBoosts(),
        get().loadTransactions(),
        get().loadCompetition(),
      ]);
    } catch (err: any) {
      console.error('[Store Init Error]', err);
      // If not in Telegram (dev mode), load demo data
      set({ initialized: true, isDemoMode: true });
      await Promise.all([get().loadLeaderboard(), get().loadGifts(), get().loadBoosts()]);
    } finally {
      set({ loading: false });
    }
  },

  // ── LOADERS ─────────────────────────────────────────────────
  loadLeaderboard: async () => {
    try {
      const { users } = await fetchLeaderboard();
      const current = get().currentUser;
      const mapped: UserProfile[] = (users || []).map((u: any) => ({
        id: u.id,
        telegramId: u.telegram_id,
        username: u.username || `user_${u.telegram_id}`,
        fullName: u.full_name,
        avatar: u.avatar_url || '',
        city: u.city || 'Toshkent',
        bio: u.bio || '',
        points: Number(u.points || 0),
        rank: Number(u.rank || 999),
        previousRank: Number(u.previous_rank || 999),
        giftsReceivedCount: Number(u.gifts_received_count || 0),
        giftsSentCount: Number(u.gifts_sent_count || 0),
        weeklyWins: Number(u.weekly_wins || 0),
        isOnline: u.is_online ?? true,
        isCurrentUser: current?.telegramId === u.telegram_id,
        interests: u.interests || [],
        badges: u.badges || [],
      }));

      set({ users: mapped });
    } catch (err) {
      console.error('[Leaderboard Error]', err);
    }
  },

  loadGifts: async () => {
    try {
      const { gifts } = await fetchGifts();
      set({
        gifts: (gifts || []).map((g: any) => ({
          id: g.id,
          name: g.name,
          uzName: g.uz_name,
          starsPrice: g.stars_price,
          pointsReward: g.points_reward,
          tier: g.tier,
          tierLabel: g.tier_label,
          description: g.description || '',
          imageUrl: g.image_url,
          projectedRank: `#${Math.floor(Math.random() * 5 + 1)} O'RIN`,
        }))
      });
    } catch (err) {
      console.error('[Gifts Error]', err);
    }
  },

  loadBoosts: async () => {
    try {
      const { packages } = await fetchBoosts();
      set({
        boosts: (packages || []).map((p: any) => ({
          id: p.id,
          name: p.name,
          name_uz: p.name_uz,
          stars: p.stars_price,
          points: p.points_reward,
          bonusLabel: p.bonus_label,
          isPopular: p.is_popular,
          isMega: p.is_mega,
        }))
      });
    } catch (err) {
      console.error('[Boosts Error]', err);
    }
  },

  loadTransactions: async () => {
    const { currentUser } = get();
    if (!currentUser?.telegramId) return;
    try {
      const { transactions } = await fetchTransactions(currentUser.telegramId);
      set({
        transactions: (transactions || []).map((t: any) => ({
          id: t.id,
          type: t.type,
          title: `${t.amount_stars} ⭐ ${t.type}`,
          stars: t.amount_stars,
          points: t.points_awarded,
          timestamp: new Date(t.created_at).toLocaleDateString('uz-UZ'),
          status: t.status,
          senderId: t.user_id,
          recipientId: t.recipient_id,
          recipientName: t.recipient?.full_name,
          telegramChargeId: t.telegram_charge_id,
          isDemo: t.is_demo,
        }))
      });
    } catch (err) {
      console.error('[Transactions Error]', err);
    }
  },

  loadCompetition: async () => {
    try {
      const { competition } = await fetchCompetition();
      set({ competition });
    } catch (err) {
      console.error('[Competition Error]', err);
    }
  },

  // ── NAVIGATION ──────────────────────────────────────────────
  navigateTo: (screen: string) => {
    triggerHaptic?.('light');
    screenHistory.push(screen);
    set({ currentScreen: screen });
  },

  navigateBack: () => {
    triggerHaptic?.('light');
    if (screenHistory.length > 1) {
      screenHistory.pop();
      set({ currentScreen: screenHistory[screenHistory.length - 1] });
    }
  },

  // ── PAYMENTS ────────────────────────────────────────────────
  buyBoost: async (pkg: BoostPackage) => {
    const { currentUser, loadLeaderboard, loadTransactions } = get();
    if (!currentUser) return;

    try {
      const { invoiceLink } = await createStarsInvoice({
        type: 'boost',
        amount: pkg.stars,
        points: pkg.points,
        userTelegramId: currentUser.telegramId!,
      });

      const status = await openStarsInvoice(invoiceLink);

      if (status === 'paid') {
        triggerHaptic?.('success');
        await Promise.all([loadLeaderboard(), loadTransactions()]);
      } else {
        triggerHaptic?.('error');
      }
    } catch (err: any) {
      console.error('[BuyBoost Error]', err);
      triggerHaptic?.('error');
    }
  },

  sendGift: async (gift, recipient, message, anonymous) => {
    const { currentUser, loadLeaderboard, loadTransactions } = get();
    if (!currentUser) return;

    try {
      const { invoiceLink } = await createStarsInvoice({
        type: 'gift_sent',
        amount: gift.starsPrice,
        points: gift.pointsReward,
        recipientId: recipient.id,
        message,
        userTelegramId: currentUser.telegramId!,
      });

      const status = await openStarsInvoice(invoiceLink);

      if (status === 'paid') {
        triggerHaptic?.('success');
        await Promise.all([loadLeaderboard(), loadTransactions()]);
      } else {
        triggerHaptic?.('error');
      }
    } catch (err: any) {
      console.error('[SendGift Error]', err);
      triggerHaptic?.('error');
    }
  },

  payEntryFee: async () => {
    const { currentUser, loadLeaderboard, loadTransactions } = get();
    if (!currentUser) return;

    try {
      const { invoiceLink } = await createStarsInvoice({
        type: 'entry_fee',
        amount: 250,
        points: 1000,
        userTelegramId: currentUser.telegramId!,
      });

      const status = await openStarsInvoice(invoiceLink);

      if (status === 'paid') {
        triggerHaptic?.('success');
        await Promise.all([loadLeaderboard(), loadTransactions()]);
      } else {
        triggerHaptic?.('error');
      }
    } catch (err: any) {
      console.error('[EntryFee Error]', err);
      triggerHaptic?.('error');
    }
  },
}));
