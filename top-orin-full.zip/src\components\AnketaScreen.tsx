import React, { useState } from 'react';
import { ScreenType, UserProfile } from '../types';
import { triggerHaptic } from '../services/telegram';

interface AnketaScreenProps {
  currentUser: UserProfile;
  onNavigate: (screen: ScreenType) => void;
  onRegister: (data: {
    fullName: string;
    username: string;
    avatar: string;
    city: string;
    bio: string;
    birthDate: string;
    age: number;
    interests: string[];
  }) => void;
}

export const AnketaScreen: React.FC<AnketaScreenProps> = ({
  currentUser,
  onNavigate,
  onRegister,
}) => {
  const [username, setUsername] = useState(
    currentUser.username ? `@${currentUser.username}` : '@islom_karimov'
  );
  const [fullName, setFullName] = useState(currentUser.fullName || 'Islom Karimov');
  const [avatar, setAvatar] = useState(
    currentUser.avatar ||
      'https://lh3.googleusercontent.com/aida-public/AB6AXuAoBBfne1nYxQ0XDnz1vZHiXp8iEet5WYV0vqz4r_-Nn68sK_W1Q_ZNI-YZElFG_0AaaRYRWt_95JI1V0KIes8jhUvCNigjsWXWhJlxbKNMYK9O6fEFdP2dM0vVWmYXiWwBAFdoGmu-urVR93CxTdEH2vntFstNpIGkikPF7mhoEwHx6kZ3znLvxJX06eF0G8oImX32eCJIdK1OgwLsxnKSGioII-vxEuAakZdrcjdrNG8ZY-BggZtsDw'
  );
  const [birthDate, setBirthDate] = useState('1998-08-15');
  const [city, setCity] = useState('Toshkent shahri');
  const [bio, setBio] = useState(
    'Tadbirkor, innovatsiyalar va texnologiyalar ixlosmandi. Har doim cho‘qqiga intilaman!'
  );
  const [interests, setInterests] = useState<string[]>([
    'Biznes',
    'Sport',
    'IT',
    'Sayohat',
    'San\'at',
  ]);
  const [newTagInput, setNewTagInput] = useState('');
  const [isAddingTag, setIsAddingTag] = useState(false);
  const [consentChecked, setConsentChecked] = useState(true);

  // Age calculation
  const calculateAge = (dobString: string): number => {
    try {
      const birth = new Date(dobString);
      const diff = Date.now() - birth.getTime();
      const ageDate = new Date(diff);
      return Math.abs(ageDate.getUTCFullYear() - 1970);
    } catch {
      return 26;
    }
  };

  const age = calculateAge(birthDate);
  const is18Plus = age >= 18;

  const removeTag = (tag: string) => {
    triggerHaptic('light');
    setInterests((prev) => prev.filter((t) => t !== tag));
  };

  const addTag = () => {
    if (newTagInput.trim() && !interests.includes(newTagInput.trim())) {
      triggerHaptic('light');
      setInterests((prev) => [...prev, newTagInput.trim()]);
      setNewTagInput('');
      setIsAddingTag(false);
    }
  };

  const handleProceedToPayment = () => {
    if (!consentChecked) {
      alert('Davom etish uchun 18 yoshdan oshganligingiz va qoidalarga roziligingizni belgilang.');
      return;
    }
    if (!is18Plus) {
      alert('Kechirasiz, TOP O‘RIN platformasi faqat 18 yoshga to‘lgan fuqarolar uchun mo‘ljallangan.');
      return;
    }

    triggerHaptic('medium');
    onRegister({
      fullName,
      username,
      avatar,
      city,
      bio,
      birthDate,
      age,
      interests,
    });

    onNavigate('payment');
  };

  return (
    <div className="relative w-full max-w-lg mx-auto px-margin pt-space-md flex flex-col gap-space-lg pb-28">
      {/* Top Flow Indicator */}
      <div className="flex flex-col gap-space-xs">
        <div className="flex items-center justify-between">
          <span className="inline-flex items-center gap-space-xs px-space-md py-space-2xs rounded-full bg-surface-container-high text-primary font-label-md text-label-md uppercase tracking-wider font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-secondary animate-pulse"></span>
            Qadam 2 / 3
          </span>
          <span className="font-label-sm text-label-sm text-outline uppercase tracking-widest font-bold">
            Shaxsiy ma'lumotlar
          </span>
        </div>

        {/* Segmented Progress Bar */}
        <div className="w-full grid grid-cols-3 gap-space-xs mt-space-xs">
          <div className="h-1.5 rounded-full bg-primary shadow-[0_0_8px_rgba(208,188,255,0.4)]"></div>
          <div className="h-1.5 rounded-full bg-gradient-to-r from-primary to-secondary relative overflow-hidden">
            <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
          </div>
          <div className="h-1.5 rounded-full bg-surface-container-highest"></div>
        </div>

        <div className="mt-space-sm">
          <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-on-surface font-extrabold tracking-tight">
            Anketa to‘ldirish
          </h1>
          <p className="font-body-sm text-body-sm text-on-surface-variant mt-space-2xs">
            TOP O‘RIN ochiq reytingiga qo‘shilish uchun anketani to‘ldiring{' '}
            <span className="text-tertiary font-bold">(Faqat 18 yoshdan kattalar uchun)</span>.
          </p>
        </div>
      </div>

      {/* Main Dynamic Form Panel */}
      <form className="flex flex-col gap-space-lg" onSubmit={(e) => e.preventDefault()}>
        {/* Photo Uploader Section */}
        <div className="bg-surface-container-low rounded-2xl p-space-lg shadow-xl relative overflow-hidden flex flex-col items-center gap-space-md border border-white/5">
          <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-primary/10 blur-2xl pointer-events-none"></div>
          <div className="w-full flex items-center justify-between">
            <span className="font-label-lg text-label-lg text-on-surface font-semibold flex items-center gap-space-xs">
              <span className="material-symbols-outlined text-secondary text-base">photo_camera</span>
              Profil fotosurati
            </span>
            <span className="px-space-sm py-space-2xs rounded-full bg-secondary/15 text-secondary font-label-sm text-label-sm flex items-center gap-space-2xs font-bold">
              <span
                className="material-symbols-outlined text-xs"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                verified
              </span>
              Yuqori sifat
            </span>
          </div>

          <div className="relative group mt-space-xs">
            {/* Championship Glow Ring Outer */}
            <div className="w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-primary via-secondary to-tertiary shadow-[0_0_20px_rgba(76,215,246,0.35)] flex items-center justify-center">
              <div className="w-full h-full rounded-full overflow-hidden bg-surface-container-highest relative">
                <img className="w-full h-full object-cover" src={avatar} alt="Avatar" />
              </div>
            </div>

            {/* Change photo button */}
            <button
              type="button"
              onClick={() => {
                const sampleUrls = [
                  'https://lh3.googleusercontent.com/aida-public/AB6AXuAoBBfne1nYxQ0XDnz1vZHiXp8iEet5WYV0vqz4r_-Nn68sK_W1Q_ZNI-YZElFG_0AaaRYRWt_95JI1V0KIes8jhUvCNigjsWXWhJlxbKNMYK9O6fEFdP2dM0vVWmYXiWwBAFdoGmu-urVR93CxTdEH2vntFstNpIGkikPF7mhoEwHx6kZ3znLvxJX06eF0G8oImX32eCJIdK1OgwLsxnKSGioII-vxEuAakZdrcjdrNG8ZY-BggZtsDw',
                  'https://lh3.googleusercontent.com/aida-public/AB6AXuAv-YIzi77LK3WnOx4Wxepo3BNbF0SPUVO0vlKqLOkvzyUtpQKgPVG7n6AapBoAfiylxpB6Flg7tqXREHW2cKZzLWpNoBMNAJhawr2N0fVWanFZjioxLIVTaN4iPCX2T3pWbFHyQQOsPYNcK-VYtyZ_65nrteZJcuVlhFAcIGkin_CJ-u0pQshQWB3hz-NrKswBi__JrOF5PXzOvZZIuxaeCoYup_MwCCjM5Bihv_iA8lpu6T2hSggMBA',
                  'https://lh3.googleusercontent.com/aida-public/AB6AXuBLBaEXMLnAHkL_B7f4KU-9dbVJAxpX_UKysGVLmBmx8y3u_40A7nBi4DdvRSPRoh_ccMI7dDMAGqsxY9znMHbecih3mdUwCv1mVQRx8MK6QPhmB4-j5sd4YZHEfOQtyPugb6k9lN0X94FC5URvYlu-RpNEwWg9OZsz41s44_JHUvGgSCKo97eDYCzRQ6W29zb14vR_VS435qw03ONmSSeoZgZpirtIaiF9-7RTJA6RIJa2auPqksynVA'
                ];
                const next = sampleUrls[(sampleUrls.indexOf(avatar) + 1) % sampleUrls.length];
                setAvatar(next);
              }}
              aria-label="Rasmni o'zgartirish"
              className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center shadow-lg active:scale-90 transition-transform cursor-pointer"
            >
              <span className="material-symbols-outlined text-sm">edit</span>
            </button>
          </div>

          <p className="font-body-sm text-body-sm text-on-surface-variant text-center max-w-xs">
            Raqobatchilar sizni reyting shohsupasida shu rasm orqali tanishadi.
          </p>
        </div>

        {/* Full Name */}
        <div className="flex flex-col gap-space-xs">
          <label className="font-label-lg text-label-lg text-on-surface font-semibold" htmlFor="fullname_field">
            To‘liq ism-familiya
          </label>
          <div className="relative flex items-center">
            <input
              id="fullname_field"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full h-12 rounded-xl bg-surface-container px-space-md pl-11 text-on-surface font-body-md text-body-md focus:outline-none focus:bg-surface-container-high transition-colors shadow-inner"
              placeholder="Ism Familiya"
            />
            <span className="material-symbols-outlined absolute left-3.5 text-outline text-lg pointer-events-none">
              badge
            </span>
          </div>
        </div>

        {/* Field 1: Username Input */}
        <div className="flex flex-col gap-space-xs">
          <label
            className="font-label-lg text-label-lg text-on-surface font-semibold flex items-center justify-between"
            htmlFor="username_field"
          >
            <span>Ko‘rinadigan ism / Taxallus</span>
            <span className="text-secondary font-label-sm text-label-sm font-bold">Band emas</span>
          </label>
          <div className="relative flex items-center">
            <input
              id="username_field"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full h-12 rounded-xl bg-surface-container px-space-md pl-11 text-on-surface font-body-md text-body-md focus:outline-none focus:bg-surface-container-high transition-colors shadow-inner"
              placeholder="@username"
            />
            <span className="material-symbols-outlined absolute left-3.5 text-outline text-lg pointer-events-none">
              alternate_email
            </span>
            <span
              className="material-symbols-outlined absolute right-3.5 text-secondary text-lg pointer-events-none"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              check_circle
            </span>
          </div>
        </div>

        {/* Field 2: Date of Birth & 18+ Verification Tag */}
        <div className="flex flex-col gap-space-xs">
          <label className="font-label-lg text-label-lg text-on-surface font-semibold" htmlFor="dob_field">
            Tug‘ilgan sana
          </label>
          <div className="relative flex items-center">
            <input
              id="dob_field"
              type="date"
              value={birthDate}
              onChange={(e) => setBirthDate(e.target.value)}
              className="w-full h-12 rounded-xl bg-surface-container px-space-md pl-11 text-on-surface font-body-md text-body-md focus:outline-none shadow-inner cursor-pointer"
            />
            <span className="material-symbols-outlined absolute left-3.5 text-outline text-lg pointer-events-none">
              calendar_today
            </span>
          </div>
          {/* Adult Verification Badge */}
          <div className="mt-space-2xs flex items-center gap-space-xs px-space-md py-space-xs rounded-xl bg-surface-container-low shadow-sm border border-white/5">
            <div className="w-5 h-5 rounded-full bg-secondary/20 flex items-center justify-center shrink-0">
              <span
                className="material-symbols-outlined text-secondary text-sm"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                verified_user
              </span>
            </div>
            <span className="font-label-sm text-label-sm text-secondary font-bold tracking-wide">
              {is18Plus
                ? `18 yoshdan oshganligi tasdiqlandi (${age} yosh)`
                : `18 yoshga yetmagan (${age} yosh)`}
            </span>
          </div>
        </div>

        {/* Field 3: City / Region Selector */}
        <div className="flex flex-col gap-space-xs">
          <label className="font-label-lg text-label-lg text-on-surface font-semibold" htmlFor="city_field">
            Shahar / Hudud
          </label>
          <div className="relative flex items-center">
            <select
              id="city_field"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="w-full h-12 rounded-xl bg-surface-container px-space-md pl-11 pr-10 text-on-surface font-body-md text-body-md focus:outline-none shadow-inner cursor-pointer appearance-none"
            >
              <option value="Toshkent shahri">Toshkent shahri</option>
              <option value="Samarqand">Samarqand viloyati</option>
              <option value="Buxoro">Buxoro viloyati</option>
              <option value="Andijon">Andijon viloyati</option>
              <option value="Farg‘ona">Farg‘ona viloyati</option>
              <option value="Namangan">Namangan viloyati</option>
              <option value="Xorazm">Xorazm viloyati</option>
              <option value="Qashqadaryo">Qashqadaryo viloyati</option>
              <option value="Surxondaryo">Surxondaryo viloyati</option>
              <option value="Navoiy">Navoiy viloyati</option>
              <option value="Jizzax">Jizzax viloyati</option>
              <option value="Sirdaryo">Sirdaryo viloyati</option>
              <option value="Qoraqalpog‘iston">Qoraqalpog‘iston Respublikasi</option>
            </select>
            <span className="material-symbols-outlined absolute left-3.5 text-tertiary text-lg pointer-events-none">
              location_on
            </span>
            <span className="material-symbols-outlined absolute right-3.5 text-outline text-lg pointer-events-none">
              unfold_more
            </span>
          </div>
        </div>

        {/* Field 4: Bio / About */}
        <div className="flex flex-col gap-space-xs">
          <div className="flex items-center justify-between">
            <label className="font-label-lg text-label-lg text-on-surface font-semibold" htmlFor="bio_field">
              Qisqacha o‘zingiz haqingizda
            </label>
            <span className="font-label-sm text-label-sm text-outline">
              {bio.length} / 150
            </span>
          </div>
          <div className="relative">
            <textarea
              id="bio_field"
              maxLength={150}
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full rounded-xl bg-surface-container p-space-md text-on-surface font-body-md text-body-md focus:outline-none focus:bg-surface-container-high transition-colors resize-none shadow-inner"
              placeholder="O'zingiz haqingizda yozing..."
            />
          </div>
        </div>

        {/* Field 5: Interests Chips */}
        <div className="flex flex-col gap-space-xs">
          <label className="font-label-lg text-label-lg text-on-surface font-semibold flex items-center justify-between">
            <span>Qiziqishlar va Sohalar</span>
            <span className="font-label-sm text-label-sm text-outline">
              Tanlandi: {interests.length}
            </span>
          </label>
          <div className="flex flex-wrap gap-space-xs mt-space-2xs">
            {interests.map((item, idx) => (
              <button
                key={item}
                type="button"
                onClick={() => removeTag(item)}
                className={`px-space-md py-space-xs rounded-full font-label-md text-label-md font-bold shadow-md active:scale-95 transition-all flex items-center gap-space-2xs cursor-pointer ${
                  idx % 3 === 0
                    ? 'bg-primary text-on-primary'
                    : idx % 3 === 1
                    ? 'bg-secondary text-on-secondary'
                    : 'bg-tertiary-container text-on-tertiary'
                }`}
              >
                <span>#{item}</span>
                <span className="material-symbols-outlined text-xs">close</span>
              </button>
            ))}

            {isAddingTag ? (
              <div className="flex items-center gap-1 bg-surface-container-high rounded-full px-2 py-1">
                <input
                  type="text"
                  value={newTagInput}
                  onChange={(e) => setNewTagInput(e.target.value)}
                  placeholder="Yangi soha..."
                  className="bg-transparent text-xs text-on-surface outline-none w-24 px-1"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addTag();
                    }
                  }}
                />
                <button
                  type="button"
                  onClick={addTag}
                  className="text-secondary text-xs font-bold"
                >
                  ✓
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setIsAddingTag(true)}
                className="px-space-md py-space-xs rounded-full bg-surface-container-high text-on-surface-variant font-label-md text-label-md hover:text-on-surface active:scale-95 transition-all flex items-center gap-space-2xs cursor-pointer"
              >
                <span className="material-symbols-outlined text-sm">add</span>
                <span>Qo‘shish</span>
              </button>
            )}
          </div>
        </div>

        {/* Public Profile Mini Preview Card */}
        <div className="flex flex-col gap-space-xs mt-space-sm">
          <span className="font-label-sm text-label-sm text-outline uppercase tracking-wider flex items-center gap-space-2xs font-bold">
            <span className="material-symbols-outlined text-sm">visibility</span>
            Jonli reytingdagi ko‘rinishingiz
          </span>

          <div className="p-space-md rounded-2xl bg-surface-container-high shadow-xl relative overflow-hidden flex items-center justify-between border border-white/5">
            <div className="absolute -left-10 -bottom-10 w-24 h-24 rounded-full bg-secondary/10 blur-xl pointer-events-none"></div>
            <div className="flex items-center gap-space-md min-w-0">
              {/* Rank Preview Badge */}
              <div className="w-9 h-9 rounded-xl bg-surface-container-lowest flex items-center justify-center shrink-0 shadow-inner">
                <span className="font-metric-rank-sm text-metric-rank-sm text-secondary font-bold">
                  #--
                </span>
              </div>
              {/* Avatar */}
              <div className="w-11 h-11 rounded-full overflow-hidden bg-surface-container-highest shrink-0 shadow-md ring-1 ring-primary/30">
                <img className="w-full h-full object-cover" src={avatar} alt="Preview Avatar" />
              </div>
              {/* Meta Text */}
              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-space-2xs">
                  <span className="font-headline-sm text-headline-sm text-on-surface truncate font-bold">
                    {username}
                  </span>
                  <span
                    className="material-symbols-outlined text-secondary text-sm"
                    style={{ fontVariationSettings: "'FILL' 1" }}
                  >
                    shield
                  </span>
                </div>
                <span className="font-body-sm text-body-sm text-on-surface-variant truncate">
                  {city} • Oltin Liga da'vogari
                </span>
              </div>
            </div>

            {/* Points / Status Badge */}
            <div className="shrink-0 pl-space-sm text-right">
              <div className="px-space-sm py-space-2xs rounded-lg bg-surface-container-lowest flex items-center gap-space-2xs">
                <span
                  className="material-symbols-outlined text-tertiary text-sm"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  local_fire_department
                </span>
                <span className="font-label-md text-label-md text-on-surface font-bold">0 Ball</span>
              </div>
            </div>
          </div>
        </div>

        {/* Legal & Privacy Consent Checkbox */}
        <label className="flex items-start gap-space-md mt-space-xs cursor-pointer select-none group">
          <div className="relative flex items-center justify-center shrink-0 mt-0.5">
            <input
              type="checkbox"
              id="consent_checkbox"
              checked={consentChecked}
              onChange={(e) => setConsentChecked(e.target.checked)}
              className="peer appearance-none w-5 h-5 rounded-md bg-surface-container-highest checked:bg-primary transition-all cursor-pointer shadow-sm border border-outline/30"
            />
            <span className="material-symbols-outlined text-on-primary text-sm font-bold absolute pointer-events-none opacity-0 peer-checked:opacity-100 transition-opacity">
              check
            </span>
          </div>
          <span className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
            Men 18 yoshga to‘lganimni va profilim umumiy <strong className="text-on-surface">TOP O‘RIN</strong> reytingida ochiq ko‘rinishiga rozilik bildiraman.
          </span>
        </label>

        {/* CTA Action Area */}
        <div className="pt-space-md pb-space-lg flex flex-col gap-space-xs">
          <button
            id="submit_btn"
            type="button"
            onClick={handleProceedToPayment}
            className="w-full h-14 rounded-2xl bg-gradient-to-r from-primary via-primary-container to-secondary text-on-primary font-headline-sm text-headline-sm font-bold tracking-wide shadow-[0_8px_24px_rgba(160,120,255,0.35)] active:scale-[0.98] transition-transform flex items-center justify-center gap-space-sm cursor-pointer"
          >
            <span>Davom etish va To‘lovga o‘tish</span>
            <span className="material-symbols-outlined text-xl">arrow_forward</span>
          </button>
          <p className="font-label-sm text-label-sm text-outline text-center">
            Keyingi bosqichda liga ishtirok to‘lovi amalga oshiriladi
          </p>
        </div>
      </form>
    </div>
  );
};
