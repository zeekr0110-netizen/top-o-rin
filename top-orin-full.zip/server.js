// ============================================================
// TOP O'ZBEK - Backend Server
// Express + Telegram Stars + Supabase + Weekly Competition
// ============================================================

const express = require('express');
const crypto = require('crypto');
const path = require('path');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(express.json());

// ============================================================
// ENV CONFIG
// ============================================================
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '8726788315:AAFH4Q4DdJ_b3P1TWp9Np9azr2urcHlAeVI';
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://qidrzcvbzcoyrspnktzp.supabase.co';
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;
const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';

// Initialize Supabase admin (service role - server-side only)
const supabaseAdmin = SUPABASE_SERVICE_KEY
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, { auth: { persistSession: false } })
  : null;

console.log(`[TOP O'ZBEK] Server starting...`);
console.log(`[TOP O'ZBEK] Supabase: ${SUPABASE_URL}`);
console.log(`[TOP O'ZBEK] Telegram Bot: ${TELEGRAM_BOT_TOKEN.slice(0, 10)}...`);
console.log(`[TOP O'ZBEK] Supabase Admin: ${supabaseAdmin ? 'CONNECTED' : 'NOT SET (read-only mode)'}`);

// ============================================================
// TELEGRAM UTILS
// ============================================================

// Verify Telegram Mini App initData (HMAC-SHA256)
function verifyInitData(initData, botToken) {
  try {
    const params = new URLSearchParams(initData);
    const hash = params.get('hash');
    if (!hash) return { valid: false, user: null };
    params.delete('hash');
    const dataCheckString = Array.from(params.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => `${k}=${v}`).join('\n');
    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
    const calculatedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
    const userJson = params.get('user');
    return {
      valid: calculatedHash === hash,
      user: userJson ? JSON.parse(userJson) : null
    };
  } catch { return { valid: false, user: null }; }
}

// Telegram Bot API call helper
async function telegramApi(method, body) {
  const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  return res.json();
}

// ============================================================
// MIDDLEWARE: Auth
// ============================================================

// Verify Telegram user from initData
async function authTelegramUser(req, res, next) {
  const initData = req.headers['x-telegram-init-data'];
  if (!initData) return res.status(401).json({ error: 'No initData' });

  const { valid, user } = verifyInitData(initData, TELEGRAM_BOT_TOKEN);
  if (!valid && NODE_ENV !== 'development') {
    return res.status(401).json({ error: 'Invalid initData signature' });
  }

  // Get or create user in Supabase
  if (supabaseAdmin && user) {
    const { data } = await supabaseAdmin.rpc('get_or_create_user', {
      p_telegram_id: user.id,
      p_username: user.username || null,
      p_full_name: `${user.first_name || ''} ${user.last_name || ''}`.trim(),
      p_avatar_url: user.photo_url || null
    });
    req.dbUserId = data;
  }

  req.telegramUser = user;
  next();
}

// ============================================================
// API: HEALTH CHECK
// ============================================================
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    name: "TOP O'ZBEK",
    version: '1.0.0',
    supabaseConnected: !!supabaseAdmin,
    telegramBotConfigured: !!TELEGRAM_BOT_TOKEN,
    time: new Date().toISOString()
  });
});

// ============================================================
// API: TELEGRAM VERIFY
// ============================================================
app.post('/api/auth/telegram-verify', async (req, res) => {
  const { initData } = req.body;
  if (!initData) return res.status(400).json({ error: 'initData required' });

  const { valid, user } = verifyInitData(initData, TELEGRAM_BOT_TOKEN);

  if (!valid && NODE_ENV !== 'development') {
    return res.status(401).json({ verified: false, error: 'Invalid signature' });
  }

  // Parse user without full verification in dev mode
  const params = new URLSearchParams(initData);
  const userJson = params.get('user');
  const rawUser = userJson ? JSON.parse(userJson) : null;
  const resolvedUser = user || rawUser;

  if (!resolvedUser) return res.status(400).json({ verified: false, error: 'No user data' });

  // Upsert user in Supabase
  let dbUserId = null;
  if (supabaseAdmin) {
    const result = await supabaseAdmin.rpc('get_or_create_user', {
      p_telegram_id: resolvedUser.id,
      p_username: resolvedUser.username || null,
      p_full_name: `${resolvedUser.first_name || ''} ${resolvedUser.last_name || ''}`.trim(),
      p_avatar_url: resolvedUser.photo_url || null
    });
    dbUserId = result.data;
  }

  return res.json({
    verified: true,
    dbUserId,
    user: {
      id: resolvedUser.id,
      username: resolvedUser.username,
      firstName: resolvedUser.first_name,
      lastName: resolvedUser.last_name,
      photoUrl: resolvedUser.photo_url,
      languageCode: resolvedUser.language_code
    }
  });
});

// ============================================================
// API: LEADERBOARD
// ============================================================
app.get('/api/leaderboard', async (req, res) => {
  if (!supabaseAdmin) return res.status(503).json({ error: 'Database not configured' });

  const { data, error } = await supabaseAdmin
    .from('users')
    .select('*')
    .eq('is_active', true)
    .order('points', { ascending: false })
    .limit(100);

  if (error) return res.status(500).json({ error: error.message });

  const leaderboard = (data || []).map((u, i) => ({
    ...u,
    rank: i + 1,
    previousRank: u.rank || i + 1
  }));

  return res.json({ users: leaderboard });
});

// ============================================================
// API: GIFTS CATALOG
// ============================================================
app.get('/api/gifts', async (req, res) => {
  if (!supabaseAdmin) return res.status(503).json({ error: 'Database not configured' });

  const { data, error } = await supabaseAdmin
    .from('gifts')
    .select('*')
    .eq('is_active', true)
    .order('stars_price', { ascending: true });

  if (error) return res.status(500).json({ error: error.message });
  return res.json({ gifts: data || [] });
});

// ============================================================
// API: BOOST PACKAGES
// ============================================================
app.get('/api/boosts', async (req, res) => {
  if (!supabaseAdmin) return res.status(503).json({ error: 'Database not configured' });

  const { data, error } = await supabaseAdmin
    .from('boost_packages')
    .select('*')
    .eq('is_active', true)
    .order('stars_price', { ascending: true });

  if (error) return res.status(500).json({ error: error.message });
  return res.json({ packages: data || [] });
});

// ============================================================
// API: USER PROFILE
// ============================================================
app.get('/api/user/:telegramId', async (req, res) => {
  if (!supabaseAdmin) return res.status(503).json({ error: 'Database not configured' });

  const { data, error } = await supabaseAdmin
    .from('users')
    .select('*')
    .eq('telegram_id', parseInt(req.params.telegramId))
    .single();

  if (error) return res.status(404).json({ error: 'User not found' });
  return res.json({ user: data });
});

// ============================================================
// API: CREATE STARS INVOICE
// ============================================================
app.post('/api/payments/create-invoice', async (req, res) => {
  const { type, amount, points, recipientId, message, userTelegramId } = req.body;

  if (!amount || amount < 1) return res.status(400).json({ error: 'Invalid amount' });

  // Create invoice via Telegram Bot API
  const titleMap = {
    boost: '🚀 Ball oshirish',
    gift_sent: '🎁 Sovga yuborish',
    entry_fee: '📋 Roʻyxatdan oʻtish'
  };

  const descriptionMap = {
    boost: `${points} ball oshirish uchun`,
    gift_sent: `Doʻstingizga sovga — ${points} ball`,
    entry_fee: 'TOP OʻRIN reytingida ishtirok etish'
  };

  try {
    const payload = JSON.stringify({
      type,
      userTelegramId,
      recipientId,
      message,
      ts: Date.now()
    });

    const result = await telegramApi('createInvoiceLink', {
      title: titleMap[type] || 'TOP OʻRIN toʻlovi',
      description: descriptionMap[type] || 'TOP OʻRIN xizmati uchun toʻlovi',
      payload,
      provider_token: '', // Empty = Telegram Stars (XTR)
      currency: 'XTR',
      prices: [{ label: titleMap[type] || 'Stars', amount }]
    });

    if (!result.ok) return res.status(400).json({ error: result.description || 'Invoice failed' });

    // Create pending transaction in DB
    if (supabaseAdmin) {
      const { data: userData } = await supabaseAdmin
        .from('users').select('id').eq('telegram_id', parseInt(userTelegramId)).single();

      if (userData) {
        await supabaseAdmin.from('transactions').insert({
          user_id: userData.id,
          type,
          amount_stars: amount,
          points_awarded: points || 0,
          status: 'pending',
          recipient_id: recipientId || null,
          message: message || null
        });
      }
    }

    return res.json({ invoiceLink: result.result });
  } catch (err) {
    console.error('[Invoice Error]', err);
    return res.status(500).json({ error: 'Failed to create invoice' });
  }
});

// ============================================================
// API: GET USER TRANSACTIONS
// ============================================================
app.get('/api/transactions/:telegramId', async (req, res) => {
  if (!supabaseAdmin) return res.status(503).json({ error: 'Database not configured' });

  const telegramId = parseInt(req.params.telegramId);

  const { data: userData } = await supabaseAdmin
    .from('users').select('id').eq('telegram_id', telegramId).single();

  if (!userData) return res.json({ transactions: [] });

  const { data, error } = await supabaseAdmin
    .from('transactions')
    .select('*, sender:user_id(full_name, username), recipient:recipient_id(full_name, username)')
    .or(`user_id.eq.${userData.id},recipient_id.eq.${userData.id}`)
    .order('created_at', { ascending: false })
    .limit(50);

  if (error) return res.status(500).json({ error: error.message });
  return res.json({ transactions: data || [] });
});

// ============================================================
// API: COMPETITION STATUS
// ============================================================
app.get('/api/competition/current', async (req, res) => {
  if (!supabaseAdmin) return res.status(503).json({ error: 'Database not configured' });

  const { data, error } = await supabaseAdmin
    .from('weekly_competitions')
    .select('*, winner:winner_id(full_name, username, avatar_url)')
    .eq('status', 'active')
    .single();

  if (error && error.code !== 'PGRST116') return res.status(500).json({ error: error.message });
  return res.json({ competition: data || null });
});

// ============================================================
// API: WEEKLY COMPETITION — CLOSE & PAY WINNER
// ============================================================
app.post('/api/competition/close', async (req, res) => {
  if (!supabaseAdmin) return res.status(503).json({ error: 'Database not configured' });

  // Find active competition
  const { data: comp } = await supabaseAdmin
    .from('weekly_competitions')
    .select('*')
    .eq('status', 'active')
    .single();

  if (!comp) return res.status(404).json({ error: 'No active competition found' });

  // Find top user
  const { data: users } = await supabaseAdmin
    .from('users')
    .select('id, telegram_id, full_name, username, points')
    .eq('is_active', true)
    .order('points', { ascending: false })
    .limit(1);

  const winner = users?.[0];
  if (!winner) return res.status(404).json({ error: 'No users found' });

  // Update competition
  await supabaseAdmin
    .from('weekly_competitions')
    .update({
      status: 'completed',
      winner_id: winner.id,
      winner_name: winner.full_name
    })
    .eq('id', comp.id);

  // Mark winner's weekly win
  await supabaseAdmin
    .from('users')
    .update({ weekly_wins: supabaseAdmin.sql`weekly_wins + 1` })
    .eq('id', winner.id);

  // Send prize Stars to winner via Telegram Bot
  let prizeSent = false;
  let prizeError = null;

  try {
    // Get config for prize amount
    const { data: configData } = await supabaseAdmin
      .from('app_config').select('value').eq('key', 'competition').single();

    const prizeStars = configData?.value?.prize_stars || 50000;

    // Send Stars via Telegram Bot
    const sendResult = await telegramApi('sendStars', {
      user_id: winner.telegram_id,
      amount: prizeStars,
      caption: `🏆 Tabriklayman! Siz TOP O'ZBEK haftalik chempionisiz! ${prizeStars} ⭐ sizning hisobingizga tushdi!`
    });

    if (sendResult.ok) {
      prizeSent = true;
      await supabaseAdmin
        .from('weekly_competitions')
        .update({ winner_prize_sent: true })
        .eq('id', comp.id);
    } else {
      prizeError = sendResult.description;
    }
  } catch (err) {
    prizeError = err.message;
  }

  // Reset points for new round (optional — controlled by config)
  const { data: configData } = await supabaseAdmin
    .from('app_config').select('value').eq('key', 'competition').single();

  if (configData?.value?.reset_on_win) {
    await supabaseAdmin
      .from('users')
      .update({ points: 0 })
      .eq('is_active', true)
      .neq('id', winner.id);

    await supabaseAdmin.rpc('recalculate_ranks');
  }

  // Create new competition round
  const now = new Date();
  const nextSunday = new Date(now);
  nextSunday.setDate(now.getDate() + (7 - now.getDay() || 7));
  nextSunday.setHours(23, 59, 59, 0);

  const { data: configData2 } = await supabaseAdmin
    .from('app_config').select('value').eq('key', 'competition').single();

  await supabaseAdmin.from('weekly_competitions').insert({
    week_number: (comp.week_number || 0) + 1,
    start_time: new Date().toISOString(),
    end_time: nextSunday.toISOString(),
    prize_stars: configData2?.value?.prize_stars || 50000,
    prize_trophy: configData2?.value?.trophy || '🏆 Oltin Kubok',
    status: 'active'
  });

  // Notify winner
  if (winner.telegram_id) {
    await telegramApi('sendMessage', {
      chat_id: winner.telegram_id,
      text: `🏆 TABRIKLAYMIZ!\n\nSiz haftalik musobaqada g'olib bo'ldingiz!\n${configData2?.value?.prize_stars || 50000} ⭐ sizning hisobingizga tushdi!\n\nYangi hafta boshlandi — yana kurashni boshleng!`
    });
  }

  return res.json({
    success: true,
    winner: { name: winner.full_name, username: winner.username, points: winner.points },
    prizeSent,
    prizeError,
    newRoundStarted: true
  });
});

// ============================================================
// API: MANUAL COMPETITION CLOSE (Admin)
// ============================================================
app.post('/api/admin/competition/close', async (req, res) => {
  // Simple admin key check
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== process.env.ADMIN_SECRET && adminKey !== 'top-orin-admin-2025') {
    return res.status(403).json({ error: 'Forbidden' });
  }
  req.url = '/api/competition/close';
  return app._router.handle(req, res);
});

// ============================================================
// TELEGRAM WEBHOOK
// ============================================================
app.post('/api/telegram/webhook', async (req, res) => {
  const update = req.body;

  // Answer pre_checkout_query within 10 seconds
  if (update.pre_checkout_query) {
    await telegramApi('answerPreCheckoutQuery', {
      pre_checkout_query_id: update.pre_checkout_query.id,
      ok: true
    });
    return res.json({ ok: true });
  }

  // Handle successful_payment
  const msg = update.message || update.edited_message;
  if (msg?.successful_payment && supabaseAdmin) {
    const payment = msg.successful_payment;
    const chargeId = payment.telegram_payment_charge_id;

    let payload = {};
    try { payload = JSON.parse(payment.invoice_payload); } catch {}

    // Find pending transaction
    const { data: pendingTx } = await supabaseAdmin
      .from('transactions')
      .select('id, user_id, type, points_awarded, recipient_id')
      .eq('user_id', payload.dbUserId || msg.from.id)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })
      .limit(1);

    if (pendingTx?.[0]) {
      await supabaseAdmin.rpc('verify_transaction', {
        p_tx_id: pendingTx[0].id,
        p_telegram_charge_id: chargeId,
        p_is_demo: false
      });
      console.log(`[Payment] Verified tx ${pendingTx[0].id} for user ${pendingTx[0].user_id}`);
    }
  }

  // Handle callback_query from inline buttons
  if (update.callback_query) {
    const cb = update.callback_query;
    const data = cb.data;

    if (data === 'close_comp') {
      // Trigger competition close
      req.url = '/api/competition/close';
      return app._router.handle(req, res);
    }

    await telegramApi('answerCallbackQuery', { callback_query_id: cb.id });
  }

  return res.json({ ok: true });
});

// ============================================================
// STATIC FILES (Production)
// ============================================================
if (NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  });
}

// ============================================================
// START
// ============================================================
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🚀 TOP O'ZBEK server running on port ${PORT}`);
  console.log(`🌐 Environment: ${NODE_ENV}`);
  console.log(`⏰ Started at: ${new Date().toISOString()}\n`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[TOP OZBEK] Shutting down...');
  server.close(() => process.exit(0));
});
