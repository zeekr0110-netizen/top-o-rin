import React, { useState } from 'react';
import { GiftItem, ScreenType, UserProfile } from '../types';
import { GIFTS_CATALOG } from '../config/appConfig';

interface GiftsScreenProps {
  selectedRecipient: UserProfile;
  selectedGift: GiftItem;
  onSelectGift: (gift: GiftItem) => void;
  onOpenRecipientPicker: () => void;
  onNavigate: (screen: ScreenType) => void;
}

export const GiftsScreen: React.FC<GiftsScreenProps> = ({
  selectedRecipient,
  selectedGift,
  onSelectGift,
  onOpenRecipientPicker,
  onNavigate,
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'mythic' | 'epic' | 'rare'>('all');
  const [previewGift, setPreviewGift] = useState<GiftItem | null>(null);

  const filteredGifts = GIFTS_CATALOG.filter((gift) => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'mythic') return gift.tier === 'mythic' || gift.tier === 'exalted';
    if (activeCategory === 'epic') return gift.tier === 'epic';
    if (activeCategory === 'rare') return gift.tier === 'rare' || gift.tier === 'standard';
    return true;
  });

  const handleSelectAndSend = (gift: GiftItem) => {
    onSelectGift(gift);
    onNavigate('sendgift');
  };

  return (
    <div className="flex flex-col w-full gap-space-lg pb-12 max-w-lg mx-auto relative">
      {/* Recipient Selector Card */}
      <div className="relative w-full rounded-2xl bg-surface-container-high/90 p-space-md shadow-lg overflow-hidden backdrop-blur-xl border border-white/5">
        <div className="absolute -right-8 -top-8 w-28 h-28 bg-primary/10 rounded-full blur-2xl pointer-events-none"></div>
        <div className="flex items-center justify-between gap-space-sm relative z-10">
          <div className="flex items-center gap-space-sm min-w-0">
            <div className="relative shrink-0">
              <img
                className="w-12 h-12 rounded-full object-cover shadow-[0_0_12px_rgba(76,215,246,0.35)] ring-2 ring-secondary/50"
                src={selectedRecipient.avatar}
                alt={selectedRecipient.fullName}
              />
              <span className="absolute -bottom-1 -right-1 bg-secondary text-on-secondary font-label-sm text-label-sm px-1.5 py-0.5 rounded-full font-bold shadow-md">
                #{selectedRecipient.rank}
              </span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">
                Sovg‘a qabul qiluvchi
              </span>
              <span className="font-headline-sm text-headline-sm text-on-surface truncate font-bold">
                {selectedRecipient.fullName}
              </span>
              <span className="font-body-sm text-body-sm text-secondary truncate flex items-center gap-1">
                <span className="material-symbols-outlined text-[14px]">trending_up</span>
                Oltin Liga · Top 5 talikda
              </span>
            </div>
          </div>
          <button
            onClick={onOpenRecipientPicker}
            type="button"
            className="shrink-0 flex items-center gap-1 bg-surface-container-highest hover:bg-surface-bright active:scale-95 transition-all text-primary font-label-md text-label-md px-space-md py-space-sm rounded-full shadow-sm cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">swap_horiz</span>
            <span>O‘zgartirish</span>
          </button>
        </div>
      </div>

      {/* Header & Narrative */}
      <div className="flex flex-col gap-space-2xs">
        <div className="flex items-center gap-space-xs">
          <span
            className="material-symbols-outlined text-tertiary text-[20px]"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            auto_awesome
          </span>
          <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-on-surface font-extrabold tracking-tight">
            Eksklyuziv Sovg‘alar
          </h1>
        </div>
        <p className="font-body-md text-body-md text-on-surface-variant leading-snug">
          Foydalanuvchilarga original virtual sovg‘alar yuborib, ularning reytingini va o‘z nufuzingizni eng cho‘qqiga olib chiqing.
        </p>
      </div>

      {/* Filter Chips Bar */}
      <div className="flex items-center gap-space-xs overflow-x-auto pb-1 no-scrollbar -mx-margin px-margin">
        <button
          onClick={() => setActiveCategory('all')}
          className={`flex items-center gap-1.5 px-space-md py-space-xs rounded-full font-label-md text-label-md shrink-0 transition-all cursor-pointer ${
            activeCategory === 'all'
              ? 'bg-primary text-on-primary shadow-[0_0_16px_rgba(208,188,255,0.4)]'
              : 'bg-surface-container-high text-on-surface-variant hover:text-on-surface'
          }`}
        >
          <span>Barchasi (6)</span>
        </button>
        <button
          onClick={() => setActiveCategory('mythic')}
          className={`flex items-center gap-1.5 px-space-md py-space-xs rounded-full font-label-md text-label-md shrink-0 transition-all cursor-pointer ${
            activeCategory === 'mythic'
              ? 'bg-primary text-on-primary shadow-[0_0_16px_rgba(208,188,255,0.4)]'
              : 'bg-surface-container-high text-on-surface-variant hover:text-on-surface'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-tertiary"></span>
          <span>Afsonaviy</span>
        </button>
        <button
          onClick={() => setActiveCategory('epic')}
          className={`flex items-center gap-1.5 px-space-md py-space-xs rounded-full font-label-md text-label-md shrink-0 transition-all cursor-pointer ${
            activeCategory === 'epic'
              ? 'bg-primary text-on-primary shadow-[0_0_16px_rgba(208,188,255,0.4)]'
              : 'bg-surface-container-high text-on-surface-variant hover:text-on-surface'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-secondary"></span>
          <span>Epik</span>
        </button>
        <button
          onClick={() => setActiveCategory('rare')}
          className={`flex items-center gap-1.5 px-space-md py-space-xs rounded-full font-label-md text-label-md shrink-0 transition-all cursor-pointer ${
            activeCategory === 'rare'
              ? 'bg-primary text-on-primary shadow-[0_0_16px_rgba(208,188,255,0.4)]'
              : 'bg-surface-container-high text-on-surface-variant hover:text-on-surface'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-primary-container"></span>
          <span>Noyob</span>
        </button>
      </div>

      {/* Live Points Simulation Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-surface-container-low via-surface-container to-surface-container-low p-space-md shadow-md flex items-center justify-between gap-space-sm border border-white/5">
        <div className="flex items-center gap-space-sm min-w-0">
          <div className="w-10 h-10 rounded-full bg-tertiary-container/30 flex items-center justify-center shrink-0">
            <span
              className="material-symbols-outlined text-tertiary text-[22px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              bolt
            </span>
          </div>
          <div className="flex flex-col min-w-0">
            <span className="font-label-sm text-label-sm text-tertiary uppercase tracking-wider font-bold">
              Reyting Simulyatori
            </span>
            <span className="font-body-sm text-body-sm text-on-surface truncate">
              Tanlangan: <strong className="text-tertiary font-bold">{selectedGift.name}</strong> (+{selectedGift.pointsReward.toLocaleString()} ball)
            </span>
          </div>
        </div>
        <div className="text-right shrink-0">
          <span className="font-label-sm text-label-sm text-on-surface-variant block">
            Yangi kutilayotgan o‘rin
          </span>
          <span className="font-metric-rank-sm text-metric-rank-sm text-secondary font-bold">
            {selectedGift.projectedRank}
          </span>
        </div>
      </div>

      {/* Collectible Gift Grid */}
      <div className="grid grid-cols-1 gap-space-lg w-full">
        {filteredGifts.map((gift) => {
          const isSelected = selectedGift.id === gift.id;

          return (
            <div
              key={gift.id}
              onClick={() => onSelectGift(gift)}
              className={`group relative rounded-2xl bg-surface-container p-space-md shadow-xl flex flex-col gap-space-md transition-all duration-300 cursor-pointer ${
                isSelected ? 'ring-2 ring-secondary' : 'hover:bg-surface-container-high'
              }`}
            >
              {/* Top tier badge & 3D button */}
              <div className="flex items-start justify-between gap-space-xs">
                <span className="inline-flex items-center gap-1.5 px-space-sm py-0.5 rounded-full bg-tertiary/20 text-tertiary font-label-sm text-label-sm font-bold uppercase tracking-wider shadow-sm">
                  <span
                    className="material-symbols-outlined text-[13px]"
                    style={{ fontVariationSettings: "'FILL' 1" }}
                  >
                    workspace_premium
                  </span>
                  {gift.tierLabel}
                </span>

                <button
                  type="button"
                  title="3D Ko‘rish"
                  onClick={(e) => {
                    e.stopPropagation();
                    setPreviewGift(gift);
                  }}
                  className="text-on-surface-variant hover:text-secondary p-1 rounded-full bg-surface-container-high/80 active:scale-95 transition-all cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">view_in_ar</span>
                </button>
              </div>

              {/* Gift Image with Overlay Price & Point reward */}
              <div className="relative w-full h-44 rounded-xl overflow-hidden bg-surface-container-lowest flex items-center justify-center">
                <img
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  src={gift.imageUrl}
                  alt={gift.name}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-surface-container-lowest/90 via-transparent to-transparent"></div>
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                  <div className="flex items-center gap-1 bg-surface-dim/80 backdrop-blur-md px-space-sm py-1 rounded-full shadow-md">
                    <span className="material-symbols-outlined text-tertiary text-[16px]">stars</span>
                    <span className="font-label-md text-label-md text-on-surface font-bold">
                      {gift.starsPrice.toLocaleString()} Stars
                    </span>
                  </div>
                  <div className="flex items-center gap-1 bg-surface-dim/80 backdrop-blur-md px-space-sm py-1 rounded-full shadow-md">
                    <span className="material-symbols-outlined text-secondary text-[16px]">
                      keyboard_double_arrow_up
                    </span>
                    <span className="font-label-md text-label-md text-secondary font-bold">
                      +{gift.pointsReward.toLocaleString()} Ball
                    </span>
                  </div>
                </div>
              </div>

              {/* Title & description */}
              <div className="flex flex-col gap-1">
                <h3 className="font-headline-sm text-headline-sm text-on-surface font-bold">
                  {gift.name}
                </h3>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  {gift.description}
                </p>
              </div>

              {/* Action Button */}
              <div className="flex items-center gap-space-sm pt-space-xs">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSelectAndSend(gift);
                  }}
                  className="flex-1 py-space-sm px-space-md rounded-xl bg-gradient-to-r from-tertiary-container via-tertiary to-tertiary-container text-on-tertiary-container font-headline-sm text-headline-sm font-bold shadow-[0_4px_16px_rgba(202,129,0,0.3)] active:scale-95 transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>Sovg‘ani tanlash va yuborish</span>
                  <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* 3D Preview Modal Overlay */}
      {previewGift && (
        <div className="fixed inset-0 z-50 bg-surface-dim/80 backdrop-blur-2xl flex items-center justify-center p-margin">
          <div className="relative w-full max-w-sm rounded-2xl bg-surface-container-high p-space-lg shadow-2xl flex flex-col items-center text-center gap-space-md border border-white/10 animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setPreviewGift(null)}
              className="absolute top-3 right-3 text-on-surface-variant hover:text-on-surface p-1 rounded-full bg-surface-container-highest cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>

            <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center text-primary mt-2 animate-bounce">
              <span className="material-symbols-outlined text-[32px]">view_in_ar</span>
            </div>

            <div className="flex flex-col gap-1">
              <span className="font-headline-md text-headline-md text-on-surface font-bold">
                {previewGift.name} - 3D Preview
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">
                Interaktiv 3D animatsiya va particle effektlar faollashtirildi
              </span>
            </div>

            {/* 3D Canvas Mock Graphic with Live Pulse and Image */}
            <div className="w-full h-44 rounded-xl bg-surface-container-lowest relative overflow-hidden flex items-center justify-center">
              <img
                src={previewGift.imageUrl}
                alt={previewGift.name}
                className="w-full h-full object-cover opacity-60"
              />
              <div className="absolute inset-0 bg-radial from-primary/40 via-transparent to-transparent animate-pulse pointer-events-none"></div>
              <div className="absolute flex flex-col items-center gap-2 z-10 bg-surface-dim/70 backdrop-blur-sm px-4 py-2 rounded-xl">
                <span
                  className="material-symbols-outlined text-tertiary text-[36px]"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  token
                </span>
                <span className="font-label-sm text-label-sm text-secondary font-bold tracking-widest uppercase">
                  Telegram Gift Particle 3D
                </span>
                <span className="text-xs text-on-surface font-semibold">
                  {previewGift.starsPrice} ⭐ | +{previewGift.pointsReward} Ball
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                const gift = previewGift;
                setPreviewGift(null);
                handleSelectAndSend(gift);
              }}
              className="w-full py-space-sm rounded-xl bg-primary text-on-primary font-headline-sm text-headline-sm font-bold shadow-lg active:scale-95 transition-all cursor-pointer"
            >
              Tanlash va Davom etish
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
