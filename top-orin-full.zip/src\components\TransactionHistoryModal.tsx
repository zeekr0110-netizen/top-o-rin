import React, { useState } from 'react';
import { TransactionRecord } from '../types';

interface TransactionHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: TransactionRecord[];
  starsBalance: number;
  isDemoMode: boolean;
  onToggleDemoMode: () => void;
  onVerifyPendingTx?: (txId: string) => void;
}

export const TransactionHistoryModal: React.FC<TransactionHistoryModalProps> = ({
  isOpen,
  onClose,
  transactions,
  starsBalance,
  isDemoMode,
  onToggleDemoMode,
  onVerifyPendingTx,
}) => {
  const [filter, setFilter] = useState<'all' | 'verified' | 'pending'>('all');

  if (!isOpen) return null;

  const filtered = transactions.filter((tx) => {
    if (filter === 'verified') return tx.status === 'verified';
    if (filter === 'pending') return tx.status === 'pending';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 bg-surface-dim/80 backdrop-blur-2xl flex items-center justify-center p-margin animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-2xl bg-surface-container-high p-space-lg shadow-2xl flex flex-col gap-space-md border border-white/10 max-h-[85vh]">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-on-surface-variant hover:text-on-surface p-1 rounded-full bg-surface-container-highest cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">close</span>
        </button>

        {/* Title */}
        <div className="flex items-center gap-space-sm">
          <div className="w-10 h-10 rounded-full bg-surface-container-highest flex items-center justify-center text-tertiary">
            <span className="material-symbols-outlined text-[24px]">receipt_long</span>
          </div>
          <div>
            <h2 className="font-headline-sm text-headline-sm text-on-surface font-bold">
              Tranzaksiyalar Tarixi
            </h2>
            <span className="font-label-sm text-label-sm text-tertiary font-bold">
              Mavjud balans: {starsBalance.toLocaleString()} Stars ⭐
            </span>
          </div>
        </div>

        {/* Mode Switcher Banner */}
        <div className="flex items-center justify-between p-space-sm rounded-xl bg-surface-container-lowest border border-white/5">
          <div className="flex flex-col">
            <span className="font-label-sm text-label-sm text-on-surface font-semibold">
              Rejim: {isDemoMode ? 'Sandbox / Demo Rejim' : 'Jonli Telegram Stars'}
            </span>
            <span className="text-[11px] text-on-surface-variant">
              {isDemoMode
                ? 'Sinov to‘lovlari va reyting simulyatsiyasi'
                : 'Rasmiy Telegram Stars API orqali to‘lovlar'}
            </span>
          </div>
          <button
            onClick={onToggleDemoMode}
            className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
              isDemoMode
                ? 'bg-amber-500/20 text-tertiary border border-amber-500/40'
                : 'bg-cyan-500/20 text-secondary border border-cyan-500/40'
            }`}
          >
            {isDemoMode ? 'Jonliga o‘tish' : 'Demoga o‘tish'}
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5">
          {(
            [
              { key: 'all', label: `Barchasi (${transactions.length})` },
              {
                key: 'verified',
                label: `Tasdiqlangan (${transactions.filter((t) => t.status === 'verified').length})`,
              },
              {
                key: 'pending',
                label: `Kutilmoqda (${transactions.filter((t) => t.status === 'pending').length})`,
              },
            ] as const
          ).map((item) => (
            <button
              key={item.key}
              onClick={() => setFilter(item.key)}
              className={`px-2.5 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                filter === item.key
                  ? 'bg-primary text-on-primary'
                  : 'bg-surface-container text-on-surface-variant hover:text-on-surface'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto space-y-space-xs pr-1">
          {filtered.length === 0 ? (
            <div className="p-space-lg text-center text-on-surface-variant text-sm bg-surface-container rounded-xl">
              Hozircha tranzaksiyalar mavjud emas.
            </div>
          ) : (
            filtered.map((tx) => (
              <div
                key={tx.id}
                className="p-space-sm rounded-xl bg-surface-container flex items-center justify-between gap-space-sm border border-white/5"
              >
                <div className="flex items-center gap-space-sm min-w-0">
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                      tx.status === 'verified'
                        ? 'bg-secondary-container/20 text-secondary'
                        : tx.status === 'pending'
                        ? 'bg-tertiary-container/20 text-tertiary'
                        : 'bg-error-container/20 text-error'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">
                      {tx.type === 'boost'
                        ? 'rocket_launch'
                        : tx.type === 'gift_sent'
                        ? 'featured_seasonal_and_gifts'
                        : 'verified'}
                    </span>
                  </div>

                  <div className="flex flex-col min-w-0">
                    <span className="font-body-sm text-body-sm font-bold text-on-surface truncate">
                      {tx.title}
                    </span>
                    <div className="flex items-center gap-2 text-[11px] text-on-surface-variant">
                      <span>{tx.timestamp}</span>
                      {tx.isDemo && (
                        <span className="text-[10px] px-1 rounded bg-amber-500/20 text-tertiary">
                          Demo
                        </span>
                      )}
                      {tx.telegramChargeId && (
                        <span className="font-mono text-[9px] text-outline truncate max-w-[90px]">
                          {tx.telegramChargeId}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end shrink-0">
                  <span className="font-label-md text-label-md text-tertiary font-bold">
                    -{tx.stars.toLocaleString()} ⭐
                  </span>
                  <span className="font-label-sm text-label-sm text-secondary font-bold">
                    +{tx.points.toLocaleString()} ball
                  </span>
                  <span
                    className={`text-[10px] uppercase font-bold mt-0.5 ${
                      tx.status === 'verified'
                        ? 'text-secondary'
                        : tx.status === 'pending'
                        ? 'text-tertiary'
                        : 'text-error'
                    }`}
                  >
                    {tx.status === 'verified'
                      ? '✓ Tasdiqlangan'
                      : tx.status === 'pending'
                      ? '⏳ Kutilmoqda'
                      : '✕ Bekor'}
                  </span>

                  {tx.status === 'pending' && onVerifyPendingTx && (
                    <button
                      onClick={() => onVerifyPendingTx(tx.id)}
                      className="mt-1 text-[10px] px-2 py-0.5 rounded bg-primary text-on-primary font-bold cursor-pointer"
                    >
                      Tasdiqlash
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        <button
          onClick={onClose}
          className="w-full py-space-sm rounded-xl bg-surface-container-highest hover:bg-surface-bright text-on-surface font-headline-sm text-headline-sm font-bold transition-all cursor-pointer"
        >
          Yopish
        </button>
      </div>
    </div>
  );
};
