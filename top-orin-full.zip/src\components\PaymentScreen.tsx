import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { CompetitionConfig, ScreenType, UserProfile } from '../types';
import { triggerHaptic } from '../services/telegram';

interface PaymentScreenProps {
  currentUser: UserProfile;
  config: CompetitionConfig;
  starsBalance: number;
  isDemoMode: boolean;
  onNavigate: (screen: ScreenType) => void;
  onInitiateTransaction: (
    type: 'entry_fee',
    title: string,
    stars: number,
    points: number
  ) => { id: string };
  onProcessVerified: (txId: string) => void;
}

export const PaymentScreen: React.FC<PaymentScreenProps> = ({
  currentUser,
  config,
  starsBalance,
  isDemoMode,
  onNavigate,
  onInitiateTransaction,
  onProcessVerified,
}) => {
  const [paymentState, setPaymentState] = useState<'pending' | 'success' | 'failed'>('pending');
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTxId, setActiveTxId] = useState<string | null>(null);

  const handlePayStars = async () => {
    triggerHaptic('heavy');
    setIsProcessing(true);
    setPaymentState('pending');

    // 1. Create entry_fee transaction
    const tx = onInitiateTransaction(
      'entry_fee',
      `TOP O‘RIN Standard Pass (${config.entryFeeStars} ⭐)`,
      config.entryFeeStars,
      config.entryPointsBonus
    );
    setActiveTxId(tx.id);

    // 2. Verified simulation / Telegram Stars payment verification
    setTimeout(() => {
      onProcessVerified(tx.id);
      setIsProcessing(false);
      setPaymentState('success');
      triggerHaptic('success');

      try {
        confetti({
          particleCount: 120,
          spread: 90,
          origin: { y: 0.5 },
          colors: ['#ca8100', '#ffb95f', '#d0bcff'],
        });
      } catch (e) {
        // ignore
      }

      setTimeout(() => {
        onNavigate('leaderboard');
      }, 2500);
    }, 1600);
  };

  return (
    <div className="flex flex-col w-full pb-space-3xl relative max-w-lg mx-auto">
      {/* Atmospheric Glow Overlays */}
      <div className="pointer-events-none absolute -top-10 left-1/2 -translate-x-1/2 w-72 h-72 rounded-full bg-primary-container/20 blur-[90px]"></div>
      <div className="pointer-events-none absolute top-72 -right-16 w-56 h-56 rounded-full bg-secondary-container/15 blur-[80px]"></div>

      {/* Header & Trust Badges */}
      <div className="flex flex-col items-center text-center mt-space-sm mb-space-lg relative z-10">
        <div className="inline-flex items-center gap-space-xs px-space-md py-space-xs rounded-full bg-surface-container-high shadow-md mb-space-md border border-white/5">
          <span
            className="material-symbols-outlined text-secondary text-[16px]"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            verified
          </span>
          <span className="font-label-md text-label-md text-on-surface uppercase tracking-wider font-bold">
            Rasmiy Telegram Stars to‘lovi
          </span>
        </div>
        <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-on-surface tracking-tight mb-space-xs font-extrabold">
          TOP O‘RIN Reytingiga kirish to‘lovi
        </h1>
        <p className="font-body-md text-body-md text-on-surface-variant max-w-xs">
          Bir martalik to‘lov orqali profilingiz ochiq jonli jadvalga kiritiladi va start ballariga ega bo‘lasiz.
        </p>
      </div>

      {/* Featured Pricing Tier Card */}
      <div className="relative w-full rounded-2xl bg-surface-container-low shadow-xl p-space-lg mb-space-xl overflow-hidden border border-white/5">
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-tertiary-container/25 rounded-full blur-2xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-primary-container via-secondary to-tertiary"></div>

        <div className="flex items-start justify-between relative z-10 mb-space-lg">
          <div className="flex items-center gap-space-md">
            <div className="relative w-14 h-14 rounded-2xl bg-surface-container-highest flex items-center justify-center shadow-lg">
              <span
                className="material-symbols-outlined text-tertiary text-[36px]"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                hotel_class
              </span>
              <span className="material-symbols-outlined text-tertiary-fixed absolute -top-1 -right-1 text-[16px] animate-pulse">
                arrow_back_ios_new
              </span>
            </div>
            <div>
              <span className="font-label-sm text-label-sm uppercase tracking-widest text-secondary font-bold">
                Standard Pass
              </span>
              <div className="flex items-baseline gap-space-2xs mt-space-2xs">
                <span className="font-display-hero-mobile text-display-hero-mobile text-on-surface font-extrabold">
                  {config.entryFeeStars}
                </span>
                <span className="font-headline-md text-headline-md text-tertiary font-bold">
                  ⭐ Stars
                </span>
              </div>
            </div>
          </div>
          <div className="px-space-sm py-space-2xs rounded-full bg-surface-container-highest">
            <span className="font-label-md text-label-md text-on-surface-variant font-bold">
              ~$4.99 ekv.
            </span>
          </div>
        </div>

        {/* Visual Divider */}
        <div className="w-full h-[1px] bg-surface-container-highest mb-space-lg"></div>

        {/* Benefits Checklist */}
        <div className="space-y-space-md mb-space-xl">
          <div className="flex items-start gap-space-sm">
            <div className="w-6 h-6 rounded-full bg-primary-container/25 flex items-center justify-center shrink-0 mt-0.5">
              <span className="material-symbols-outlined text-primary text-[15px] font-bold">
                check
              </span>
            </div>
            <p className="font-body-md text-body-md text-on-surface leading-tight font-medium">
              Umumiy jonli reytingda doimiy o‘rin
            </p>
          </div>

          <div className="flex items-start gap-space-sm">
            <div className="w-6 h-6 rounded-full bg-tertiary-container/25 flex items-center justify-center shrink-0 mt-0.5">
              <span className="material-symbols-outlined text-tertiary text-[15px] font-bold">
                military_tech
              </span>
            </div>
            <div>
              <p className="font-body-md text-body-md text-on-surface leading-tight font-semibold">
                {config.entryPointsBonus.toLocaleString()} boshlang‘ich reyting ballari
              </p>
              <span className="font-body-sm text-body-sm text-tertiary font-bold">
                Bonus darhol hisobga o‘tadi
              </span>
            </div>
          </div>

          <div className="flex items-start gap-space-sm">
            <div className="w-6 h-6 rounded-full bg-secondary-container/25 flex items-center justify-center shrink-0 mt-0.5">
              <span className="material-symbols-outlined text-secondary text-[15px] font-bold">
                redeem
              </span>
            </div>
            <p className="font-body-md text-body-md text-on-surface leading-tight font-medium">
              Virtual sovg‘alarni qabul qilish va yuborish imkoniyati
            </p>
          </div>

          <div className="flex items-start gap-space-sm">
            <div className="w-6 h-6 rounded-full bg-surface-container-highest flex items-center justify-center shrink-0 mt-0.5">
              <span className="material-symbols-outlined text-primary-fixed text-[15px] font-bold">
                trophy
              </span>
            </div>
            <p className="font-body-md text-body-md text-on-surface leading-tight font-medium">
              Haftalik chempionlik sovrinlari o‘yinida ishtirok
            </p>
          </div>
        </div>

        {/* Primary Call-to-Action */}
        <button
          id="payStarsBtn"
          type="button"
          disabled={isProcessing}
          onClick={handlePayStars}
          className="group relative w-full h-14 rounded-2xl bg-gradient-to-r from-primary-container via-[#6366f1] to-secondary-container text-on-surface shadow-[0_8px_24px_rgba(160,120,255,0.35)] flex items-center justify-center gap-space-sm font-headline-sm text-headline-sm font-bold tracking-tight active:scale-[0.98] transition-all overflow-hidden cursor-pointer"
        >
          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none"></div>
          {isProcessing ? (
            <>
              <span className="material-symbols-outlined animate-spin text-[22px]">progress_activity</span>
              <span className="text-white drop-shadow-sm">To‘lov amalga oshirilmoqda...</span>
            </>
          ) : (
            <>
              <span
                className="material-symbols-outlined text-[22px] text-tertiary"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                star
              </span>
              <span className="text-white drop-shadow-sm">
                Stars bilan to‘lash ({config.entryFeeStars} ⭐)
              </span>
            </>
          )}
        </button>
      </div>

      {/* Interactive State Visualizer */}
      <div className="w-full flex flex-col mb-space-xl">
        <div className="flex items-center justify-between mb-space-sm px-space-xs">
          <span className="font-label-lg text-label-lg text-on-surface-variant font-bold uppercase tracking-wider">
            Holat ko‘rinishi
          </span>
          <span className="font-label-sm text-label-sm text-outline">Simulyatsiya & Status</span>
        </div>

        {/* Status Selector Tabs */}
        <div className="grid grid-cols-3 gap-space-xs p-space-2xs bg-surface-container-lowest rounded-xl mb-space-md border border-white/5">
          <button
            type="button"
            onClick={() => setPaymentState('pending')}
            className={`py-space-xs px-space-sm rounded-lg font-label-md text-label-md transition-all text-center cursor-pointer font-bold ${
              paymentState === 'pending'
                ? 'bg-surface-container-high text-on-surface'
                : 'text-on-surface-variant'
            }`}
          >
            Kutilmoqda
          </button>
          <button
            type="button"
            onClick={() => setPaymentState('success')}
            className={`py-space-xs px-space-sm rounded-lg font-label-md text-label-md transition-all text-center cursor-pointer font-bold ${
              paymentState === 'success'
                ? 'bg-surface-container-high text-on-surface'
                : 'text-on-surface-variant'
            }`}
          >
            Tasdiqlandi
          </button>
          <button
            type="button"
            onClick={() => setPaymentState('failed')}
            className={`py-space-xs px-space-sm rounded-lg font-label-md text-label-md transition-all text-center cursor-pointer font-bold ${
              paymentState === 'failed'
                ? 'bg-surface-container-high text-on-surface'
                : 'text-on-surface-variant'
            }`}
          >
            Xatolik
          </button>
        </div>

        {/* Status Card Container */}
        <div className="w-full rounded-2xl bg-surface-container p-space-md shadow-md min-h-[92px] flex items-center border border-white/5">
          {paymentState === 'pending' && (
            <div className="flex items-center gap-space-md w-full">
              <div className="w-12 h-12 rounded-xl bg-tertiary-container/20 flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-tertiary text-[26px] animate-spin">
                  hourglass_top
                </span>
              </div>
              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-space-xs">
                  <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
                    Kutilmoqda
                  </span>
                  <span className="w-2 h-2 rounded-full bg-tertiary animate-ping"></span>
                </div>
                <p className="font-body-sm text-body-sm text-on-surface-variant truncate">
                  Telegram tarmog‘ida to‘lov tranzaksiyasi tekshirilmoqda...
                </p>
              </div>
            </div>
          )}

          {paymentState === 'success' && (
            <div className="flex items-center gap-space-md w-full">
              <div className="w-12 h-12 rounded-xl bg-secondary-container/20 flex items-center justify-center shrink-0">
                <span
                  className="material-symbols-outlined text-secondary text-[26px]"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  verified_user
                </span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-headline-sm text-headline-sm text-secondary font-bold">
                  Tasdiqlandi!
                </span>
                <p className="font-body-sm text-body-sm text-on-surface leading-tight">
                  To‘lov qabul qilindi, profilingiz umumiy reytingda aks etdi! (+{config.entryPointsBonus} ball).
                </p>
              </div>
            </div>
          )}

          {paymentState === 'failed' && (
            <div className="flex items-center gap-space-md w-full">
              <div className="w-12 h-12 rounded-xl bg-error-container/40 flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-error text-[26px]">error</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-headline-sm text-headline-sm text-error font-bold">
                  Muvaffaqiyatsiz
                </span>
                <p className="font-body-sm text-body-sm text-on-surface-variant leading-tight">
                  Hisobingizda Stars yetarli emas. Telegram bot orqali to‘ldiring.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Trust, Guarantee & Security Footer */}
      <div className="w-full flex flex-col items-center justify-center text-center px-space-md mt-auto">
        <div className="w-8 h-8 rounded-full bg-surface-container-high flex items-center justify-center mb-space-xs text-outline">
          <span className="material-symbols-outlined text-[18px]">lock</span>
        </div>
        <p className="font-body-sm text-body-sm text-outline max-w-xs leading-tight">
          To‘lovlar Telegram platformasi xavfsizlik protokollari orqali 100% himoyalangan.
        </p>
      </div>
    </div>
  );
};
