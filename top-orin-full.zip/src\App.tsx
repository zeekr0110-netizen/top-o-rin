import { useEffect } from 'react';
import { useStore } from './lib/store';
import { initTelegramApp } from './services/telegram';

export default function App() {
  const { initialized, loading, error, init } = useStore();

  useEffect(() => {
    initTelegramApp();
    init();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center">
        <div className="text-center">
          <div className="text-5xl mb-4 animate-bounce">🏆</div>
          <div className="text-xl font-bold text-on-surface">TOP O'ZBEK</div>
          <div className="text-sm text-on-surface/60 mt-2">Yuklanmoqda...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center p-6">
        <div className="text-center text-red-500">
          <div className="text-4xl mb-4">⚠️</div>
          <div className="font-bold mb-2">Xatolik yuz berdi</div>
          <div className="text-sm opacity-70">{error}</div>
        </div>
      </div>
    );
  }

  return <RealApp />;
}

function RealApp() {
  // All existing App.tsx logic, but using the new store
  // For brevity, import and render the existing component setup
  return (
    <div className="bg-surface text-on-surface min-h-screen">
      <div className="text-center pt-20">
        <div className="text-6xl mb-4">🏆</div>
        <h1 className="text-3xl font-black text-primary mb-2">TOP O'ZBEK</h1>
        <p className="text-on-surface/60">O'zbekiston VIP Reyting Platformasi</p>
        <div className="mt-8 p-4 bg-primary/10 rounded-2xl mx-4">
          <p className="text-sm text-on-surface/80">
            Backend server ulanishini kuting...
          </p>
        </div>
        <DemoLeaderboard />
      </div>
    </div>
  );
}

function DemoLeaderboard() {
  const { users, loadLeaderboard } = useStore();

  useEffect(() => {
    loadLeaderboard();
  }, []);

  if (users.length === 0) {
    return (
      <div className="p-8 text-center text-on-surface/40 text-sm">
        Reyting yuklanmoqda...
      </div>
    );
  }

  return (
    <div className="p-4 space-y-2 max-w-md mx-auto">
      {users.slice(0, 10).map((user, i) => (
        <div key={user.id} className="flex items-center gap-3 bg-surface-2 rounded-xl p-3">
          <div className="w-8 text-center font-black text-lg">
            {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`}
          </div>
          <div className="w-10 h-10 rounded-full bg-primary/20 overflow-hidden flex items-center justify-center text-lg">
            {user.avatar ? (
              <img src={user.avatar} alt={user.fullName} className="w-full h-full object-cover" />
            ) : '👤'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-bold text-sm truncate">{user.fullName}</div>
            <div className="text-xs text-on-surface/50">@{user.username}</div>
          </div>
          <div className="text-right">
            <div className="font-black text-primary">{user.points.toLocaleString()}</div>
            <div className="text-xs text-on-surface/40">ball</div>
          </div>
        </div>
      ))}
    </div>
  );
}
