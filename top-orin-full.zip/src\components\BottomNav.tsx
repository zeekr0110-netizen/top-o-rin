import React from 'react';
import { ScreenType } from '../types';

interface BottomNavProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentScreen, onNavigate }) => {
  const navItems: { screen: ScreenType; label: string; icon: string }[] = [
    { screen: 'leaderboard', label: 'Asosiy', icon: 'military_tech' },
    { screen: 'boost', label: 'Ko‘tarish', icon: 'rocket_launch' },
    { screen: 'gifts', label: 'Sovg‘alar', icon: 'featured_seasonal_and_gifts' },
    { screen: 'anketa', label: 'Anketa', icon: 'verified' },
    { screen: 'profile', label: 'Profil', icon: 'person' },
  ];

  // Map sub-screens to main nav items
  const activeScreen =
    currentScreen === 'sendgift'
      ? 'gifts'
      : currentScreen === 'payment'
      ? 'anketa'
      : currentScreen;

  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 pb-safe bg-surface-container-lowest/90 backdrop-blur-2xl shadow-[0_-8px_32px_rgba(0,0,0,0.7)]">
      <div className="flex items-center justify-around h-20 px-space-xs max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = activeScreen === item.screen;
          return (
            <button
              key={item.screen}
              onClick={() => onNavigate(item.screen)}
              className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] py-space-xs transition-all cursor-pointer ${
                isActive
                  ? 'text-primary font-bold shadow-[0_0_16px_rgba(208,188,255,0.35)] scale-105'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              <span
                className="material-symbols-outlined text-[24px]"
                style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
              >
                {item.icon}
              </span>
              <span className="font-label-sm text-label-sm mt-space-2xs">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
