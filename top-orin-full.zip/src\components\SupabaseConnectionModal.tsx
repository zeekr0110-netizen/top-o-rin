import React, { useState } from 'react';
import { 
  getSupabaseCredentials, 
  saveCustomSupabaseCredentials, 
  isSupabaseConfigured,
  fetchSupabaseLeaderboard 
} from '../services/supabaseClient';

interface SupabaseConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRefreshLeaderboard: () => Promise<boolean>;
}

export const SupabaseConnectionModal: React.FC<SupabaseConnectionModalProps> = ({
  isOpen,
  onClose,
  onRefreshLeaderboard,
}) => {
  const currentCreds = getSupabaseCredentials();
  const [url, setUrl] = useState(currentCreds.url);
  const [anonKey, setAnonKey] = useState(currentCreds.anonKey);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  if (!isOpen) return null;

  const handleTestAndSave = async () => {
    setTesting(true);
    setTestResult(null);

    saveCustomSupabaseCredentials(url, anonKey);

    try {
      const refreshed = await onRefreshLeaderboard();
      if (refreshed) {
        setTestResult({
          success: true,
          message: 'Muvaffaqiyatli ulandi! Supabase ma’lumotlar bazasidan jonli profillar yuklandi.',
        });
      } else {
        const users = await fetchSupabaseLeaderboard();
        if (users && users.length > 0) {
          setTestResult({
            success: true,
            message: `Muvaffaqiyatli! ${users.length} ta foydalanuvchi profili aniqlandi.`,
          });
        } else {
          setTestResult({
            success: true,
            message: 'Ulandi, ammo "users" jadvali bo‘sh. SQL migratsiyani Supabase SQL Editor-da bajarganingizga ishonch hosil qiling.',
          });
        }
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: `Ulanishda xatolik: ${err.message || 'Noto‘g‘ri URL yoki Anon Key'}`,
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-surface-dim/80 backdrop-blur-2xl flex items-center justify-center p-margin animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-2xl bg-surface-container-high p-space-lg shadow-2xl flex flex-col gap-space-md border border-white/10 max-h-[85vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-on-surface-variant hover:text-on-surface p-1 rounded-full bg-surface-container-highest cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">close</span>
        </button>

        <div className="flex items-center gap-space-sm">
          <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <span className="material-symbols-outlined text-[22px]">database</span>
          </div>
          <div>
            <h3 className="font-headline-sm text-headline-sm text-on-surface font-bold">
              Supabase Integratsiyasi
            </h3>
            <span className="text-xs text-on-surface-variant">
              PostgreSQL & RLS xavfsiz backend sozlamalari
            </span>
          </div>
        </div>

        {/* Current Status Badge */}
        <div className="p-space-sm rounded-xl bg-surface-container-lowest border border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                isSupabaseConfigured() ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
              }`}
            ></span>
            <span className="text-xs font-semibold text-on-surface">
              {isSupabaseConfigured() ? 'Supabase Jonli Ulangan' : 'Mahalliy / Demo Rejim'}
            </span>
          </div>
          <span className="text-[11px] text-outline">
            {isSupabaseConfigured() ? 'Cloud DB Active' : 'Offline'}
          </span>
        </div>

        {/* Credentials Form */}
        <div className="space-y-3">
          <div>
            <label className="text-xs text-on-surface-variant block mb-1 font-semibold">
              VITE_SUPABASE_URL:
            </label>
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://your-project.supabase.co"
              className="w-full bg-surface-container-lowest px-3 py-2 rounded-xl text-xs font-mono text-on-surface focus:outline-none focus:ring-1 focus:ring-primary/40 border border-white/5"
            />
          </div>

          <div>
            <label className="text-xs text-on-surface-variant block mb-1 font-semibold">
              VITE_SUPABASE_ANON_KEY:
            </label>
            <input
              type="password"
              value={anonKey}
              onChange={(e) => setAnonKey(e.target.value)}
              placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
              className="w-full bg-surface-container-lowest px-3 py-2 rounded-xl text-xs font-mono text-on-surface focus:outline-none focus:ring-1 focus:ring-primary/40 border border-white/5"
            />
          </div>
        </div>

        {testResult && (
          <div
            className={`p-3 rounded-xl text-xs leading-relaxed border ${
              testResult.success
                ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                : 'bg-error-container/20 border-error/30 text-error'
            }`}
          >
            {testResult.message}
          </div>
        )}

        {/* Step-by-step guidance card */}
        <div className="p-3 rounded-xl bg-surface-container text-xs space-y-1.5 text-on-surface-variant border border-white/5">
          <span className="font-bold text-on-surface block">Supabase loyihasini ulash tartibi:</span>
          <p>1. Supabase Dashboard oching va yangi loyiha yarating.</p>
          <p>2. <strong>SQL Editor</strong> bo‘limiga o‘tib, <code>src/db/schema.sql</code> faylidagi SQL kodni ishga tushiring.</p>
          <p>3. <strong>Settings ➔ API</strong> bo‘limidan Project URL va anon key nusxalab shu yerga yoki <code>.env</code> fayliga kiriting.</p>
        </div>

        <div className="flex gap-2 pt-2">
          <button
            onClick={handleTestAndSave}
            disabled={testing || !url || !anonKey}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 text-white font-bold text-xs shadow-md active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
          >
            {testing ? (
              <>
                <span className="material-symbols-outlined text-[16px] animate-spin">
                  progress_activity
                </span>
                <span>Tekshirilmoqda...</span>
              </>
            ) : (
              <>
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                <span>Saqlash va Ulanish</span>
              </>
            )}
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-surface-container-highest text-on-surface-variant font-bold text-xs active:scale-95 transition-all cursor-pointer"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
