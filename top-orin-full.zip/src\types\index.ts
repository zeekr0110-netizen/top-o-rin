export type ScreenType = 
  | 'leaderboard'
  | 'boost'
  | 'gifts'
  | 'sendgift'
  | 'anketa'
  | 'payment'
  | 'profile';

export type GiftTier = 'mythic' | 'epic' | 'rare' | 'standard' | 'exalted';

export interface UserProfile {
  id: string;
  telegramId?: number;
  username: string;
  fullName: string;
  avatar: string;
  city: string;
  bio: string;
  birthDate: string;
  age: number;
  isVerified18: boolean;
  points: number;
  rank: number;
  previousRank: number;
  giftsReceivedCount: number;
  giftsSentCount: number;
  votesCount: number;
  weeklyWins: number;
  isOnline: boolean;
  isCurrentUser?: boolean;
  isDemo?: boolean;
  interests: string[];
  badges: {
    id: string;
    title: string;
    category: string;
    icon: string;
    color: string;
  }[];
  receivedGiftsBreakdown?: {
    giftId: string;
    name: string;
    emoji: string;
    count: number;
    points: number;
  }[];
}

export interface GiftItem {
  id: string;
  name: string;
  uzName: string;
  starsPrice: number;
  pointsReward: number;
  tier: GiftTier;
  tierLabel: string;
  description: string;
  imageUrl: string;
  projectedRank: string;
}

export interface BoostPackage {
  id: number;
  name: string;
  stars: number;
  points: number;
  bonusLabel?: string;
  isPopular?: boolean;
  isMega?: boolean;
}

export type TransactionType = 'entry_fee' | 'boost' | 'gift_sent' | 'gift_received';
export type TransactionStatus = 'pending' | 'verified' | 'failed';

export interface TransactionRecord {
  id: string;
  type: TransactionType;
  title: string;
  stars: number;
  points: number;
  timestamp: string;
  status: TransactionStatus;
  recipientId?: string;
  recipientName?: string;
  senderId?: string;
  senderName?: string;
  telegramChargeId?: string;
  message?: string;
  isAnonymous?: boolean;
  isDemo: boolean;
}

export interface CompetitionConfig {
  entryFeeStars: number;
  entryPointsBonus: number;
  championshipPrizeStars: number;
  championshipTrophy: string;
  endDate: string; // ISO string
  pointsPerStarBase: number;
}
