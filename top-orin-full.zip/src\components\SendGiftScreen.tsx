import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { GiftItem, ScreenType, UserProfile } from '../types';
import { triggerHaptic } from '../services/telegram';

interface SendGiftScreenProps {
  selectedRecipient: UserProfile;
  selectedGift: GiftItem;
  starsBalance: number;
  isDemoMode: boolean;
  onNavigate: (screen: ScreenType) => void;
  onInitiateTransaction: (
    type: 'gift_sent',
    title: string,
    stars: number,
    points: number,
    options?: {
      recipientId?: string;
      recipientName?: string;
      message?: string;
      isAnonymous?: boolean;
    }
  ) => { id: string };
  onProcessVerified: (txId: string) => void;
}

export const SendGiftScreen: React.FC<SendGiftScreenProps> = ({
  selectedRecipient,
  selectedGift,
  starsBalance,
  isDemoMode,
  onNavigate,
  onInitiateTransaction,
  onProcessVerified,
}) => {
  const [greetingMessage, setGreetingMessage] = useState(
    'Do‘stim, g‘alaba senga yarashadi! Cho‘qqi sari olg‘a! 👑'
  );
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [pendingTxId, setPendingTxId] = useState<string | null>(null);

  const newPoints = selectedRecipient.points + selectedGift.pointsReward;

  const handleSendGift = async () => {
    triggerHaptic('medium');
    setIsSubmitting(true);

    // 1. Initiate pending transaction
    const tx = onInitiateTransaction(
      'gift_sent',
      `${selectedGift.name} Sovg‘asi (${selectedGift.starsPrice} ⭐)`,
      selectedGift.starsPrice,
      selectedGift.pointsReward,
      {
        recipientId: selectedRecipient.id,
        recipientName: selectedRecipient.fullName,
        message: greetingMessage,
        isAnonymous,
      }
    );
    setPendingTxId(tx.id);

    // 2. Verification flow
    setTimeout(() => {
      onProcessVerified(tx.id);
      setIsSubmitting(false);
      setIsSuccess(true);
      triggerHaptic('success');

      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#ffb95f', '#4cd7f6', '#d0bcff'],
        });
      } catch (e) {
        // ignore
      }

      setTimeout(() => {
        onNavigate('leaderboard');
      }, 2500);
    }, 1500);
  };

  return (
    <div className="flex flex-col w-full pb-32 space-y-space-lg max-w-lg mx-auto relative">
      {/* Status & Step Progress Header */}
      <section className="flex flex-col space-y-space-xs mt-space-sm">
        <div className="flex items-center justify-between text-on-surface-variant font-label-md text-label-md uppercase tracking-wider">
          <span className="flex items-center gap-space-2xs text-secondary font-bold">
            <span className="material-symbols-outlined text-[16px]">verified</span>
            Yakuniy Bosqich
          </span>
          <span className="text-tertiary font-bold">3 / 3 Tasdiqlash</span>
        </div>
        {/* Progress Indicator Bar */}
        <div className="w-full h-1.5 bg-surface-container-high rounded-full overflow-hidden flex">
          <div className="w-full h-full bg-gradient-to-r from-secondary via-primary to-tertiary rounded-full shadow-[0_0_8px_rgba(208,188,255,0.6)]"></div>
        </div>
      </section>

      {/* Step 1: Recipient Profile Identification Card */}
      <section className="bg-surface-container-low rounded-DEFAULT p-space-md shadow-md relative overflow-hidden border border-white/5">
        <div className="absolute -right-10 -top-10 w-32 h-32 bg-primary/10 rounded-full blur-2xl pointer-events-none"></div>
        <div className="flex items-center justify-between mb-space-sm">
          <span className="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant">
            Qabul qiluvchi
          </span>
          <span className="inline-flex items-center gap-space-2xs px-space-xs py-0.5 rounded-full bg-secondary/15 text-secondary font-label-sm text-label-sm font-bold">
            <span
              className="material-symbols-outlined text-[12px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              verified
            </span>
            Tasdiqlangan qabul qiluvchi ✓
          </span>
        </div>
        <div className="flex items-center gap-space-md">
          <div className="relative shrink-0">
            <img
              alt={selectedRecipient.fullName}
              className="w-14 h-14 rounded-full object-cover shadow-[0_0_16px_rgba(147,112,219,0.35)] ring-2 ring-secondary/40"
              src={selectedRecipient.avatar}
            />
            <div className="absolute -bottom-1 -right-1 bg-surface-container-highest px-1.5 py-0.2 rounded-full text-secondary font-metric-rank-sm text-[11px] leading-tight flex items-center justify-center shadow">
              #{selectedRecipient.rank}
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-space-2xs">
              <h2 className="font-headline-sm text-headline-sm text-on-surface truncate font-bold">
                {selectedRecipient.fullName}
              </h2>
              <span
                className="material-symbols-outlined text-primary text-[16px]"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                shield
              </span>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant truncate">
              @{selectedRecipient.username} • {selectedRecipient.city}
            </p>
            <div className="flex items-center gap-space-xs mt-space-2xs">
              <span className="px-space-xs py-0.5 rounded bg-surface-container-highest font-label-sm text-label-sm text-tertiary font-bold">
                #{selectedRecipient.rank} o‘rin ({selectedRecipient.points.toLocaleString()} ball)
              </span>
              <span className="text-on-surface-variant font-body-sm text-[11px]">Oltin Liga</span>
            </div>
          </div>
        </div>
      </section>

      {/* Step 2: Selected Gift Card Showcase with Neon Glow */}
      <section className="relative bg-gradient-to-b from-surface-container to-surface-container-low rounded-DEFAULT p-space-md shadow-xl overflow-hidden border border-white/5">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-tertiary/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col items-center text-center">
          {/* Gift Aura & Mascot Visual Container */}
          <div className="relative my-space-xs flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-tertiary via-primary to-secondary blur-xl opacity-40 animate-pulse"></div>
            <div className="relative w-24 h-24 rounded-2xl overflow-hidden bg-surface-container-high/90 flex items-center justify-center shadow-[0_0_30px_rgba(255,185,95,0.35)] p-2">
              <img
                src={selectedGift.imageUrl}
                alt={selectedGift.name}
                className="w-full h-full object-cover rounded-xl"
              />
            </div>
          </div>

          <div className="mt-space-sm space-y-space-2xs">
            <div className="inline-flex items-center gap-space-2xs bg-tertiary-container/30 px-space-sm py-0.5 rounded-full">
              <span className="material-symbols-outlined text-tertiary text-[14px]">military_tech</span>
              <span className="font-label-sm text-label-sm text-tertiary uppercase font-bold">
                {selectedGift.tierLabel}
              </span>
            </div>
            <h3 className="font-headline-md text-headline-md text-on-surface font-bold">
              {selectedGift.name}
            </h3>
            <p className="font-body-sm text-body-sm text-on-surface-variant max-w-xs">
              {selectedGift.description}
            </p>
          </div>

          {/* Cost Badge */}
          <div className="mt-space-md inline-flex items-center gap-space-xs bg-surface-container-highest px-space-md py-space-xs rounded-full shadow-inner">
            <span className="material-symbols-outlined text-tertiary text-[18px]">star</span>
            <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
              {selectedGift.starsPrice.toLocaleString()}
            </span>
            <span className="font-label-md text-label-md text-tertiary">Telegram Stars</span>
          </div>

          {/* Impact Calculation Banner */}
          <div className="mt-space-lg w-full bg-surface-container-highest/70 rounded-DEFAULT p-space-md text-left">
            <div className="flex items-center justify-between mb-space-2xs">
              <span className="font-label-sm text-label-sm uppercase tracking-wider text-secondary flex items-center gap-space-2xs font-bold">
                <span className="material-symbols-outlined text-[15px]">trending_up</span>
                Reyting Ta'siri
              </span>
              <span className="text-tertiary font-label-md text-label-md font-bold">
                95% G‘alaba ehtimoli
              </span>
            </div>
            <div className="font-body-md text-body-md text-on-surface font-semibold">
              Yangi ball:{' '}
              <span className="text-on-surface-variant">
                {selectedRecipient.points.toLocaleString()}
              </span>{' '}
              +{' '}
              <span className="text-secondary font-bold">
                {selectedGift.pointsReward.toLocaleString()}
              </span>{' '}
              ={' '}
              <span className="text-primary font-bold">
                {newPoints.toLocaleString()} ball!
              </span>
            </div>
            <p className="mt-space-2xs font-body-sm text-body-sm text-on-surface-variant">
              {selectedRecipient.fullName}{' '}
              <span className="text-tertiary font-bold">{selectedGift.projectedRank}</span>ga intiladi va
              podium aurasiga ega bo‘ladi!
            </p>
            {/* Dynamic Rank Leap Visual Bar */}
            <div className="mt-space-sm w-full bg-surface-container-low rounded-full h-2 overflow-hidden flex">
              <div className="h-full bg-outline-variant w-[65%]"></div>
              <div className="h-full bg-secondary w-[25%] shadow-[0_0_8px_rgba(76,215,246,0.8)]"></div>
              <div className="h-full bg-surface-bright w-[10%]"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Step 3: Personal Greeting Note & Anonymous Toggle */}
      <section className="bg-surface-container-low rounded-DEFAULT p-space-md space-y-space-md shadow-md border border-white/5">
        <div className="flex items-center justify-between">
          <label
            className="font-label-md text-label-md uppercase tracking-wider text-on-surface flex items-center gap-space-2xs font-bold"
            htmlFor="greeting-input"
          >
            <span className="material-symbols-outlined text-primary text-[16px]">edit_note</span>
            Tabrik / Tilak xabari (Ixtiyoriy)
          </label>
          <span className="font-label-sm text-label-sm text-on-surface-variant">
            {greetingMessage.length} / 120 belgi
          </span>
        </div>

        {/* Textarea field */}
        <div className="relative">
          <textarea
            id="greeting-input"
            maxLength={120}
            rows={3}
            value={greetingMessage}
            onChange={(e) => setGreetingMessage(e.target.value)}
            className="w-full bg-surface-container-highest rounded-DEFAULT p-space-sm font-body-md text-body-md text-on-surface placeholder:text-outline focus:outline-none focus:ring-1 focus:ring-primary/50 transition-all resize-none shadow-inner"
            placeholder="Do‘stim, g‘alaba senga yarashadi! Cho‘qqi sari olg‘a!"
          />
          {/* Preset Quick Replies */}
          <div className="flex gap-space-2xs mt-space-xs overflow-x-auto pb-1 no-scrollbar">
            <button
              type="button"
              onClick={() =>
                setGreetingMessage('Do‘stim, g‘alaba senga yarashadi! Cho‘qqi sari olg‘a! 👑')
              }
              className="shrink-0 px-space-xs py-1 rounded-full bg-surface-container-high hover:bg-surface-container-highest text-on-surface-variant text-[11px] font-label-md transition cursor-pointer"
            >
              👑 Cho‘qqi sari olg‘a!
            </button>
            <button
              type="button"
              onClick={() => setGreetingMessage('Faqat 1-o‘rin! Taslim bo‘lish yo‘q! 🚀')}
              className="shrink-0 px-space-xs py-1 rounded-full bg-surface-container-high hover:bg-surface-container-highest text-on-surface-variant text-[11px] font-label-md transition cursor-pointer"
            >
              🚀 Faqat 1-o‘rin!
            </button>
            <button
              type="button"
              onClick={() => setGreetingMessage('Doimiy qo‘llab-quvvatlov bilan! 💎')}
              className="shrink-0 px-space-xs py-1 rounded-full bg-surface-container-high hover:bg-surface-container-highest text-on-surface-variant text-[11px] font-label-md transition cursor-pointer"
            >
              💎 Olg‘a do‘stim!
            </button>
          </div>
        </div>

        {/* Anonymous Toggle Option */}
        <div className="flex items-center justify-between pt-space-xs bg-surface-container-high/40 p-space-sm rounded-DEFAULT">
          <div className="flex flex-col pr-space-sm">
            <span className="font-headline-sm text-body-md text-on-surface font-semibold flex items-center gap-space-2xs">
              <span className="material-symbols-outlined text-secondary text-[16px]">visibility_off</span>
              Anonim tarzda yuborish
            </span>
            <span className="font-body-sm text-body-sm text-on-surface-variant">
              Mening ismim sovg‘alar lentasi va ommaviy reytingda ko‘rinmasin
            </span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer shrink-0">
            <input
              type="checkbox"
              id="anon-toggle"
              checked={isAnonymous}
              onChange={(e) => setIsAnonymous(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-surface-container-highest peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-on-surface after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
          </label>
        </div>
      </section>

      {/* Step 4: Cost Breakdown & Payment Summary */}
      <section className="bg-surface-container-low rounded-DEFAULT p-space-md space-y-space-sm shadow-md border border-white/5">
        <h4 className="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-bold">
          To‘lov Tafsilotlari
        </h4>
        <div className="space-y-space-xs text-body-md">
          <div className="flex justify-between items-center text-on-surface-variant">
            <span>Sovg‘a narxi ({selectedGift.name}):</span>
            <span className="font-label-lg text-label-lg text-on-surface font-semibold">
              {selectedGift.starsPrice.toLocaleString()} ⭐
            </span>
          </div>
          <div className="flex justify-between items-center text-on-surface-variant">
            <span>Xizmat komissiyasi (0%):</span>
            <span className="font-label-lg text-label-lg text-secondary font-semibold">0 ⭐</span>
          </div>
          <div className="flex justify-between items-center text-on-surface-variant">
            <span>Telegram tarmoq to‘lovi:</span>
            <span className="font-label-lg text-label-lg text-secondary font-semibold">0 ⭐</span>
          </div>
          <div className="h-px bg-surface-container-highest my-space-xs"></div>
          <div className="flex justify-between items-center pt-space-2xs">
            <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
              Jami to‘lov:
            </span>
            <div className="flex items-center gap-space-2xs text-tertiary">
              <span className="font-headline-md text-headline-md font-bold">
                {selectedGift.starsPrice.toLocaleString()}
              </span>
              <span className="font-label-lg text-label-lg font-bold">Telegram Stars</span>
            </div>
          </div>
        </div>
      </section>

      {/* Security & Delivery Guarantee Note */}
      <section className="flex items-start gap-space-sm px-space-xs text-on-surface-variant">
        <span className="material-symbols-outlined text-secondary text-[20px] shrink-0 mt-0.5">
          verified_user
        </span>
        <p className="font-body-sm text-body-sm leading-relaxed">
          To‘lov tasdiqlangach, qabul qiluvchiga zudlik bilan{' '}
          <strong className="text-on-surface">
            +{selectedGift.pointsReward.toLocaleString()} ball
          </strong>{' '}
          o‘tkaziladi va Telegram orqali rasmiy bot tabrik bildirishnomasi yetkaziladi.
        </p>
      </section>

      {/* Sticky Bottom Interactive Action Panel */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-surface/95 backdrop-blur-2xl p-space-md pb-safe shadow-[0_-8px_32px_rgba(0,0,0,0.7)] flex flex-col items-center">
        <div className="w-full max-w-md space-y-space-xs">
          <button
            id="send-gift-button"
            type="button"
            disabled={isSubmitting || isSuccess}
            onClick={handleSendGift}
            className={`w-full py-space-md px-space-lg rounded-DEFAULT font-headline-sm text-headline-sm font-extrabold flex items-center justify-center gap-space-sm shadow-[0_4px_24px_rgba(202,129,0,0.4)] active:scale-95 transition-all duration-150 relative overflow-hidden group cursor-pointer ${
              isSuccess
                ? 'bg-secondary-container text-on-secondary-container'
                : 'bg-gradient-to-r from-tertiary-container via-tertiary to-primary-container text-on-tertiary-fixed'
            }`}
          >
            {isSubmitting ? (
              <>
                <span className="material-symbols-outlined animate-spin text-[22px]">progress_activity</span>
                <span>To‘lov tekshirilmoqda...</span>
              </>
            ) : isSuccess ? (
              <>
                <span className="material-symbols-outlined text-[22px]">check_circle</span>
                <span>Muvaffaqiyatli Yuborildi! 🎉</span>
              </>
            ) : (
              <>
                <span className="material-symbols-outlined text-[24px]">stars</span>
                <span>
                  {selectedGift.starsPrice.toLocaleString()} ⭐ bilan Sovg‘a Yuborish 🎁
                </span>
              </>
            )}
          </button>

          <div className="flex items-center justify-center gap-space-2xs text-center text-on-surface-variant font-label-sm text-label-sm">
            <span className="material-symbols-outlined text-[13px] text-tertiary">lock</span>
            <span>Telegram Stars orqali xavfsiz serverda tasdiqlanadigan to‘lov</span>
          </div>
        </div>
      </div>
    </div>
  );
};
