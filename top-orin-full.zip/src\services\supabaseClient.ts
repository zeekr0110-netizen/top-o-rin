import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { UserProfile, TransactionRecord, CompetitionConfig } from '../types';
import { INITIAL_LEADERBOARD_USERS } from '../config/appConfig';

const STORAGE_KEYS = {
  CUSTOM_SUPABASE_URL: 'toporin_custom_supabase_url',
  CUSTOM_SUPABASE_ANON_KEY: 'toporin_custom_supabase_anon_key',
};

// Get active configuration (priority: env vars, then user-stored localStorage settings)
export function getSupabaseCredentials(): { url: string; anonKey: string } {
  const envUrl = (import.meta.env.VITE_SUPABASE_URL as string) || '';
  const envKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string) || '';

  if (envUrl && envKey && !envUrl.includes('YOUR_PROJECT_REF')) {
    return { url: envUrl, anonKey: envKey };
  }

  const localUrl = localStorage.getItem(STORAGE_KEYS.CUSTOM_SUPABASE_URL) || '';
  const localKey = localStorage.getItem(STORAGE_KEYS.CUSTOM_SUPABASE_ANON_KEY) || '';

  return { url: localUrl, anonKey: localKey };
}

export function saveCustomSupabaseCredentials(url: string, anonKey: string) {
  if (url) localStorage.setItem(STORAGE_KEYS.CUSTOM_SUPABASE_URL, url.trim());
  if (anonKey) localStorage.setItem(STORAGE_KEYS.CUSTOM_SUPABASE_ANON_KEY, anonKey.trim());
  // Re-create client
  _cachedClient = null;
}

export function isSupabaseConfigured(): boolean {
  const { url, anonKey } = getSupabaseCredentials();
  return Boolean(
    url &&
    anonKey &&
    url.startsWith('https://') &&
    anonKey.length > 20 &&
    !url.includes('YOUR_PROJECT_REF')
  );
}

let _cachedClient: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  if (_cachedClient) return _cachedClient;

  const { url, anonKey } = getSupabaseCredentials();
  if (!url || !anonKey || url.includes('YOUR_PROJECT_REF')) {
    return null;
  }

  try {
    _cachedClient = createClient(url, anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
    return _cachedClient;
  } catch (err) {
    console.warn('Failed to initialize Supabase client:', err);
    return null;
  }
}

/**
 * Maps Supabase Postgres row to frontend UserProfile model
 */
export function mapDbUserToProfile(row: any, currentUserId?: string): UserProfile {
  return {
    id: row.id,
    telegramId: row.telegram_id ? Number(row.telegram_id) : undefined,
    username: row.username || 'foydalanuvchi',
    fullName: row.full_name || 'Noma‘lum',
    avatar: row.avatar_url || 'https://lh3.googleusercontent.com/aida-public/AB6AXuAv-YIzi77LK3WnOx4Wxepo3BNbF0SPUVO0vlKqLOkvzyUtpQKgPVG7n6AapBoAfiylxpB6Flg7tqXREHW2cKZzLWpNoBMNAJhawr2N0fVWanFZjioxLIVTaN4iPCX2T3pWbFHyQQOsPYNcK-VYtyZ_65nrteZJcuVlhFAcIGkin_CJ-u0pQshQWB3hz-NrKswBi__JrOF5PXzOvZZIuxaeCoYup_MwCCjM5Bihv_iA8lpu6T2hSggMBA',
    city: row.city || 'Toshkent',
    bio: row.bio || '',
    birthDate: row.birth_date || '1998-01-01',
    age: row.birth_date ? calculateAge(row.birth_date) : 26,
    isVerified18: Boolean(row.is_verified_18),
    points: Number(row.points || 0),
    rank: Number(row.rank || 999),
    previousRank: Number(row.rank || 999),
    giftsReceivedCount: Number(row.gifts_received_count || 0),
    giftsSentCount: Number(row.gifts_sent_count || 0),
    votesCount: Number(row.votes_count || 0),
    weeklyWins: Number(row.weekly_wins || 0),
    isOnline: Boolean(row.is_online),
    isCurrentUser: currentUserId ? row.id === currentUserId : false,
    interests: Array.isArray(row.interests) ? row.interests : ['Biznes', 'Sport'],
    badges: Array.isArray(row.badges) ? row.badges : [],
    isDemo: false,
  };
}

function calculateAge(dobString: string): number {
  try {
    const birth = new Date(dobString);
    const diff = Date.now() - birth.getTime();
    return Math.abs(new Date(diff).getUTCFullYear() - 1970);
  } catch {
    return 26;
  }
}

/**
 * 1. Fetch live leaderboard users from Supabase
 */
export async function fetchSupabaseLeaderboard(): Promise<UserProfile[] | null> {
  const supabase = getSupabaseClient();
  if (!supabase) return null;

  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('is_active', true)
      .order('points', { ascending: false });

    if (error) {
      console.error('Supabase fetchLeaderboard error:', error);
      return null;
    }

    if (!data || data.length === 0) return null;

    return data.map((row, idx) => ({
      ...mapDbUserToProfile(row),
      rank: idx + 1,
    }));
  } catch (e) {
    console.error('Network error querying Supabase:', e);
    return null;
  }
}

/**
 * 2. Create or sync user profile in Supabase
 */
export async function syncUserToSupabase(profile: Partial<UserProfile>): Promise<UserProfile | null> {
  const supabase = getSupabaseClient();
  if (!supabase) return null;

  try {
    const payload: any = {
      full_name: profile.fullName,
      username: profile.username?.replace('@', ''),
      avatar_url: profile.avatar,
      city: profile.city || 'Toshkent',
      bio: profile.bio || '',
      birth_date: profile.birthDate || null,
      is_verified_18: profile.isVerified18 ?? true,
      interests: profile.interests || [],
      updated_at: new Date().toISOString(),
    };

    if (profile.telegramId) {
      payload.telegram_id = profile.telegramId;
    }

    let response;
    if (profile.id && !profile.id.startsWith('user-') && !profile.id.startsWith('current-user')) {
      // Existing UUID
      response = await supabase
        .from('users')
        .update(payload)
        .eq('id', profile.id)
        .select()
        .single();
    } else if (profile.telegramId) {
      // Upsert by telegram_id
      response = await supabase
        .from('users')
        .upsert(payload, { onConflict: 'telegram_id' })
        .select()
        .single();
    } else {
      // Insert new
      response = await supabase
        .from('users')
        .insert(payload)
        .select()
        .single();
    }

    if (response.error) {
      console.error('Supabase sync user error:', response.error);
      return null;
    }

    return mapDbUserToProfile(response.data);
  } catch (err) {
    console.error('Failed to sync profile to Supabase:', err);
    return null;
  }
}

/**
 * 3. Insert real pending transaction into Supabase
 */
export async function insertSupabaseTransaction(params: {
  userId: string;
  type: TransactionRecord['type'];
  amountStars: number;
  pointsAwarded: number;
  recipientId?: string;
  message?: string;
  isAnonymous?: boolean;
}): Promise<TransactionRecord | null> {
  const supabase = getSupabaseClient();
  if (!supabase) return null;

  try {
    const { data, error } = await supabase
      .from('transactions')
      .insert({
        user_id: params.userId,
        type: params.type,
        amount_stars: params.amountStars,
        points_awarded: params.pointsAwarded,
        status: 'pending', // RLS enforces status = 'pending'
        recipient_id: params.recipientId || null,
        message: params.message || null,
        is_anonymous: Boolean(params.isAnonymous),
        is_demo: false,
      })
      .select()
      .single();

    if (error) {
      console.error('Supabase transaction insert error:', error);
      return null;
    }

    return {
      id: data.id,
      type: data.type,
      title: `${data.amount_stars} Stars to‘lovi`,
      stars: data.amount_stars,
      points: data.points_awarded,
      status: 'pending',
      timestamp: 'Hozirgina (Kutilmoqda)',
      senderId: data.user_id,
      recipientId: data.recipient_id,
      isDemo: false,
    };
  } catch (e) {
    console.error('Transaction insert network error:', e);
    return null;
  }
}

/**
 * 4. Fetch user transaction history from Supabase
 */
export async function fetchSupabaseTransactions(userId: string): Promise<TransactionRecord[]> {
  const supabase = getSupabaseClient();
  if (!supabase) return [];

  try {
    const { data, error } = await supabase
      .from('transactions')
      .select('*')
      .or(`user_id.eq.${userId},recipient_id.eq.${userId}`)
      .order('created_at', { ascending: false });

    if (error || !data) return [];

    return data.map((t) => ({
      id: t.id,
      type: t.type,
      title: `${t.amount_stars} ⭐ Stars (${t.type === 'boost' ? 'Boost' : t.type === 'gift_sent' ? 'Sovg‘a' : 'Kirish to‘lovi'})`,
      stars: t.amount_stars,
      points: t.points_awarded,
      timestamp: new Date(t.created_at).toLocaleString('uz-UZ'),
      status: t.status,
      senderId: t.user_id,
      recipientId: t.recipient_id,
      telegramChargeId: t.telegram_charge_id,
      isDemo: Boolean(t.is_demo),
    }));
  } catch (e) {
    console.error('Error fetching transactions from Supabase:', e);
    return [];
  }
}

/**
 * 5. Verify Telegram InitData via Server API
 */
export async function verifyTelegramInitDataViaServer(initData: string): Promise<{
  verified: boolean;
  user?: any;
  reason?: string;
}> {
  try {
    const res = await fetch('/api/auth/telegram-verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ initData }),
    });
    return await res.json();
  } catch (err: any) {
    console.warn('Server initData verification request failed:', err);
    return { verified: false, reason: 'Server endpoint unreachable' };
  }
}
