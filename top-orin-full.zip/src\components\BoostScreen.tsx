import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { BoostPackage, ScreenType, UserProfile } from '../types';
import { BOOST_PACKAGES } from '../config/appConfig';
import { triggerHaptic } from '../services/telegram';

interface BoostScreenProps {
  currentUser: UserProfile;
  users: UserProfile[];
  onNavigate: (screen: ScreenType) => void;
  onInitiateTransaction: (
    type: 'boost',
    title: string,
    stars: number,
    points: number
  ) => { id: string };
  onProcessVerified: (txId: string) => void;
}

export const BoostScreen: React.FC<BoostScreenProps> = ({
  currentUser,
  users,
  onNavigate,
  onInitiateTransaction,
  onProcessVerified,
}) => {
  const [selectedPkg, setSelectedPkg] = useState<BoostPackage | null>(BOOST_PACKAGES[2]); // Super Nitro by default
  const [customStars, setCustomStars] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Dynamic point multiplier
  const calculateDynamicPoints = (stars: number) => {
    if (stars <= 0) return 0;
    let multiplier = 10;
    if (stars >= 1000) multiplier = 16.6;
    else if (stars >= 500) multiplier = 14;
    else if (stars >= 150) multiplier = 12;
    return Math.round(stars * multiplier);
  };

  const activeStars = customStars
    ? parseInt(customStars, 10) || 0
    : selectedPkg?.stars || 0;

  const activePoints = customStars
    ? calculateDynamicPoints(parseInt(customStars, 10) || 0)
    : selectedPkg?.points || 0;

  const packageName = customStars ? 'Maxsus Miqdor' : selectedPkg?.name || 'Boost Paketi';

  // Distance to rank 3 calculation
  const rank3User = users.find((u) => u.rank === 3);
  const pointsToTop3 = rank3User
    ? Math.max(0, rank3User.points - currentUser.points + 100)
    : 11600;
  const progressPercent = Math.min(
    95,
    Math.max(20, Math.round((currentUser.points / (currentUser.points + pointsToTop3)) * 100))
  );

  const handleSelectPackage = (pkg: BoostPackage) => {
    triggerHaptic('light');
    setSelectedPkg(pkg);
    setCustomStars('');
  };

  const handleCustomInput = (val: string) => {
    setCustomStars(val);
    setSelectedPkg(null);
  };

  const handleQuickAdd = (amount: number) => {
    triggerHaptic('light');
    const current = parseInt(customStars, 10) || activeStars || 0;
    const next = current + amount;
    setCustomStars(next.toString());
    setSelectedPkg(null);
  };

  const handleTriggerBoost = async () => {
    if (activeStars <= 0) return;
    triggerHaptic('heavy');
    setIsSubmitting(true);

    // 1. Record pending transaction
    const tx = onInitiateTransaction(
      'boost',
      `${packageName} (${activeStars.toLocaleString()} ⭐)`,
      activeStars,
      activePoints
    );

    // 2. Verified simulation / Telegram Stars webhook verification
    setTimeout(() => {
      onProcessVerified(tx.id);
      setIsSubmitting(false);
      setIsSuccess(true);
      triggerHaptic('success');

      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#a078ff', '#4cd7f6', '#ffb95f'],
        });
      } catch (e) {
        // ignore
      }

      setTimeout(() => {
        setIsSuccess(false);
        onNavigate('leaderboard');
      }, 2000);
    }, 1400);
  };

  return (
    <div className="flex flex-col w-full gap-space-lg select-none max-w-lg mx-auto pb-12">
      {/* Status Banner Card */}
      <section className="relative overflow-hidden rounded-lg bg-surface-container-high p-space-lg shadow-xl border border-white/5">
        <div className="absolute -right-10 -top-10 w-44 h-44 rounded-full bg-primary/10 blur-3xl pointer-events-none"></div>
        <div className="absolute -left-12 -bottom-12 w-40 h-40 rounded-full bg-secondary/10 blur-2xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col gap-space-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-space-xs">
              <span className="inline-flex p-1.5 rounded-full bg-surface-container-highest text-secondary shadow-inner">
                <span
                  className="material-symbols-outlined text-[20px]"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  trending_up
                </span>
              </span>
              <span className="font-label-md text-label-md text-on-surface-variant uppercase tracking-wider font-bold">
                Joriy Holat
              </span>
            </div>
            <span className="font-metric-rank-sm text-metric-rank-sm text-secondary bg-surface-container-lowest px-space-md py-space-2xs rounded-full font-bold">
              #{currentUser.rank} O‘rinda
            </span>
          </div>

          <div className="grid grid-cols-2 gap-space-sm pt-space-xs">
            <div className="flex flex-col p-space-sm rounded bg-surface-container-lowest/70 backdrop-blur-sm">
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold">
                Mavjud ball
              </span>
              <div className="flex items-baseline gap-space-2xs mt-space-2xs">
                <span className="font-metric-rank text-metric-rank text-on-surface font-bold">
                  {currentUser.points.toLocaleString()}
                </span>
                <span className="font-label-sm text-label-sm text-primary font-bold">ball</span>
              </div>
            </div>

            <div className="flex flex-col p-space-sm rounded bg-surface-container-lowest/70 backdrop-blur-sm">
              <span className="font-label-sm text-label-sm text-tertiary uppercase font-semibold">
                3-o‘ringa intilish
              </span>
              <div className="flex items-baseline gap-space-2xs mt-space-2xs">
                <span className="font-metric-rank text-metric-rank text-tertiary font-bold">
                  +{pointsToTop3.toLocaleString()}
                </span>
                <span className="font-label-sm text-label-sm text-tertiary font-bold">ball</span>
              </div>
            </div>
          </div>

          {/* Distance Progress Gauge Visual */}
          <div className="flex flex-col gap-space-xs pt-space-2xs">
            <div className="flex justify-between items-center text-on-surface-variant font-label-sm text-label-sm">
              <span>Top-3 Shoxsupasigacha</span>
              <span className="text-tertiary font-bold">{progressPercent}% masofa bosib o‘tildi</span>
            </div>
            <div className="w-full h-2 rounded-full bg-surface-container-lowest overflow-hidden p-0.5 flex">
              <div
                className="h-full rounded-full bg-gradient-to-r from-secondary via-primary to-tertiary shadow-[0_0_12px_rgba(255,185,95,0.6)] transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
          </div>
        </div>
      </section>

      {/* Live Disclaimer Notice */}
      <aside className="flex items-start gap-space-sm p-space-md rounded bg-surface-container-lowest/60 backdrop-blur-md border border-white/5">
        <span className="material-symbols-outlined text-secondary text-[20px] shrink-0 mt-0.5">
          info
        </span>
        <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
          <strong className="text-on-surface font-semibold">Eslatma:</strong> Ballar sizning umumiy reytingdagi o‘rningizni oshiradi. Raqobat real vaqt rejimida kechadi, shuning uchun aniq o‘rin kafolatlanmaydi.
        </p>
      </aside>

      {/* Configurable Stars Packages Grid */}
      <section className="flex flex-col gap-space-sm">
        <div className="flex items-center justify-between px-space-xs">
          <span className="font-label-lg text-label-lg text-on-surface uppercase tracking-wider font-bold">
            Tanlangan Boost Paketlari
          </span>
          <span className="font-label-sm text-label-sm text-primary font-bold">Tezkor Faollashuv</span>
        </div>

        <div className="grid grid-cols-2 gap-space-sm">
          {BOOST_PACKAGES.map((pkg) => {
            const isSelected = selectedPkg?.id === pkg.id && !customStars;

            return (
              <div
                key={pkg.id}
                onClick={() => handleSelectPackage(pkg)}
                className={`relative flex flex-col justify-between p-space-md rounded-lg transition-all active:scale-[0.98] shadow-md cursor-pointer border border-white/5 ${
                  isSelected
                    ? 'is-selected bg-surface-container-highest shadow-xl shadow-tertiary/10 ring-1 ring-secondary'
                    : 'bg-surface-container-low hover:bg-surface-container-high'
                }`}
              >
                {pkg.isPopular && (
                  <div className="absolute -top-2.5 right-3 bg-tertiary text-on-tertiary font-label-sm text-label-sm px-space-sm py-0.5 rounded-full uppercase font-bold shadow-md flex items-center gap-1">
                    <span>Eng ommabop 🔥</span>
                  </div>
                )}

                <div className="flex flex-col gap-space-2xs">
                  <span
                    className={`font-label-sm text-label-sm uppercase font-bold ${
                      pkg.bonusLabel ? 'text-secondary' : 'text-outline'
                    }`}
                  >
                    {pkg.bonusLabel || (pkg.id === 1 ? 'Eng arzon' : '')}
                  </span>
                  <span className="font-headline-sm text-headline-sm text-on-surface mt-space-2xs font-bold">
                    {pkg.name}
                  </span>
                  <div className="flex items-center gap-space-2xs mt-space-xs text-secondary font-bold">
                    <span className="material-symbols-outlined text-[18px]">bolt</span>
                    <span className="font-label-md text-label-md">
                      +{pkg.points.toLocaleString()} ball
                    </span>
                  </div>
                </div>

                <div className="mt-space-lg flex items-center justify-between pt-space-xs">
                  <span className="font-label-md text-label-md text-tertiary flex items-center gap-1 font-bold">
                    <span
                      className="material-symbols-outlined text-[16px]"
                      style={{ fontVariationSettings: "'FILL' 1" }}
                    >
                      star
                    </span>{' '}
                    {pkg.stars.toLocaleString()}
                  </span>
                  <span
                    className={`selection-indicator w-4 h-4 rounded-full flex items-center justify-center ${
                      isSelected
                        ? 'bg-tertiary text-on-tertiary'
                        : 'bg-surface-container-highest'
                    }`}
                  >
                    {isSelected && (
                      <span className="material-symbols-outlined text-[12px] font-bold">check</span>
                    )}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Custom Stars Amount Input Field */}
      <section className="flex flex-col gap-space-sm p-space-lg rounded-lg bg-surface-container-low shadow-lg border border-white/5">
        <div className="flex items-center justify-between">
          <label
            className="font-label-lg text-label-lg text-on-surface flex items-center gap-space-xs font-bold"
            htmlFor="custom-stars"
          >
            <span className="material-symbols-outlined text-primary text-[20px]">tune</span>
            <span>Boshqa miqdor kiriting</span>
          </label>
          <span className="font-label-sm text-label-sm text-outline">1 ⭐ = 10-16 Ball</span>
        </div>

        <div className="relative flex items-center mt-space-xs">
          <div className="absolute left-space-md flex items-center pointer-events-none text-tertiary">
            <span
              className="material-symbols-outlined text-[24px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              star
            </span>
          </div>
          <input
            id="custom-stars"
            type="number"
            min="10"
            max="50000"
            step="10"
            value={customStars}
            onChange={(e) => handleCustomInput(e.target.value)}
            placeholder="Yulduzlar soni (kamida 10)..."
            className="w-full h-14 pl-12 pr-space-lg rounded bg-surface-container-lowest text-on-surface font-headline-sm text-headline-sm placeholder:text-outline/60 focus:outline-none focus:ring-1 focus:ring-primary/40 transition-colors"
          />
        </div>

        {/* Quick Increment Pills */}
        <div className="flex items-center gap-space-xs mt-space-xs">
          <button
            type="button"
            onClick={() => handleQuickAdd(100)}
            className="flex-1 py-space-xs rounded bg-surface-container-high hover:bg-surface-bright text-on-surface-variant font-label-md text-label-md active:scale-95 transition-all cursor-pointer font-bold"
          >
            +100 ⭐
          </button>
          <button
            type="button"
            onClick={() => handleQuickAdd(250)}
            className="flex-1 py-space-xs rounded bg-surface-container-high hover:bg-surface-bright text-on-surface-variant font-label-md text-label-md active:scale-95 transition-all cursor-pointer font-bold"
          >
            +250 ⭐
          </button>
          <button
            type="button"
            onClick={() => handleQuickAdd(1000)}
            className="flex-1 py-space-xs rounded bg-surface-container-high hover:bg-surface-bright text-on-surface-variant font-label-md text-label-md active:scale-95 transition-all cursor-pointer font-bold"
          >
            +1,000 ⭐
          </button>
        </div>

        {/* Live Calculation Badge */}
        <div className="flex items-center justify-between p-space-sm rounded bg-surface-container-highest/60 mt-space-xs">
          <span className="font-body-sm text-body-sm text-on-surface-variant">Hisoblangan ball:</span>
          <span className="font-headline-sm text-headline-sm text-secondary font-bold">
            +{activePoints.toLocaleString()} ball
          </span>
        </div>
      </section>

      {/* Visual Boost Animation Deck */}
      <section className="relative h-28 rounded-lg overflow-hidden bg-surface-container-lowest flex items-center justify-between px-space-lg shadow-inner border border-white/5">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-surface-container-lowest to-secondary/10 pointer-events-none"></div>
        <div className="flex flex-col z-10 max-w-[200px]">
          <span className="font-label-sm text-label-sm text-primary uppercase font-bold tracking-widest">
            Poyga Shiddati
          </span>
          <span className="font-headline-sm text-headline-sm text-on-surface mt-1 leading-tight font-bold">
            O‘z o‘rningizni mustahkamlang
          </span>
        </div>
        <div className="relative z-10 w-16 h-16 rounded-full bg-surface-container-high flex items-center justify-center shadow-lg">
          <span
            className="material-symbols-outlined text-[32px] text-tertiary animate-pulse"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            rocket_launch
          </span>
        </div>
      </section>

      {/* Summary & Checkout Execution Deck */}
      <section className="flex flex-col gap-space-md p-space-lg rounded-lg bg-surface-container-high shadow-2xl border border-white/5">
        <div className="flex flex-col gap-space-2xs">
          <div className="flex justify-between items-center text-on-surface-variant font-body-sm text-body-sm">
            <span>Tanlangan paket:</span>
            <span className="text-on-surface font-semibold">
              {packageName} ({activeStars.toLocaleString()} ⭐)
            </span>
          </div>
          <div className="flex justify-between items-center text-on-surface-variant font-body-sm text-body-sm">
            <span>Olinadigan ball:</span>
            <span className="text-secondary font-bold">+{activePoints.toLocaleString()} ball</span>
          </div>
        </div>

        <button
          type="button"
          disabled={isSubmitting || activeStars <= 0}
          onClick={handleTriggerBoost}
          className={`relative group w-full h-14 rounded font-headline-sm text-headline-sm flex items-center justify-center gap-space-sm shadow-[0_8px_24px_rgba(160,120,255,0.35)] active:scale-[0.98] transition-all overflow-hidden cursor-pointer ${
            isSuccess
              ? 'bg-secondary-container text-on-secondary-container'
              : 'bg-gradient-to-r from-primary-container via-primary to-secondary text-on-primary'
          }`}
        >
          {isSubmitting ? (
            <>
              <span className="material-symbols-outlined animate-spin text-[24px]">progress_activity</span>
              <span className="font-bold tracking-wide">Jarayonda...</span>
            </>
          ) : isSuccess ? (
            <>
              <span className="material-symbols-outlined text-[24px]">check_circle</span>
              <span className="font-bold tracking-wide">Muvaffaqiyatli oshirildi! 🎉</span>
            </>
          ) : (
            <>
              <span
                className="material-symbols-outlined text-[24px] group-hover:-translate-y-1 group-hover:translate-x-1 transition-transform"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                rocket_launch
              </span>
              <span className="font-bold tracking-wide">
                Reytingni ko‘tarish ({activeStars.toLocaleString()} ⭐)
              </span>
            </>
          )}
        </button>

        <div className="flex items-center justify-center gap-space-xs text-on-surface-variant pt-space-2xs">
          <span
            className="material-symbols-outlined text-secondary text-[16px]"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            verified_user
          </span>
          <span className="font-label-md text-label-md">
            Telegram Stars bilan bir zumda faollashadi
          </span>
        </div>
      </section>
    </div>
  );
};
