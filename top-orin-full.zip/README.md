# 🏆 TOP O'ZBEK — Telegram Mini App

> O'zbekiston VIP Reyting Platformasi: Telegram Stars orqali reytingni ko'tarish, eksklyuziv sovg'alar va haftalik chempionatlar.

---

## 1. What Is This?

A full-stack Telegram Mini App where users:
- **Register** via Telegram auth
- **Pay with Telegram Stars** to boost their rating points
- **Send gifts** to other users (gifts cost Stars, recipient gains points)
- **Compete weekly** — top-ranked user wins a prize in Telegram Stars
- **Leaderboard** updates in real-time after every verified payment

---

## 2. Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19 + TypeScript + Vite + Tailwind CSS 4 |
| State | Zustand |
| Backend | Express.js |
| Database | Supabase (PostgreSQL + RLS + RPC Functions) |
| Payments | Telegram Stars (XTR) via Bot API |
| Auth | Telegram WebApp HMAC-SHA256 initData |
| Hosting | Railway / Render / Docker |

---

## 3. Project Structure

```
top-orin-full/
├── server.js          ← Express backend (API + Webhooks)
├── package.json       ← Backend dependencies
├── schema.sql         ← Supabase database schema (run this first!)
├── Dockerfile         ← Production Docker image
├── docker-compose.yml ← Docker Compose setup
├── .env.example       ← Environment variables template
│
├── index.html
├── vite.config.ts
├── tailwind.config.js
└── src/
    ├── App.tsx         ← Main React app
    ├── lib/
    │   ├── api.ts      ← API client (all server calls)
    │   └── store.ts    ← Zustand store (state management)
    ├── components/     ← All UI components
    └── services/
        ├── supabaseClient.ts
        └── telegram.ts
```

---

## 4. Setup Guide (Step by Step)

### STEP 1 — Run Database Schema (Supabase)

1. Go to [supabase.com](https://supabase.com) → your project → **SQL Editor**
2. Click **New Query**
3. Copy-paste the entire content of `schema.sql`
4. Click **Run** — all tables, functions, RLS policies, and seed data will be created

### STEP 2 — Get Supabase Service Role Key

1. Supabase Dashboard → **Settings** → **API**
2. Find **service_role** key (under "service_role (secret)")
3. Copy it — you'll need it for the server

### STEP 3 — Set Up Telegram Bot Webhook

Set the webhook so Telegram sends payment events to your server:

```
https://api.telegram.org/bot8726788315:AAFH4Q4DdJ_b3P1TWp9Np9azr2urcHlAeVI/setwebhook?url=https://YOUR_DOMAIN/api/telegram/webhook
```

Replace `YOUR_DOMAIN` with your actual deployed server URL.

### STEP 4 — Deploy Backend Server

**Option A: Railway (Recommended — easiest)**

1. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub or upload
2. Add environment variables:
   - `TELEGRAM_BOT_TOKEN` = `8726788315:AAFH4Q4DdJ_b3P1TWp9Np9azr2urcHlAeVI`
   - `SUPABASE_URL` = `https://qidrzcvbzcoyrspnktzp.supabase.co`
   - `SUPABASE_SERVICE_KEY` = your service_role key
   - `ADMIN_SECRET` = any strong random string you choose
   - `NODE_ENV` = `production`
   - `PORT` = `3000`
3. Deploy — Railway auto-detects Node.js and starts `npm start`

**Option B: Render**

1. Go to [render.com](https://render.com) → New → Web Service
2. Connect repo → set build command: empty → start command: `node server.js`
3. Add env vars same as above
4. Deploy

**Option C: DigitalOcean / VPS**

```bash
# SSH into your server
git clone <your-repo>
cd top-orin-full
npm install --production
# Set env vars
cp .env.example .env
nano .env  # fill in real values
node server.js
```

**Option D: Docker**

```bash
cp .env.example .env
# Edit .env with real values
docker-compose up -d
```

### STEP 5 — Build & Host Frontend

The frontend is a static React app. Build it and host anywhere:

```bash
cd top-orin-full
npm install
npm run build
# dist/ folder = static files to upload to any hosting
```

Set in your frontend env:
```
VITE_API_URL=https://your-backend-domain.com/api
```

For Telegram Mini App to work, your frontend must be hosted on HTTPS and added to your bot's Mini App configuration in @BotFather.

---

## 5. API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Server health check |
| POST | `/api/auth/telegram-verify` | Verify Telegram user, get/create DB user |
| GET | `/api/leaderboard` | Top 100 users by points |
| GET | `/api/gifts` | All active gifts catalog |
| GET | `/api/boosts` | All active boost packages |
| GET | `/api/user/:telegramId` | Single user profile |
| GET | `/api/transactions/:telegramId` | User transaction history |
| POST | `/api/payments/create-invoice` | Create Telegram Stars invoice link |
| GET | `/api/competition/current` | Current active weekly competition |
| POST | `/api/competition/close` | Close competition, pay winner (admin) |
| POST | `/api/telegram/webhook` | Telegram payment webhook receiver |

---

## 6. Weekly Competition Flow

```
Every Sunday 23:59 → Competition auto-closes
                        ↓
              Top-ranked user wins
                        ↓
        Telegram Stars prize sent to winner (via Bot API)
                        ↓
              Points reset for new round
                        ↓
        New competition round starts automatically
                        ↓
        Winner notified via Telegram bot
```

Manual close (admin):
```bash
curl -X POST https://your-domain.com/api/competition/close \
  -H "X-Admin-Key: top-orin-admin-2025"
```

---

## 7. Telegram Stars Payment Flow

```
User clicks "Buy Boost" or "Send Gift"
         ↓
  Frontend calls POST /api/payments/create-invoice
         ↓
  Server creates invoice via Telegram Bot API
         ↓
  Frontend opens invoice via Telegram.WebApp.openInvoice()
         ↓
  User pays with Telegram Stars
         ↓
  Telegram sends webhook to /api/telegram/webhook
         ↓
  Server verifies payment → updates Supabase (points + ranks)
         ↓
  Leaderboard refreshes → new rankings live!
```

---

## 8. Environment Variables

```env
TELEGRAM_BOT_TOKEN=       # From @BotFather
SUPABASE_URL=             # https://xxx.supabase.co
SUPABASE_SERVICE_KEY=     # service_role key from Supabase
ADMIN_SECRET=             # Your chosen admin password
PORT=3000
NODE_ENV=production
```

---

## 9. Security Notes

- `SUPABASE_SERVICE_KEY` is **server-side only** — never expose to frontend
- Telegram initData is verified with **HMAC-SHA256** on every auth request
- All payments go through **official Telegram Stars API** — no manual overrides
- RLS policies ensure users can only read their own transactions
- Webhook endpoint validates Telegram's `pre_checkout_query` before payment

---

## 10. Admin Panel

Access admin functions:
- **Close competition manually:** `POST /api/competition/close` with header `X-Admin-Key`
- **View analytics:** `/api/health` shows connection status
- **Manage users:** Supabase Dashboard → Table Editor → users

---

## Current Status

- ✅ Frontend: Built (7 screens + modals)
- ✅ Backend: Built (all API endpoints)
- ✅ Telegram Bot: Connected (@toporin_bot)
- ✅ Supabase: Project ready, schema file prepared
- ⏳ Deployment: **YOU need to do this part** — host the server + run schema.sql
- ⏳ Webhook URL: **YOU need to set this** after deployment
- ⏳ Frontend hosting: **YOU need to host** the React build
