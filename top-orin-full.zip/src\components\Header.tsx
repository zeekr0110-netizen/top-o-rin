import React from 'react';
import { ScreenType, UserProfile } from '../types';
import { LOGO_URL } from '../config/appConfig';

interface HeaderProps {
  currentScreen: ScreenType;
  starsBalance: number;
  currentUser: UserProfile;
  isDemoMode: boolean;
  onNavigate: (screen: ScreenType) => void;
  onBack?: () => void;
  onOpenTransactions: () => void;
  onOpenNotifications: () => void;
  onToggleDemoMode: () => void;
  onOpenConfig: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentScreen,
  starsBalance,
  currentUser,
  isDemoMode,
  onNavigate,
  onBack,
  onOpenTransactions,
  onOpenNotifications,
  onToggleDemoMode,
  onOpenConfig,
}) => {
  const isSubScreen = currentScreen === 'sendgift' || currentScreen === 'payment';

  const screenSubtitle: Record<ScreenType, string> = {
    leaderboard: 'Leaderboard',
    boost: 'Boost',
    gifts: 'Gifts',
    sendgift: 'Sendgift',
    anketa: 'Anketa',
    payment: 'Payment',
    profile: 'Profile',
  };

  return (
    <header className="fixed top-0 inset-x-0 z-50 pt-safe bg-surface/85 backdrop-blur-xl shadow-[0_4px_24px_rgba(0,0,0,0.4)]">
      <div className="h-16 px-margin flex items-center justify-between gap-space-sm max-w-lg mx-auto">
        {/* Left: Back button or Logo + Title */}
        <div className="flex items-center gap-space-xs min-w-0 flex-1">
          {isSubScreen ? (
            <button
              aria-label="Orqaga"
              className="w-10 h-10 flex items-center justify-center rounded-full bg-surface-container-high/70 text-on-surface hover:text-primary active:scale-95 transition-transform shrink-0"
              onClick={onBack}
            >
              <span className="material-symbols-outlined text-[22px]">arrow_back</span>
            </button>
          ) : null}

          <div
            className="flex items-center gap-space-sm min-w-0 cursor-pointer"
            onClick={() => onNavigate('leaderboard')}
          >
            <img
              alt="TOP O‘RIN Logo"
              className="h-8 w-auto object-contain shrink-0"
              src={LOGO_URL}
            />
            <div className="flex flex-col min-w-0">
              <span className="font-headline-sm text-headline-sm text-on-surface truncate leading-none">
                TOP O‘RIN
              </span>
              <div className="flex items-center gap-1.5 leading-tight">
                <span className="font-label-sm text-label-sm text-primary tracking-widest uppercase truncate">
                  {screenSubtitle[currentScreen]}
                </span>
                {isDemoMode ? (
                  <span
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleDemoMode();
                    }}
                    title="Demo rejimida (haqiqiy to'lov emas). Bosib almashtirish mumkin."
                    className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-tertiary border border-amber-500/30 cursor-pointer hover:bg-amber-500/30"
                  >
                    DEMO
                  </span>
                ) : (
                  <span
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleDemoMode();
                    }}
                    title="Jonli Telegram Stars rejimi. Bosib almashtirish mumkin."
                    className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-cyan-500/20 text-secondary border border-cyan-500/30 cursor-pointer hover:bg-cyan-500/30"
                  >
                    LIVE
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-space-xs shrink-0">
          {/* Telegram Stars Balance Badge */}
          <button
            onClick={onOpenTransactions}
            title="Tranzaksiyalar tarixi va Stars balansi"
            className="flex items-center gap-space-2xs bg-surface-container-high/90 hover:bg-surface-container-highest px-space-sm py-space-2xs rounded-full shadow-[0_0_12px_rgba(202,129,0,0.15)] active:scale-95 transition-all"
          >
            <span className="material-symbols-outlined text-tertiary text-[18px]">star</span>
            <span className="font-label-md text-label-md text-tertiary font-bold">
              {starsBalance.toLocaleString()}
            </span>
          </button>

          {/* Notifications / Announcements Bell */}
          <button
            aria-label="Xabarlar va chempionatlar"
            onClick={onOpenNotifications}
            className="relative w-10 h-10 flex items-center justify-center rounded-full bg-surface-container-high/60 text-on-surface-variant hover:text-on-surface active:scale-95 transition-transform"
          >
            <span className="material-symbols-outlined text-[20px]">notifications</span>
            <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-secondary shadow-[0_0_8px_#4cd7f6]"></span>
          </button>

          {/* Profile Avatar Button */}
          <button
            aria-label="Profil"
            onClick={() => onNavigate('profile')}
            className="relative shrink-0 active:scale-95 transition-transform"
          >
            <img
              alt={currentUser.fullName}
              className="w-8 h-8 rounded-full object-cover shadow-[0_0_10px_rgba(208,188,255,0.3)] ring-1 ring-primary/40"
              src={currentUser.avatar}
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-secondary ring-2 ring-surface"></span>
          </button>
        </div>
      </div>
    </header>
  );
};
