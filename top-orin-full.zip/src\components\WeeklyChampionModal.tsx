import React from 'react';
import { CompetitionConfig, UserProfile } from '../types';

interface WeeklyChampionModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: CompetitionConfig;
  leader: UserProfile;
}

export const WeeklyChampionModal: React.FC<WeeklyChampionModalProps> = ({
  isOpen,
  onClose,
  config,
  leader,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-surface-dim/80 backdrop-blur-2xl flex items-center justify-center p-margin animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm rounded-2xl bg-surface-container-high p-space-lg shadow-2xl flex flex-col gap-space-md border border-white/10 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-on-surface-variant hover:text-on-surface p-1 rounded-full bg-surface-container-highest cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">close</span>
        </button>

        {/* Header Icon */}
        <div className="flex flex-col items-center text-center gap-space-2xs mt-2">
          <div className="w-16 h-16 rounded-full bg-tertiary-container/40 flex items-center justify-center text-tertiary shadow-[0_0_24px_rgba(202,129,0,0.4)]">
            <span
              className="material-symbols-outlined text-[36px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              military_tech
            </span>
          </div>
          <span className="font-label-sm text-label-sm text-tertiary uppercase font-bold tracking-widest mt-1">
            Haftalik Chempionat
          </span>
          <h2 className="font-headline-md text-headline-md text-on-surface font-extrabold">
            Sovrinlar & Shartlar
          </h2>
        </div>

        {/* Prize Box */}
        <div className="p-space-md rounded-xl bg-gradient-to-r from-tertiary-container/30 via-surface-container to-surface-container border border-tertiary/30 flex items-center gap-space-md">
          <div className="w-12 h-12 rounded-xl bg-tertiary-container flex items-center justify-center text-on-tertiary-container shrink-0 shadow-md">
            <span className="text-2xl">🏆</span>
          </div>
          <div className="flex flex-col min-w-0">
            <span className="font-label-sm text-label-sm text-tertiary uppercase font-bold">
              1-O‘rin Bosh Mukofoti
            </span>
            <span className="font-headline-sm text-headline-sm text-on-surface font-extrabold truncate">
              {config.championshipTrophy}
            </span>
            <span className="font-label-md text-label-md text-secondary font-bold">
              +{config.championshipPrizeStars.toLocaleString()} Telegram Stars
            </span>
          </div>
        </div>

        {/* Current Leader */}
        <div className="flex flex-col gap-space-xs bg-surface-container p-space-sm rounded-xl">
          <span className="font-label-sm text-label-sm text-outline uppercase font-semibold">
            Hozirgi Hafta Yetakchisi
          </span>
          <div className="flex items-center gap-space-sm">
            <img
              src={leader.avatar}
              alt={leader.fullName}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-tertiary"
            />
            <div className="flex-1 min-w-0">
              <span className="font-body-md text-body-md font-bold text-on-surface block truncate">
                {leader.fullName}
              </span>
              <span className="font-label-sm text-label-sm text-tertiary font-bold">
                {leader.points.toLocaleString()} ball (#{leader.rank})
              </span>
            </div>
            <span className="text-xl">👑</span>
          </div>
        </div>

        {/* Rules */}
        <div className="flex flex-col gap-space-xs text-body-sm text-on-surface-variant bg-surface-container-lowest/80 p-space-md rounded-xl leading-relaxed">
          <span className="font-label-sm text-label-sm text-primary uppercase font-bold tracking-wider">
            Chempionat Qoidalari:
          </span>
          <p>• Har yakshanba soat 23:59 da haftalik hisob-kitob amalga oshiriladi.</p>
          <p>• Eng ko‘p ball to‘plagan Top-3 ishtirokchi shoxsupaga ko‘tariladi va Oltin Liga unvonini oladi.</p>
          <p>• Sovrin Telegram Stars orqali g‘olibning hisobiga rasmiy Telegram boti orqali avtomatik o‘tkaziladi.</p>
        </div>

        <button
          onClick={onClose}
          className="w-full py-space-sm rounded-xl bg-primary text-on-primary font-headline-sm text-headline-sm font-bold shadow-lg active:scale-95 transition-all cursor-pointer"
        >
          Tushunarli
        </button>
      </div>
    </div>
  );
};
