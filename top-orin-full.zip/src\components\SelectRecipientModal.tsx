import React, { useState } from 'react';
import { UserProfile } from '../types';

interface SelectRecipientModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserProfile[];
  onSelect: (user: UserProfile) => void;
}

export const SelectRecipientModal: React.FC<SelectRecipientModalProps> = ({
  isOpen,
  onClose,
  users,
  onSelect,
}) => {
  const [search, setSearch] = useState('');

  if (!isOpen) return null;

  const filtered = users.filter(
    (u) =>
      u.fullName.toLowerCase().includes(search.toLowerCase()) ||
      u.username.toLowerCase().includes(search.toLowerCase()) ||
      u.city.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-surface-dim/80 backdrop-blur-2xl flex items-center justify-center p-margin animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm rounded-2xl bg-surface-container-high p-space-lg shadow-2xl flex flex-col gap-space-md border border-white/10 max-h-[80vh]">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-on-surface-variant hover:text-on-surface p-1 rounded-full bg-surface-container-highest cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">close</span>
        </button>

        <div>
          <h3 className="font-headline-sm text-headline-sm text-on-surface font-bold">
            Qabul Qiluvchini Tanlang
          </h3>
          <p className="font-body-sm text-body-sm text-on-surface-variant">
            Sovg‘a yubormoqchi bo‘lgan ishtirokchini tanlang:
          </p>
        </div>

        {/* Search */}
        <div className="relative flex items-center">
          <span className="material-symbols-outlined absolute left-3 text-outline text-[18px]">
            search
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Ism yoki shahar bo‘yicha qidiruv..."
            className="w-full bg-surface-container-lowest text-on-surface pl-9 pr-3 py-2 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-primary/40"
          />
        </div>

        {/* User List */}
        <div className="flex-1 overflow-y-auto space-y-space-xs pr-1">
          {filtered.map((user) => (
            <div
              key={user.id}
              onClick={() => {
                onSelect(user);
                onClose();
              }}
              className="p-2.5 rounded-xl bg-surface-container hover:bg-surface-container-highest flex items-center justify-between gap-space-sm cursor-pointer transition-colors border border-white/5"
            >
              <div className="flex items-center gap-space-sm min-w-0">
                <div className="relative shrink-0">
                  <img
                    src={user.avatar}
                    alt={user.fullName}
                    className="w-10 h-10 rounded-full object-cover ring-1 ring-secondary/40"
                  />
                  <span className="absolute -bottom-1 -right-1 bg-secondary text-on-secondary font-bold text-[9px] px-1 rounded-full">
                    #{user.rank}
                  </span>
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="font-body-md text-body-md font-bold text-on-surface truncate">
                    {user.fullName}
                  </span>
                  <span className="text-xs text-on-surface-variant truncate">
                    {user.city} • {user.points.toLocaleString()} ball
                  </span>
                </div>
              </div>

              <span className="material-symbols-outlined text-tertiary text-[20px] shrink-0">
                card_giftcard
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
