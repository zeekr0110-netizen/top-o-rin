-- ==============================================================================
-- TOP O‘RIN - SUPABASE POSTGRESQL DATABASE ARCHITECTURE & RLS POLICIES
-- ==============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. USERS TABLE
CREATE TABLE IF NOT EXISTS public.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    telegram_id BIGINT UNIQUE,
    username TEXT,
    full_name TEXT NOT NULL,
    avatar_url TEXT,
    city TEXT DEFAULT 'Toshkent',
    bio TEXT,
    birth_date DATE,
    is_verified_18 BOOLEAN DEFAULT FALSE,
    points BIGINT DEFAULT 0 CHECK (points >= 0),
    rank INT DEFAULT 999999,
    gifts_received_count INT DEFAULT 0,
    gifts_sent_count INT DEFAULT 0,
    votes_count INT DEFAULT 0,
    weekly_wins INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    is_demo BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for instant leaderboard retrieval ordered by score
CREATE INDEX IF NOT EXISTS idx_users_points_rank ON public.users(points DESC, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON public.users(telegram_id);
CREATE INDEX IF NOT EXISTS idx_users_is_demo ON public.users(is_demo);

-- 3. GIFTS CATALOG TABLE
CREATE TABLE IF NOT EXISTS public.gifts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    uz_name TEXT NOT NULL,
    stars_price INT NOT NULL CHECK (stars_price > 0),
    points_reward INT NOT NULL CHECK (points_reward > 0),
    tier TEXT NOT NULL CHECK (tier IN ('standard', 'rare', 'epic', 'mythic', 'exalted')),
    tier_label TEXT NOT NULL,
    description TEXT,
    image_url TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. BOOST PACKAGES TABLE
CREATE TABLE IF NOT EXISTS public.boost_packages (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    stars_price INT NOT NULL CHECK (stars_price > 0),
    points_reward INT NOT NULL CHECK (points_reward > 0),
    bonus_label TEXT,
    is_popular BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE
);

-- 5. TRANSACTIONS TABLE (STRICT AUDIT & SERVER-SIDE VERIFICATION)
CREATE TABLE IF NOT EXISTS public.transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    type TEXT NOT NULL CHECK (type IN ('entry_fee', 'boost', 'gift_sent', 'gift_received')),
    amount_stars INT NOT NULL CHECK (amount_stars >= 0),
    points_awarded INT NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'verified', 'failed', 'refunded')),
    telegram_charge_id TEXT,
    provider_charge_id TEXT,
    recipient_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    message TEXT,
    is_anonymous BOOLEAN DEFAULT FALSE,
    is_demo BOOLEAN DEFAULT FALSE,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    verified_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_tx_user_status ON public.transactions(user_id, status);
CREATE INDEX IF NOT EXISTS idx_tx_created ON public.transactions(created_at DESC);

-- 6. WEEKLY COMPETITIONS ROUNDS
CREATE TABLE IF NOT EXISTS public.weekly_competitions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    week_number INT NOT NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    prize_stars INT DEFAULT 50000,
    prize_trophy TEXT DEFAULT 'Oltin Kubok',
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled')),
    winner_id UUID REFERENCES public.users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. CONFIGURATION TABLE
CREATE TABLE IF NOT EXISTS public.app_config (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    description TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. ATOMIC LEADERBOARD RANK RECALCULATION FUNCTION
CREATE OR REPLACE FUNCTION public.recalculate_ranks()
RETURNS VOID AS $$
BEGIN
    WITH ranked AS (
        SELECT id, ROW_NUMBER() OVER (ORDER BY points DESC, created_at ASC) as new_rank
        FROM public.users
        WHERE is_active = TRUE
    )
    UPDATE public.users u
    SET rank = r.new_rank,
        updated_at = NOW()
    FROM ranked r
    WHERE u.id = r.id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 9. TRANSACTION VERIFICATION FUNCTION (CALLED ONLY BY BACKEND WEBHOOK)
CREATE OR REPLACE FUNCTION public.verify_telegram_stars_transaction(
    p_tx_id UUID,
    p_telegram_charge_id TEXT,
    p_is_demo BOOLEAN DEFAULT FALSE
)
RETURNS BOOLEAN AS $$
DECLARE
    v_tx RECORD;
BEGIN
    -- Fetch pending transaction
    SELECT * INTO v_tx FROM public.transactions WHERE id = p_tx_id FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Transaction % not found', p_tx_id;
    END IF;

    IF v_tx.status = 'verified' THEN
        RETURN TRUE; -- Idempotent
    END IF;

    -- Mark as verified with telegram charge ID
    UPDATE public.transactions
    SET status = 'verified',
        telegram_charge_id = p_telegram_charge_id,
        verified_at = NOW(),
        is_demo = p_is_demo
    WHERE id = p_tx_id;

    -- Apply points to sender or recipient
    IF v_tx.type = 'entry_fee' OR v_tx.type = 'boost' THEN
        UPDATE public.users
        SET points = points + v_tx.points_awarded,
            updated_at = NOW()
        WHERE id = v_tx.user_id;
    ELSIF v_tx.type = 'gift_sent' AND v_tx.recipient_id IS NOT NULL THEN
        -- Recipient gets the points & increment gift counter
        UPDATE public.users
        SET points = points + v_tx.points_awarded,
            gifts_received_count = gifts_received_count + 1,
            updated_at = NOW()
        WHERE id = v_tx.recipient_id;

        -- Sender increment sent counter
        UPDATE public.users
        SET gifts_sent_count = gifts_sent_count + 1,
            updated_at = NOW()
        WHERE id = v_tx.user_id;
    END IF;

    -- Recalculate leaderboard
    PERFORM public.recalculate_ranks();

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 10. ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.boost_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.weekly_competitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_config ENABLE ROW LEVEL SECURITY;

-- Users: Read public for active; update only self
CREATE POLICY "Public users leaderboard view" ON public.users
    FOR SELECT USING (is_active = TRUE);

CREATE POLICY "Users can update their own profile" ON public.users
    FOR UPDATE USING (auth.uid() = id);

-- Catalog: Everyone can read
CREATE POLICY "Anyone can view gifts catalog" ON public.gifts
    FOR SELECT USING (is_active = TRUE);

CREATE POLICY "Anyone can view boost packages" ON public.boost_packages
    FOR SELECT USING (is_active = TRUE);

CREATE POLICY "Anyone can view active competitions" ON public.weekly_competitions
    FOR SELECT USING (TRUE);

-- Transactions: User can read their own
CREATE POLICY "Users can read own transactions" ON public.transactions
    FOR SELECT USING (auth.uid() = user_id OR auth.uid() = recipient_id);

-- Transactions: Creation must go through server-side verification; no direct client insert of 'verified' status
CREATE POLICY "Users can insert pending transactions only" ON public.transactions
    FOR INSERT WITH CHECK (status = 'pending');
