import { useState, useEffect } from 'react';
import { 
  UserProfile, 
  GiftItem, 
  BoostPackage, 
  TransactionRecord, 
  CompetitionConfig, 
  ScreenType 
} from '../types';
import { 
  APP_CONFIG, 
  DEFAULT_CURRENT_USER, 
  INITIAL_LEADERBOARD_USERS, 
  GIFTS_CATALOG, 
  BOOST_PACKAGES, 
  INITIAL_TRANSACTIONS 
} from '../config/appConfig';
import { triggerHaptic } from './telegram';

const STORAGE_KEYS = {
  USERS: 'toporin_users_v2',
  CURRENT_USER: 'toporin_current_user_v2',
  TRANSACTIONS: 'toporin_transactions_v2',
  STARS_BALANCE: 'toporin_stars_balance_v2',
  CONFIG: 'toporin_config_v2',
  IS_DEMO_MODE: 'toporin_demo_mode_v2',
};

export function useTopOrinStore() {
  // Navigation state
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('leaderboard');
  const [screenHistory, setScreenHistory] = useState<ScreenType[]>(['leaderboard']);

  // Modals state
  const [isWeeklyChampionOpen, setIsWeeklyChampionOpen] = useState(false);
  const [isTransactionsOpen, setIsTransactionsOpen] = useState(false);
  const [isRecipientPickerOpen, setIsRecipientPickerOpen] = useState(false);
  const [isGiftPreviewOpen, setIsGiftPreviewOpen] = useState(false);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);

  // App mode: Demo vs Production (Telegram Stars Live)
  const [isDemoMode, setIsDemoMode] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.IS_DEMO_MODE);
    return saved !== null ? JSON.parse(saved) : true;
  });

  // Config
  const [config, setConfig] = useState<CompetitionConfig>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CONFIG);
    return saved ? JSON.parse(saved) : APP_CONFIG;
  });

  // Current User
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return saved ? JSON.parse(saved) : DEFAULT_CURRENT_USER;
  });

  // Users list (Leaderboard)
  const [users, setUsers] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USERS);
    return saved ? JSON.parse(saved) : INITIAL_LEADERBOARD_USERS;
  });

  // Transactions list
  const [transactions, setTransactions] = useState<TransactionRecord[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    return saved ? JSON.parse(saved) : (INITIAL_TRANSACTIONS as TransactionRecord[]);
  });

  // Stars balance
  const [starsBalance, setStarsBalance] = useState<number>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STARS_BALANCE);
    return saved ? JSON.parse(saved) : 1250;
  });

  // Gift sending state
  const [selectedGift, setSelectedGift] = useState<GiftItem>(GIFTS_CATALOG[0]);
  const [selectedRecipient, setSelectedRecipient] = useState<UserProfile>(DEFAULT_CURRENT_USER);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [regionFilter, setRegionFilter] = useState<'all' | 'toshkent' | 'viloyatlar' | 'haftalik' | 'oylik'>('all');

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STARS_BALANCE, JSON.stringify(starsBalance));
  }, [starsBalance]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
  }, [config]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.IS_DEMO_MODE, JSON.stringify(isDemoMode));
  }, [isDemoMode]);

  // Navigate with history tracking
  const navigateTo = (screen: ScreenType) => {
    triggerHaptic('light');
    setScreenHistory((prev) => [...prev, screen]);
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateBack = () => {
    triggerHaptic('light');
    if (screenHistory.length > 1) {
      const nextHistory = [...screenHistory];
      nextHistory.pop();
      const prevScreen = nextHistory[nextHistory.length - 1];
      setScreenHistory(nextHistory);
      setCurrentScreen(prevScreen || 'leaderboard');
    } else {
      setCurrentScreen('leaderboard');
    }
  };

  // Re-sort and rank users whenever points change
  const recalculateLeaderboardRanks = (userList: UserProfile[]) => {
    const sorted = [...userList].sort((a, b) => b.points - a.points);
    return sorted.map((u, idx) => ({
      ...u,
      previousRank: u.rank || idx + 1,
      rank: idx + 1,
    }));
  };

  /**
   * Verified Transaction Processing
   * Crucial rule: "Do not fabricate successful payments or ranking changes.
   * Implement real ranking updates only after verified transactions."
   */
  const processVerifiedTransaction = (txId: string) => {
    setTransactions((prevTx) => {
      const target = prevTx.find((t) => t.id === txId);
      if (!target || target.status === 'verified') return prevTx;

      const updatedTx = prevTx.map((t) =>
        t.id === txId
          ? {
              ...t,
              status: 'verified' as const,
              timestamp: 'Hozirgina',
              verifiedAt: new Date().toISOString(),
            }
          : t
      );

      // Now apply points and ranking update AFTER verification
      setUsers((prevUsers) => {
        let updatedUsers = [...prevUsers];

        if (target.type === 'boost' || target.type === 'entry_fee') {
          updatedUsers = updatedUsers.map((u) => {
            if (u.id === target.senderId) {
              return { ...u, points: u.points + target.points };
            }
            return u;
          });
        } else if (target.type === 'gift_sent' && target.recipientId) {
          updatedUsers = updatedUsers.map((u) => {
            if (u.id === target.recipientId) {
              return {
                ...u,
                points: u.points + target.points,
                giftsReceivedCount: u.giftsReceivedCount + 1,
              };
            }
            if (u.id === target.senderId) {
              return {
                ...u,
                giftsSentCount: u.giftsSentCount + 1,
              };
            }
            return u;
          });
        }

        const reranked = recalculateLeaderboardRanks(updatedUsers);

        // Update current user if affected
        const updatedCurrent = reranked.find((u) => u.id === currentUser.id);
        if (updatedCurrent) {
          setCurrentUser(updatedCurrent);
        }

        return reranked;
      });

      return updatedTx;
    });
  };

  /**
   * Create a new pending transaction (before payment verification)
   */
  const initiateTransaction = (
    type: TransactionRecord['type'],
    title: string,
    stars: number,
    points: number,
    options?: {
      recipientId?: string;
      recipientName?: string;
      message?: string;
      isAnonymous?: boolean;
    }
  ): TransactionRecord => {
    const newTx: TransactionRecord = {
      id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      type,
      title,
      stars,
      points,
      timestamp: 'Kutilmoqda...',
      status: 'pending',
      senderId: currentUser.id,
      senderName: currentUser.fullName,
      recipientId: options?.recipientId,
      recipientName: options?.recipientName,
      message: options?.message,
      isAnonymous: options?.isAnonymous,
      isDemo: isDemoMode,
      telegramChargeId: isDemoMode ? `demo_chg_${Date.now()}` : undefined,
    };

    setTransactions((prev) => [newTx, ...prev]);
    return newTx;
  };

  // Mark transaction as failed
  const failTransaction = (txId: string) => {
    setTransactions((prev) =>
      prev.map((t) => (t.id === txId ? { ...t, status: 'failed' as const, timestamp: 'Bekor qilindi' } : t))
    );
  };

  // Register new participant from Anketa
  const registerNewParticipant = (data: {
    fullName: string;
    username: string;
    avatar: string;
    city: string;
    bio: string;
    birthDate: string;
    age: number;
    interests: string[];
  }) => {
    const newUser: UserProfile = {
      id: `user-${Date.now()}`,
      telegramId: currentUser.telegramId || Math.floor(1000000 + Math.random() * 9000000),
      fullName: data.fullName,
      username: data.username.replace('@', ''),
      avatar: data.avatar,
      city: data.city,
      bio: data.bio,
      birthDate: data.birthDate,
      age: data.age,
      isVerified18: true,
      points: 0, // Starts with 0 until entry fee verified!
      rank: users.length + 1,
      previousRank: users.length + 1,
      giftsReceivedCount: 0,
      giftsSentCount: 0,
      votesCount: 0,
      weeklyWins: 0,
      isOnline: true,
      isCurrentUser: true,
      isDemo: isDemoMode,
      interests: data.interests,
      badges: [
        { id: 'b_new', title: 'Yangi Ishtirokchi', category: 'Liga 2025', icon: 'verified', color: 'secondary' }
      ]
    };

    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);
    return newUser;
  };

  // Reset demo data to factory defaults
  const resetToDefaults = () => {
    setUsers(INITIAL_LEADERBOARD_USERS);
    setCurrentUser(DEFAULT_CURRENT_USER);
    setTransactions(INITIAL_TRANSACTIONS as TransactionRecord[]);
    setStarsBalance(1250);
    setConfig(APP_CONFIG);
    localStorage.clear();
  };

  return {
    currentScreen,
    setCurrentScreen,
    navigateTo,
    navigateBack,
    isWeeklyChampionOpen,
    setIsWeeklyChampionOpen,
    isTransactionsOpen,
    setIsTransactionsOpen,
    isRecipientPickerOpen,
    setIsRecipientPickerOpen,
    isGiftPreviewOpen,
    setIsGiftPreviewOpen,
    isConfigModalOpen,
    setIsConfigModalOpen,
    isDemoMode,
    setIsDemoMode,
    config,
    setConfig,
    currentUser,
    setCurrentUser,
    users,
    setUsers,
    transactions,
    starsBalance,
    setStarsBalance,
    selectedGift,
    setSelectedGift,
    selectedRecipient,
    setSelectedRecipient,
    searchQuery,
    setSearchQuery,
    regionFilter,
    setRegionFilter,
    initiateTransaction,
    processVerifiedTransaction,
    failTransaction,
    registerNewParticipant,
    resetToDefaults,
  };
}
