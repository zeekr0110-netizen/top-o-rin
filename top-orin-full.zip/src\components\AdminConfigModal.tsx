import React, { useState } from 'react';
import { CompetitionConfig } from '../types';

interface AdminConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: CompetitionConfig;
  onSaveConfig: (newConfig: CompetitionConfig) => void;
  onResetData: () => void;
}

export const AdminConfigModal: React.FC<AdminConfigModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  onResetData,
}) => {
  const [entryFee, setEntryFee] = useState(config.entryFeeStars);
  const [entryPoints, setEntryPoints] = useState(config.entryPointsBonus);
  const [prizeStars, setPrizeStars] = useState(config.championshipPrizeStars);
  const [prizeTrophy, setPrizeTrophy] = useState(config.championshipTrophy);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveConfig({
      ...config,
      entryFeeStars: Number(entryFee),
      entryPointsBonus: Number(entryPoints),
      championshipPrizeStars: Number(prizeStars),
      championshipTrophy: prizeTrophy,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-surface-dim/80 backdrop-blur-2xl flex items-center justify-center p-margin animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm rounded-2xl bg-surface-container-high p-space-lg shadow-2xl flex flex-col gap-space-md border border-white/10">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-on-surface-variant hover:text-on-surface p-1 rounded-full bg-surface-container-highest cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">close</span>
        </button>

        <div className="flex items-center gap-space-sm">
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
            <span className="material-symbols-outlined text-[22px]">tune</span>
          </div>
          <div>
            <h3 className="font-headline-sm text-headline-sm text-on-surface font-bold">
              Konfiguratsiya & Qoidalar
            </h3>
            <span className="text-xs text-on-surface-variant">
              Narxlar va ball bonuslarini boshqarish
            </span>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs text-on-surface-variant block mb-1">
              Kirish to‘lovi (Telegram Stars):
            </label>
            <input
              type="number"
              value={entryFee}
              onChange={(e) => setEntryFee(Number(e.target.value))}
              className="w-full bg-surface-container-lowest px-3 py-2 rounded-xl text-sm text-on-surface focus:outline-none focus:ring-1 focus:ring-primary/40"
            />
          </div>

          <div>
            <label className="text-xs text-on-surface-variant block mb-1">
              Boshlang‘ich ball bonusi:
            </label>
            <input
              type="number"
              value={entryPoints}
              onChange={(e) => setEntryPoints(Number(e.target.value))}
              className="w-full bg-surface-container-lowest px-3 py-2 rounded-xl text-sm text-on-surface focus:outline-none focus:ring-1 focus:ring-primary/40"
            />
          </div>

          <div>
            <label className="text-xs text-on-surface-variant block mb-1">
              Hafta g‘olibi yutug‘i (Stars):
            </label>
            <input
              type="number"
              value={prizeStars}
              onChange={(e) => setPrizeStars(Number(e.target.value))}
              className="w-full bg-surface-container-lowest px-3 py-2 rounded-xl text-sm text-on-surface focus:outline-none focus:ring-1 focus:ring-primary/40"
            />
          </div>

          <div>
            <label className="text-xs text-on-surface-variant block mb-1">
              Hafta g‘olibi kubogi:
            </label>
            <input
              type="text"
              value={prizeTrophy}
              onChange={(e) => setPrizeTrophy(e.target.value)}
              className="w-full bg-surface-container-lowest px-3 py-2 rounded-xl text-sm text-on-surface focus:outline-none focus:ring-1 focus:ring-primary/40"
            />
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <button
            onClick={handleSave}
            className="flex-1 py-2.5 rounded-xl bg-primary text-on-primary font-bold text-sm shadow-md active:scale-95 transition-all cursor-pointer"
          >
            Saqlash
          </button>
          <button
            onClick={() => {
              if (confirm('Barcha demo ma\'lumotlar zavod holatiga qaytarilsinmi?')) {
                onResetData();
                onClose();
              }
            }}
            className="px-3 py-2.5 rounded-xl bg-error-container/30 text-error text-xs font-bold active:scale-95 transition-all cursor-pointer"
          >
            Reset
          </button>
        </div>
      </div>
    </div>
  );
};
